package com.chargepulse.pro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

public final class ChargeGaugeView extends View {
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint value = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF bounds = new RectF();
    private float currentMa = Float.NaN;
    private boolean charging;
    private boolean supported;

    public ChargeGaugeView(Context context) {
        super(context);
        track.setStyle(Paint.Style.STROKE);
        track.setStrokeCap(Paint.Cap.ROUND);
        track.setColor(Color.rgb(38, 54, 58));
        value.setStyle(Paint.Style.STROKE);
        value.setStrokeCap(Paint.Cap.ROUND);
    }

    public void setReading(float current, boolean isCharging, boolean isSupported) {
        currentMa = current;
        charging = isCharging;
        supported = isSupported;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float width = getWidth();
        float stroke = Math.max(18f, width * 0.055f);
        float inset = stroke * 1.3f;
        track.setStrokeWidth(stroke);
        value.setStrokeWidth(stroke);
        bounds.set(inset, inset, width - inset, getHeight() * 1.35f);
        canvas.drawArc(bounds, 150f, 240f, false, track);

        float max = 5000f;
        if (supported && !Float.isNaN(currentMa)) {
            max = Math.max(5000f, (float) Math.ceil(Math.abs(currentMa) / 1000f) * 1000f);
        }
        float fraction = supported && !Float.isNaN(currentMa)
                ? Math.min(1f, Math.abs(currentMa) / max)
                : 0f;
        value.setColor(!supported
                ? Color.rgb(112, 126, 132)
                : charging ? Color.rgb(53, 224, 138) : Color.rgb(255, 111, 120));
        canvas.drawArc(bounds, 150f, 240f * fraction, false, value);
    }
}
