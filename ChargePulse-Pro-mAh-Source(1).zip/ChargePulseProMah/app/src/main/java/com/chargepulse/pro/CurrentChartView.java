package com.chargepulse.pro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public final class CurrentChartView extends View {
    private static final int MAX_SAMPLES = 60;
    private final List<Float> samples = new ArrayList<>();
    private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
    private boolean charging;

    public CurrentChartView(Context context) {
        super(context);
        grid.setColor(Color.rgb(38, 54, 58));
        grid.setStrokeWidth(2f);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(5f);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
        fill.setStyle(Paint.Style.FILL);
        label.setColor(Color.rgb(145, 162, 166));
        label.setTextSize(25f);
    }

    public void addSample(float currentMa, boolean isCharging) {
        if (Float.isNaN(currentMa)) return;
        charging = isCharging;
        samples.add(currentMa);
        while (samples.size() > MAX_SAMPLES) samples.remove(0);
        invalidate();
    }

    public void reset() {
        samples.clear();
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float left = 18f;
        float right = getWidth() - 18f;
        float top = 18f;
        float bottom = getHeight() - 38f;
        for (int i = 0; i <= 4; i++) {
            float y = top + (bottom - top) * i / 4f;
            canvas.drawLine(left, y, right, y, grid);
        }
        for (int i = 0; i <= 6; i++) {
            float x = left + (right - left) * i / 6f;
            canvas.drawLine(x, top, x, bottom, grid);
        }
        canvas.drawText("last 60 seconds", left, getHeight() - 8f, label);
        if (samples.size() < 2) {
            canvas.drawText("Waiting for samples…", left, getHeight() / 2f, label);
            return;
        }
        float maximum = 500f;
        for (float sample : samples) maximum = Math.max(maximum, Math.abs(sample));
        Path linePath = new Path();
        Path fillPath = new Path();
        for (int i = 0; i < samples.size(); i++) {
            float x = left + (right - left) * i / (MAX_SAMPLES - 1f);
            float y = bottom - Math.abs(samples.get(i)) / maximum * (bottom - top);
            if (i == 0) {
                linePath.moveTo(x, y);
                fillPath.moveTo(x, bottom);
                fillPath.lineTo(x, y);
            } else {
                linePath.lineTo(x, y);
                fillPath.lineTo(x, y);
            }
        }
        float lastX = left + (right - left) * (samples.size() - 1) / (MAX_SAMPLES - 1f);
        fillPath.lineTo(lastX, bottom);
        fillPath.close();
        line.setColor(charging ? Color.rgb(53, 224, 138) : Color.rgb(255, 111, 120));
        fill.setColor(charging ? Color.argb(44, 53, 224, 138) : Color.argb(44, 255, 111, 120));
        canvas.drawPath(fillPath, fill);
        canvas.drawPath(linePath, line);
    }
}
