package com.chargepulse.pro;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int BG = Color.rgb(8, 17, 15);
    private static final int CARD = Color.rgb(17, 30, 29);
    private static final int CARD_ALT = Color.rgb(20, 37, 36);
    private static final int TEXT = Color.rgb(239, 249, 245);
    private static final int MUTED = Color.rgb(145, 162, 166);
    private static final int ACCENT = Color.rgb(53, 224, 138);
    private static final int CYAN = Color.rgb(65, 199, 255);
    private static final int DANGER = Color.rgb(255, 111, 120);
    private static final int BORDER = Color.rgb(36, 58, 56);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private BatteryManager batteryManager;
    private LinearLayout root;
    private ChargeGaugeView gauge;
    private CurrentChartView chart;
    private TextView currentValue;
    private TextView currentCaption;
    private TextView badge;
    private TextView speedValue;
    private TextView powerValue;
    private TextView liveCurrentValue;
    private TextView voltageValue;
    private TextView averageValue;
    private TextView levelValue;
    private TextView temperatureValue;
    private TextView sourceValue;
    private TextView healthValue;
    private TextView sessionTimeValue;
    private TextView sessionAverageValue;
    private TextView peakValue;
    private TextView note;
    private Switch keepAwakeSwitch;
    private long sessionStart;
    private int sampleCount;
    private double sampleSum;
    private float peak;
    private double chargedMah;
    private long lastMahSampleAt;
    private Snapshot latest;

    private final Runnable updater = new Runnable() {
        @Override public void run() {
            refreshReading();
            handler.postDelayed(this, 1000L);
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        batteryManager = (BatteryManager) getSystemService(BATTERY_SERVICE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
        }
        buildUi();
        resetSession();
    }

    @Override protected void onResume() {
        super.onResume();
        handler.removeCallbacks(updater);
        handler.post(updater);
    }

    @Override protected void onPause() {
        handler.removeCallbacks(updater);
        super.onPause();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setBackgroundColor(BG);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(32));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));
        setContentView(scroll);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            scroll.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
                @Override public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                    Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                    root.setPadding(dp(18) + bars.left, dp(18) + bars.top,
                            dp(18) + bars.right, dp(32) + bars.bottom);
                    return insets;
                }
            });
        }

        addHeader();
        addGaugeCard();
        addMetrics();
        addChart();
        addSession();
        addTools();
        note = text("Reading battery hardware…", 12, MUTED, Typeface.NORMAL);
        note.setLineSpacing(0f, 1.18f);
        root.addView(note, margins(-1, -2, 4, 5, 4, 0));
    }

    private void addHeader() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(text("ChargePulse Pro", 26, TEXT, Typeface.BOLD));
        titles.addView(text("Live current and charged mAh meter", 14, MUTED, Typeface.NORMAL));
        row.addView(titles, new LinearLayout.LayoutParams(0, -2, 1f));
        badge = text("CHECKING", 12, BG, Typeface.BOLD);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(13), dp(8), dp(13), dp(8));
        badge.setBackground(round(MUTED, 18, 0, 0));
        row.addView(badge);
        root.addView(row);
    }

    private void addGaugeCard() {
        LinearLayout card = card();
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        gauge = new ChargeGaugeView(this);
        card.addView(gauge, new LinearLayout.LayoutParams(-1, dp(230)));
        currentValue = text("—", 56, TEXT, Typeface.BOLD);
        currentValue.setGravity(Gravity.CENTER);
        card.addView(currentValue, margins(-1, -2, 0, -68, 0, 0));
        TextView unit = text("mAh", 16, MUTED, Typeface.BOLD);
        unit.setGravity(Gravity.CENTER);
        card.addView(unit);
        currentCaption = text("Estimated charge added this session", 14, MUTED, Typeface.NORMAL);
        currentCaption.setGravity(Gravity.CENTER);
        card.addView(currentCaption, margins(-1, -2, 0, 8, 0, 0));
        speedValue = text("Checking charging speed…", 17, ACCENT, Typeface.BOLD);
        speedValue.setGravity(Gravity.CENTER);
        card.addView(speedValue, margins(-1, -2, 0, 12, 0, 0));
        root.addView(card, margins(-1, -2, 0, 20, 0, 0));
    }

    private void addMetrics() {
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);
        powerValue = metric(grid, "Estimated power", "— W", ACCENT, 0, 0);
        liveCurrentValue = metric(grid, "Live charging speed", "— mA", CYAN, 0, 1);
        voltageValue = metric(grid, "Battery voltage", "— V", TEXT, 1, 0);
        averageValue = metric(grid, "Average current", "— mA", TEXT, 1, 1);
        levelValue = metric(grid, "Battery level", "—%", TEXT, 2, 0);
        temperatureValue = metric(grid, "Temperature", "— °C", TEXT, 2, 1);
        sourceValue = metric(grid, "Power source", "Unknown", TEXT, 3, 0);
        healthValue = metric(grid, "Battery health", "Unknown", TEXT, 3, 1);
        root.addView(grid, margins(-1, -2, 0, 14, 0, 0));
    }

    private TextView metric(GridLayout grid, String label, String initial, int color, int row, int col) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(13), dp(14), dp(13));
        box.setBackground(round(CARD, 18, BORDER, 1));
        box.addView(text(label, 12, MUTED, Typeface.NORMAL));
        TextView value = text(initial, 18, color, Typeface.BOLD);
        box.addView(value, margins(-1, -2, 0, 6, 0, 0));
        GridLayout.LayoutParams p = new GridLayout.LayoutParams(
                GridLayout.spec(row, 1f), GridLayout.spec(col, 1f));
        p.width = 0;
        p.height = -2;
        p.setMargins(col == 0 ? 0 : dp(6), row == 0 ? 0 : dp(6),
                col == 0 ? dp(6) : 0, 0);
        grid.addView(box, p);
        return value;
    }

    private void addChart() {
        LinearLayout card = card();
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.addView(text("Live current", 17, TEXT, Typeface.BOLD),
                new LinearLayout.LayoutParams(0, -2, 1f));
        titleRow.addView(text("LAST 60 SEC", 11, MUTED, Typeface.BOLD));
        card.addView(titleRow);
        chart = new CurrentChartView(this);
        card.addView(chart, margins(-1, dp(210), 0, 12, 0, 0));
        root.addView(card, margins(-1, -2, 0, 14, 0, 0));
    }

    private void addSession() {
        LinearLayout card = card();
        card.addView(text("Measurement session", 17, TEXT, Typeface.BOLD));
        LinearLayout row = new LinearLayout(this);
        sessionTimeValue = sessionItem(row, "TIME", "00:00");
        sessionAverageValue = sessionItem(row, "CHARGE ADDED", "0.00 mAh");
        peakValue = sessionItem(row, "PEAK CURRENT", "— mA");
        card.addView(row, margins(-1, -2, 0, 14, 0, 0));
        Button reset = button("Reset session", CARD_ALT, TEXT);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                resetSession();
                Toast.makeText(MainActivity.this, "Session reset", Toast.LENGTH_SHORT).show();
            }
        });
        card.addView(reset, margins(-1, dp(48), 0, 14, 0, 0));
        root.addView(card, margins(-1, -2, 0, 14, 0, 0));
    }

    private TextView sessionItem(LinearLayout row, String label, String initial) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.addView(text(label, 10, MUTED, Typeface.BOLD));
        TextView value = text(initial, 16, TEXT, Typeface.BOLD);
        item.addView(value, margins(-2, -2, 0, 5, 0, 0));
        row.addView(item, new LinearLayout.LayoutParams(0, -2, 1f));
        return value;
    }

    private void addTools() {
        LinearLayout card = card();
        card.addView(text("Tools", 17, TEXT, Typeface.BOLD));
        keepAwakeSwitch = new Switch(this);
        keepAwakeSwitch.setText("Keep screen awake while charging");
        keepAwakeSwitch.setTextColor(TEXT);
        keepAwakeSwitch.setTextSize(14);
        keepAwakeSwitch.setChecked(true);
        keepAwakeSwitch.setPadding(0, dp(8), 0, dp(8));
        keepAwakeSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean checked) {
                updateKeepAwake(latest != null && latest.charging);
            }
        });
        card.addView(keepAwakeSwitch, margins(-1, -2, 0, 8, 0, 0));
        Button copy = button("Copy measurement snapshot", ACCENT, BG);
        copy.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { copySnapshot(); }
        });
        card.addView(copy, margins(-1, dp(50), 0, 8, 0, 0));
        root.addView(card, margins(-1, -2, 0, 14, 0, 0));
    }

    private void refreshReading() {
        Snapshot s = readSnapshot();
        latest = s;
        updateKeepAwake(s.charging);
        int badgeColor = s.charging ? ACCENT : s.plugged ? CYAN : DANGER;
        badge.setText(s.status.toUpperCase(Locale.US));
        badge.setBackground(round(badgeColor, 18, 0, 0));
        long now = System.currentTimeMillis();
        long elapsedForMah = lastMahSampleAt > 0L ? now - lastMahSampleAt : 0L;
        lastMahSampleAt = now;

        if (s.supported && s.charging && !Float.isNaN(s.currentMa)) {
            chargedMah = ChargingMath.accumulateMah(
                    chargedMah,
                    s.currentMa,
                    elapsedForMah,
                    true
            );
        }

        currentValue.setText(ChargingMath.formatMah(chargedMah));
        currentValue.setTextColor(!s.supported ? MUTED : s.charging ? ACCENT : TEXT);
        currentCaption.setText(s.supported
                ? "Estimated charge added since session reset"
                : "mAh cannot be estimated without current data");
        gauge.setReading((float) chargedMah, s.charging, s.supported);
        speedValue.setText(ChargingMath.speedLabel(s.powerWatts, s.charging));
        speedValue.setTextColor(s.charging ? ACCENT : MUTED);
        powerValue.setText(Float.isNaN(s.powerWatts) ? "— W"
                : String.format(Locale.US, "%.2f W", s.powerWatts));
        liveCurrentValue.setText(Float.isNaN(s.currentMa) ? "— mA"
                : String.format(Locale.US, "%,.0f mA", Math.abs(s.currentMa)));
        voltageValue.setText(Float.isNaN(s.voltageVolts) ? "— V"
                : String.format(Locale.US, "%.3f V", s.voltageVolts));
        averageValue.setText(Float.isNaN(s.averageMa) ? "— mA"
                : String.format(Locale.US, "%,.0f mA", Math.abs(s.averageMa)));
        levelValue.setText(s.level >= 0 ? s.level + "%" : "—%");
        temperatureValue.setText(s.temperature > -100f
                ? String.format(Locale.US, "%.1f °C", s.temperature) : "— °C");
        sourceValue.setText(s.source);
        healthValue.setText(s.health);
        if (s.supported) {
            chart.addSample(s.currentMa, s.charging);
            sampleCount++;
            sampleSum += s.currentMa;
            peak = Math.max(peak, Math.abs(s.currentMa));
        }
        sessionTimeValue.setText(ChargingMath.formatDuration(System.currentTimeMillis() - sessionStart));
        sessionAverageValue.setText(
                ChargingMath.formatMah(chargedMah) + " mAh"
        );
        peakValue.setText(sampleCount > 0
                ? String.format(Locale.US, "%,.0f mA", peak) : "— mA");
        note.setText(s.supported
                ? "Live hardware reading available. Estimated watts are battery-side current × battery voltage and may differ from the charger rating."
                : "Current sensor unavailable on this phone. Android cannot show charging current when the manufacturer does not expose it.");
    }

    private Snapshot readSnapshot() {
        Intent intent = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (intent == null) return Snapshot.empty();
        int statusCode = intent.getIntExtra(BatteryManager.EXTRA_STATUS,
                BatteryManager.BATTERY_STATUS_UNKNOWN);
        int pluggedCode = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
        boolean charging = statusCode == BatteryManager.BATTERY_STATUS_CHARGING
                || statusCode == BatteryManager.BATTERY_STATUS_FULL;
        boolean plugged = pluggedCode != 0;
        long currentNow = batteryManager.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);
        long currentAverage = batteryManager.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_AVERAGE);
        boolean supported = currentNow != Long.MIN_VALUE;
        float currentMa = ChargingMath.normalizeCurrentMa(currentNow, charging);
        float averageMa = ChargingMath.normalizeCurrentMa(currentAverage, charging);
        int millivolts = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
        float volts = millivolts > 0 ? millivolts / 1000f : Float.NaN;
        float watts = supported ? ChargingMath.estimatePowerWatts(currentMa, volts) : Float.NaN;
        int levelRaw = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int level = levelRaw >= 0 && scale > 0 ? Math.round(levelRaw * 100f / scale) : -1;
        int tempRaw = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1000);
        float temp = tempRaw > -1000 ? tempRaw / 10f : -1000f;
        int healthCode = intent.getIntExtra(BatteryManager.EXTRA_HEALTH,
                BatteryManager.BATTERY_HEALTH_UNKNOWN);
        return new Snapshot(supported, charging, plugged, currentMa, averageMa, volts,
                watts, level, temp, statusName(statusCode), sourceName(pluggedCode),
                healthName(healthCode));
    }

    private void resetSession() {
        sessionStart = System.currentTimeMillis();
        sampleCount = 0;
        sampleSum = 0d;
        peak = 0f;
        chargedMah = 0d;
        lastMahSampleAt = 0L;
        if (chart != null) chart.reset();
        if (sessionTimeValue != null) {
            sessionTimeValue.setText("00:00");
            sessionAverageValue.setText("0.00 mAh");
            peakValue.setText("— mA");
        }
    }

    private void updateKeepAwake(boolean charging) {
        if (keepAwakeSwitch != null && keepAwakeSwitch.isChecked() && charging) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    private void copySnapshot() {
        if (latest == null) {
            Toast.makeText(this, "No reading yet", Toast.LENGTH_SHORT).show();
            return;
        }
        String report = "ChargePulse Pro measurement\n"
                + "Status: " + latest.status + "\n"
                + "Charge added this session: " + ChargingMath.formatMah(chargedMah) + " mAh\n"
                + "Live current: " + ChargingMath.formatCurrent(latest.currentMa) + " mA\n"
                + "Estimated power: " + (Float.isNaN(latest.powerWatts)
                    ? "Unavailable" : String.format(Locale.US, "%.2f W", latest.powerWatts)) + "\n"
                + "Voltage: " + (Float.isNaN(latest.voltageVolts)
                    ? "Unavailable" : String.format(Locale.US, "%.3f V", latest.voltageVolts)) + "\n"
                + "Battery: " + latest.level + "%\n"
                + "Temperature: " + String.format(Locale.US, "%.1f °C", latest.temperature) + "\n"
                + "Source: " + latest.source + "\n"
                + "Health: " + latest.health;
        ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        manager.setPrimaryClip(ClipData.newPlainText("ChargePulse measurement", report));
        Toast.makeText(this, "Measurement copied", Toast.LENGTH_SHORT).show();
    }

    private static String statusName(int status) {
        switch (status) {
            case BatteryManager.BATTERY_STATUS_CHARGING: return "Charging";
            case BatteryManager.BATTERY_STATUS_FULL: return "Full";
            case BatteryManager.BATTERY_STATUS_DISCHARGING: return "Discharging";
            case BatteryManager.BATTERY_STATUS_NOT_CHARGING: return "Not charging";
            default: return "Unknown";
        }
    }

    private static String sourceName(int source) {
        if ((source & BatteryManager.BATTERY_PLUGGED_AC) != 0) return "AC charger";
        if ((source & BatteryManager.BATTERY_PLUGGED_USB) != 0) return "USB";
        if ((source & BatteryManager.BATTERY_PLUGGED_WIRELESS) != 0) return "Wireless";
        return "Battery";
    }

    private static String healthName(int health) {
        switch (health) {
            case BatteryManager.BATTERY_HEALTH_GOOD: return "Good";
            case BatteryManager.BATTERY_HEALTH_OVERHEAT: return "Overheating";
            case BatteryManager.BATTERY_HEALTH_DEAD: return "Dead";
            case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE: return "Over voltage";
            case BatteryManager.BATTERY_HEALTH_COLD: return "Cold";
            case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE: return "Failure";
            default: return "Unknown";
        }
    }

    private LinearLayout card() {
        LinearLayout view = new LinearLayout(this);
        view.setOrientation(LinearLayout.VERTICAL);
        view.setPadding(dp(16), dp(16), dp(16), dp(16));
        view.setBackground(round(CARD, 22, BORDER, 1));
        return view;
    }

    private TextView text(String value, float size, int color, int style) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setTypeface(Typeface.create("sans", style));
        return view;
    }

    private Button button(String value, int background, int foreground) {
        Button button = new Button(this);
        button.setText(value);
        button.setTextSize(14);
        button.setTextColor(foreground);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setAllCaps(false);
        button.setGravity(Gravity.CENTER);
        button.setBackground(round(background, 15, 0, 0));
        return button;
    }

    private GradientDrawable round(int color, int radius, int strokeColor, int stroke) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        if (stroke > 0) drawable.setStroke(dp(stroke), strokeColor);
        return drawable;
    }

    private LinearLayout.LayoutParams margins(int width, int height,
            int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(width, height);
        p.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return p;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static final class Snapshot {
        final boolean supported, charging, plugged;
        final float currentMa, averageMa, voltageVolts, powerWatts, temperature;
        final int level;
        final String status, source, health;

        Snapshot(boolean supported, boolean charging, boolean plugged, float currentMa,
                float averageMa, float voltageVolts, float powerWatts, int level,
                float temperature, String status, String source, String health) {
            this.supported = supported;
            this.charging = charging;
            this.plugged = plugged;
            this.currentMa = currentMa;
            this.averageMa = averageMa;
            this.voltageVolts = voltageVolts;
            this.powerWatts = powerWatts;
            this.level = level;
            this.temperature = temperature;
            this.status = status;
            this.source = source;
            this.health = health;
        }

        static Snapshot empty() {
            return new Snapshot(false, false, false, Float.NaN, Float.NaN,
                    Float.NaN, Float.NaN, -1, -1000f,
                    "Unknown", "Unknown", "Unknown");
        }
    }
}
