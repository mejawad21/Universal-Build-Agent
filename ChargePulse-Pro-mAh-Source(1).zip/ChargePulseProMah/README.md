# ChargePulse Pro 1.1 — mAh Edition

The large main reading now shows **estimated mAh added during the current
measurement session**.

## Measurements

- Main display: accumulated charge added in mAh.
- Live charging speed: mA.
- Estimated battery-side power: watts.
- Battery voltage, level, temperature, health and charging source.
- 60-second live-current graph.
- Session timer and peak current.

## Accuracy note

mA is instantaneous current (charging speed). mAh is accumulated charge over
time. The app calculates session mAh by integrating Android's current reading
over elapsed time. This is an estimate and depends on whether the phone
manufacturer exposes a reliable battery-current sensor.

The app works offline and requests no Internet or storage permission.
