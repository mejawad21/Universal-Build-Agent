THIRD-PARTY NOTICES

PyMuPDF / MuPDF
Used for PDF reading, text extraction, preview, and page rendering.
Review the applicable PyMuPDF/MuPDF license before commercial redistribution.

python-docx
Used for reading and writing Microsoft Word DOCX files. MIT License.

ReportLab
Used for the built-in Word-to-PDF rendering fallback. BSD-style license.

Pillow
Used for image processing and previews. HPND License.

PyInstaller
Used to create the portable Windows executable. GPL-2.0-or-later with a special
exception that permits distribution of bundled applications.

LibreOffice
The optional Windows workflow attempts to bundle a LibreOffice runtime for
high-fidelity Word-to-PDF conversion. LibreOffice is distributed under MPL 2.0
and secondary LGPL terms. Preserve its license and notice files when distributing
that runtime.
