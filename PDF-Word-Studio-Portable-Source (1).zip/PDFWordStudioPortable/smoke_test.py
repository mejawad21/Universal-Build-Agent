from pathlib import Path
import tempfile

from docx import Document
from reportlab.pdfgen import canvas

from converter import pdf_to_word, word_to_pdf


def main() -> None:
    with tempfile.TemporaryDirectory() as temp_name:
        temp = Path(temp_name)
        pdf = temp / 'sample.pdf'
        docx = temp / 'sample.docx'
        docx_from_pdf = temp / 'from-pdf.docx'
        pdf_from_docx = temp / 'from-word.pdf'

        drawing = canvas.Canvas(str(pdf))
        drawing.setFont('Helvetica-Bold', 18)
        drawing.drawString(72, 760, 'Portable Conversion Test')
        drawing.setFont('Helvetica', 11)
        drawing.drawString(72, 730, 'This PDF text should become editable in Word.')
        drawing.save()

        document = Document()
        document.add_heading('Portable Conversion Test', level=1)
        document.add_paragraph('This Word content should become a PDF without installation.')
        table = document.add_table(rows=2, cols=2)
        table.cell(0, 0).text = 'Item'
        table.cell(0, 1).text = 'Status'
        table.cell(1, 0).text = 'Converter'
        table.cell(1, 1).text = 'Passed'
        document.save(docx)

        result_one = pdf_to_word(pdf, docx_from_pdf, mode='editable')
        result_two = word_to_pdf(docx, pdf_from_docx, engine='built-in')

        assert docx_from_pdf.is_file() and docx_from_pdf.stat().st_size > 1000
        assert pdf_from_docx.is_file() and pdf_from_docx.stat().st_size > 1000
        Document(docx_from_pdf)
        assert pdf_from_docx.read_bytes().startswith(b'%PDF')
        print('PDF to Word:', result_one)
        print('Word to PDF:', result_two)
        print('SMOKE TEST PASSED')


if __name__ == '__main__':
    main()
