from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import fitz
from PIL import Image, ImageTk

from converter import ConversionCancelled, pdf_to_word, word_to_pdf

APP_NAME = 'PDF Word Studio'
VERSION = '1.0 Portable'


def app_directory() -> Path:
    if getattr(sys, 'frozen', False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


class PortableSettings:
    def __init__(self) -> None:
        self.root = app_directory() / 'PortableData'
        self.root.mkdir(exist_ok=True)
        self.path = self.root / 'settings.json'
        self.data = {'theme': 'dark', 'last_output': str(Path.home() / 'Documents')}
        try:
            self.data.update(json.loads(self.path.read_text(encoding='utf-8')))
        except Exception:
            pass

    def save(self) -> None:
        try:
            self.path.write_text(json.dumps(self.data, indent=2), encoding='utf-8')
        except Exception:
            pass


class PDFWordStudio(tk.Tk):
    DARK = {
        'bg': '#0F1117', 'panel': '#171A22', 'panel2': '#1E2230', 'text': '#F5F7FB',
        'muted': '#A8B0C0', 'accent': '#7C5CFC', 'accent2': '#00B8D9', 'line': '#2C3242',
        'success': '#41D39C', 'danger': '#FF6B78', 'entry': '#12151D'
    }
    LIGHT = {
        'bg': '#F5F6FA', 'panel': '#FFFFFF', 'panel2': '#EEF0F7', 'text': '#161A24',
        'muted': '#687083', 'accent': '#5B3FF2', 'accent2': '#008FB0', 'line': '#DDE1EC',
        'success': '#118A62', 'danger': '#D63C4A', 'entry': '#FFFFFF'
    }

    def __init__(self) -> None:
        super().__init__()
        self.settings = PortableSettings()
        self.palette = self.DARK if self.settings.data.get('theme') == 'dark' else self.LIGHT
        self.title(f'{APP_NAME} — {VERSION}')
        self.geometry('1040x700')
        self.minsize(920, 620)
        self.configure(bg=self.palette['bg'])
        self.protocol('WM_DELETE_WINDOW', self.on_close)

        self.cancel_event = threading.Event()
        self.worker: threading.Thread | None = None
        self.selected_pdf: Path | None = None
        self.selected_word: Path | None = None
        self.output_file: Path | None = None
        self.preview_image = None

        self._build_styles()
        self._build_ui()
        self._apply_theme()

    def _build_styles(self) -> None:
        self.style = ttk.Style(self)
        self.style.theme_use('clam')

    def _apply_theme(self) -> None:
        p = self.palette
        self.configure(bg=p['bg'])
        self.style.configure('TFrame', background=p['bg'])
        self.style.configure('Panel.TFrame', background=p['panel'])
        self.style.configure('Panel2.TFrame', background=p['panel2'])
        self.style.configure('TLabel', background=p['bg'], foreground=p['text'], font=('Segoe UI', 10))
        self.style.configure('Panel.TLabel', background=p['panel'], foreground=p['text'], font=('Segoe UI', 10))
        self.style.configure('Muted.Panel.TLabel', background=p['panel'], foreground=p['muted'], font=('Segoe UI', 9))
        self.style.configure('Title.TLabel', background=p['bg'], foreground=p['text'], font=('Segoe UI Semibold', 25))
        self.style.configure('Subtitle.TLabel', background=p['bg'], foreground=p['muted'], font=('Segoe UI', 10))
        self.style.configure('CardTitle.Panel.TLabel', background=p['panel'], foreground=p['text'], font=('Segoe UI Semibold', 15))
        self.style.configure('Accent.TButton', font=('Segoe UI Semibold', 10), foreground='white', background=p['accent'], borderwidth=0, padding=(16, 11))
        self.style.map('Accent.TButton', background=[('active', p['accent2']), ('disabled', p['line'])])
        self.style.configure('Secondary.TButton', font=('Segoe UI Semibold', 9), foreground=p['text'], background=p['panel2'], borderwidth=0, padding=(13, 9))
        self.style.map('Secondary.TButton', background=[('active', p['line'])])
        self.style.configure('Danger.TButton', font=('Segoe UI Semibold', 9), foreground='white', background=p['danger'], borderwidth=0, padding=(13, 9))
        self.style.configure('TNotebook', background=p['bg'], borderwidth=0)
        self.style.configure('TNotebook.Tab', background=p['panel2'], foreground=p['muted'], font=('Segoe UI Semibold', 10), padding=(18, 10), borderwidth=0)
        self.style.map('TNotebook.Tab', background=[('selected', p['accent'])], foreground=[('selected', 'white')])
        self.style.configure('TProgressbar', troughcolor=p['panel2'], background=p['accent'], borderwidth=0, thickness=9)
        self.style.configure('TCombobox', fieldbackground=p['entry'], background=p['entry'], foreground=p['text'], arrowcolor=p['text'], padding=8)
        self.style.configure('TRadiobutton', background=p['panel'], foreground=p['text'], font=('Segoe UI', 10))
        self.style.map('TRadiobutton', background=[('active', p['panel'])])
        for entry in getattr(self, 'entry_widgets', []):
            entry.configure(bg=p['entry'], fg=p['text'], insertbackground=p['text'], relief='flat', highlightthickness=1, highlightbackground=p['line'], highlightcolor=p['accent'])
        for text_widget in getattr(self, 'text_widgets', []):
            text_widget.configure(bg=p['entry'], fg=p['text'], insertbackground=p['text'], relief='flat', highlightthickness=1, highlightbackground=p['line'], highlightcolor=p['accent'])
        self._recolor_frames(self)

    def _recolor_frames(self, widget) -> None:
        p = self.palette
        for child in widget.winfo_children():
            if isinstance(child, tk.Frame):
                role = getattr(child, 'color_role', 'bg')
                child.configure(bg=p.get(role, p['bg']))
            if isinstance(child, tk.Label):
                role = getattr(child, 'color_role', 'bg')
                child.configure(bg=p.get(role, p['bg']), fg=p['text'])
            self._recolor_frames(child)

    def _panel(self, parent, **grid_options):
        frame = tk.Frame(parent, bg=self.palette['panel'], highlightthickness=1, highlightbackground=self.palette['line'])
        frame.color_role = 'panel'
        frame.grid(**grid_options)
        return frame

    def _build_ui(self) -> None:
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)

        header = ttk.Frame(self)
        header.grid(row=0, column=0, sticky='ew', padx=26, pady=(20, 12))
        header.columnconfigure(0, weight=1)
        ttk.Label(header, text=APP_NAME, style='Title.TLabel').grid(row=0, column=0, sticky='w')
        ttk.Label(header, text='Premium offline document converter • no installation', style='Subtitle.TLabel').grid(row=1, column=0, sticky='w', pady=(2, 0))
        self.theme_button = ttk.Button(header, text='☾  Dark mode', style='Secondary.TButton', command=self.toggle_theme)
        self.theme_button.grid(row=0, column=1, rowspan=2, sticky='e')

        content = ttk.Frame(self)
        content.grid(row=1, column=0, sticky='nsew', padx=26, pady=(0, 18))
        content.columnconfigure(0, weight=3)
        content.columnconfigure(1, weight=2)
        content.rowconfigure(0, weight=1)

        left = ttk.Frame(content)
        left.grid(row=0, column=0, sticky='nsew', padx=(0, 10))
        left.columnconfigure(0, weight=1)
        left.rowconfigure(0, weight=1)

        self.notebook = ttk.Notebook(left)
        self.notebook.grid(row=0, column=0, sticky='nsew')
        self.pdf_tab = ttk.Frame(self.notebook, style='Panel.TFrame', padding=20)
        self.word_tab = ttk.Frame(self.notebook, style='Panel.TFrame', padding=20)
        self.notebook.add(self.pdf_tab, text='PDF  →  WORD')
        self.notebook.add(self.word_tab, text='WORD  →  PDF')
        self._build_pdf_tab()
        self._build_word_tab()

        right = self._panel(content, row=0, column=1, sticky='nsew', padx=(10, 0))
        right.columnconfigure(0, weight=1)
        right.rowconfigure(1, weight=1)
        title = tk.Label(right, text='Document preview', font=('Segoe UI Semibold', 14), anchor='w')
        title.color_role = 'panel'
        title.grid(row=0, column=0, sticky='ew', padx=18, pady=(17, 10))
        self.preview_box = tk.Label(right, text='Select a PDF or Word document', font=('Segoe UI', 11), justify='center')
        self.preview_box.color_role = 'panel2'
        self.preview_box.configure(bg=self.palette['panel2'], fg=self.palette['muted'])
        self.preview_box.grid(row=1, column=0, sticky='nsew', padx=18, pady=(0, 14))

        info = tk.Frame(right, bg=self.palette['panel'])
        info.color_role = 'panel'
        info.grid(row=2, column=0, sticky='ew', padx=18, pady=(0, 14))
        info.columnconfigure(0, weight=1)
        self.file_title = tk.Label(info, text='No file selected', font=('Segoe UI Semibold', 11), anchor='w')
        self.file_title.color_role = 'panel'
        self.file_title.grid(row=0, column=0, sticky='ew')
        self.file_details = tk.Label(info, text='Files stay on this computer', font=('Segoe UI', 9), anchor='w')
        self.file_details.color_role = 'panel'
        self.file_details.configure(fg=self.palette['muted'])
        self.file_details.grid(row=1, column=0, sticky='ew', pady=(3, 0))

        bottom = ttk.Frame(self)
        bottom.grid(row=2, column=0, sticky='ew', padx=26, pady=(0, 22))
        bottom.columnconfigure(0, weight=1)
        self.status = ttk.Label(bottom, text='Ready • 100% offline', style='Subtitle.TLabel')
        self.status.grid(row=0, column=0, sticky='w')
        self.progress = ttk.Progressbar(bottom, maximum=100, mode='determinate')
        self.progress.grid(row=1, column=0, sticky='ew', pady=(7, 0))
        self.cancel_button = ttk.Button(bottom, text='Cancel', style='Danger.TButton', command=self.cancel_conversion, state='disabled')
        self.cancel_button.grid(row=0, column=1, rowspan=2, padx=(12, 0))
        self.open_output_button = ttk.Button(bottom, text='Open output folder', style='Secondary.TButton', command=self.open_output_folder, state='disabled')
        self.open_output_button.grid(row=0, column=2, rowspan=2, padx=(8, 0))

    def _labeled_entry(self, parent, row, label, variable, browse_command=None):
        ttk.Label(parent, text=label, style='Panel.TLabel').grid(row=row, column=0, sticky='w', pady=(9, 4))
        holder = tk.Frame(parent, bg=self.palette['panel'])
        holder.color_role = 'panel'
        holder.grid(row=row + 1, column=0, sticky='ew')
        holder.columnconfigure(0, weight=1)
        entry = tk.Entry(holder, textvariable=variable, font=('Segoe UI', 10))
        entry.grid(row=0, column=0, sticky='ew', ipady=9)
        self.entry_widgets.append(entry)
        if browse_command:
            ttk.Button(holder, text='Browse', style='Secondary.TButton', command=browse_command).grid(row=0, column=1, padx=(8, 0))
        return entry

    def _build_pdf_tab(self) -> None:
        self.entry_widgets = getattr(self, 'entry_widgets', [])
        tab = self.pdf_tab
        tab.columnconfigure(0, weight=1)
        ttk.Label(tab, text='Convert PDF to Word', style='CardTitle.Panel.TLabel').grid(row=0, column=0, sticky='w')
        ttk.Label(tab, text='Choose editable text or exact visual layout.', style='Muted.Panel.TLabel').grid(row=1, column=0, sticky='w', pady=(3, 10))

        self.pdf_source_var = tk.StringVar()
        self._labeled_entry(tab, 2, 'PDF file', self.pdf_source_var, self.choose_pdf)

        ttk.Label(tab, text='Conversion mode', style='Panel.TLabel').grid(row=4, column=0, sticky='w', pady=(14, 4))
        self.pdf_mode_var = tk.StringVar(value='editable')
        mode_frame = ttk.Frame(tab, style='Panel.TFrame')
        mode_frame.grid(row=5, column=0, sticky='ew')
        ttk.Radiobutton(mode_frame, text='Smart editable text', variable=self.pdf_mode_var, value='editable').grid(row=0, column=0, sticky='w')
        ttk.Radiobutton(mode_frame, text='Exact layout pages', variable=self.pdf_mode_var, value='exact').grid(row=0, column=1, sticky='w', padx=(20, 0))

        options = ttk.Frame(tab, style='Panel.TFrame')
        options.grid(row=6, column=0, sticky='ew', pady=(12, 0))
        options.columnconfigure(0, weight=1)
        options.columnconfigure(1, weight=1)
        self.page_range_var = tk.StringVar()
        self.password_var = tk.StringVar()
        ttk.Label(options, text='Pages (blank = all)', style='Panel.TLabel').grid(row=0, column=0, sticky='w')
        ttk.Label(options, text='PDF password', style='Panel.TLabel').grid(row=0, column=1, sticky='w', padx=(12, 0))
        range_entry = tk.Entry(options, textvariable=self.page_range_var, font=('Segoe UI', 10))
        range_entry.grid(row=1, column=0, sticky='ew', ipady=8)
        password_entry = tk.Entry(options, textvariable=self.password_var, show='•', font=('Segoe UI', 10))
        password_entry.grid(row=1, column=1, sticky='ew', ipady=8, padx=(12, 0))
        self.entry_widgets.extend([range_entry, password_entry])

        quality_frame = ttk.Frame(tab, style='Panel.TFrame')
        quality_frame.grid(row=7, column=0, sticky='ew', pady=(12, 0))
        ttk.Label(quality_frame, text='Image quality', style='Panel.TLabel').grid(row=0, column=0, sticky='w')
        self.pdf_quality_var = tk.StringVar(value='high')
        quality_box = ttk.Combobox(quality_frame, textvariable=self.pdf_quality_var, values=['high', 'standard'], state='readonly', width=16)
        quality_box.grid(row=0, column=1, sticky='e', padx=(12, 0))

        self.pdf_output_var = tk.StringVar()
        self._labeled_entry(tab, 8, 'Save Word document as', self.pdf_output_var, self.choose_docx_output)
        ttk.Button(tab, text='Convert PDF to Word', style='Accent.TButton', command=self.start_pdf_to_word).grid(row=10, column=0, sticky='ew', pady=(18, 0))

    def _build_word_tab(self) -> None:
        tab = self.word_tab
        tab.columnconfigure(0, weight=1)
        ttk.Label(tab, text='Convert Word to PDF', style='CardTitle.Panel.TLabel').grid(row=0, column=0, sticky='w')
        ttk.Label(tab, text='Auto mode chooses Microsoft Word, portable LibreOffice, or the built-in engine.', style='Muted.Panel.TLabel').grid(row=1, column=0, sticky='w', pady=(3, 10))

        self.word_source_var = tk.StringVar()
        self._labeled_entry(tab, 2, 'Word file', self.word_source_var, self.choose_word)

        ttk.Label(tab, text='Conversion engine', style='Panel.TLabel').grid(row=4, column=0, sticky='w', pady=(14, 4))
        self.word_engine_var = tk.StringVar(value='Auto')
        engine_box = ttk.Combobox(tab, textvariable=self.word_engine_var, values=['Auto', 'Microsoft Word', 'LibreOffice', 'Built-in'], state='readonly')
        engine_box.grid(row=5, column=0, sticky='ew')

        note = tk.Label(tab, text='Best quality: Microsoft Word or bundled LibreOffice.\nBuilt-in mode works without either and is best for ordinary text, tables, and images.', justify='left', anchor='w', font=('Segoe UI', 9))
        note.color_role = 'panel2'
        note.configure(bg=self.palette['panel2'], fg=self.palette['muted'], padx=12, pady=10)
        note.grid(row=6, column=0, sticky='ew', pady=(12, 0))

        self.pdf_output_var2 = tk.StringVar()
        self._labeled_entry(tab, 7, 'Save PDF as', self.pdf_output_var2, self.choose_pdf_output)
        ttk.Button(tab, text='Convert Word to PDF', style='Accent.TButton', command=self.start_word_to_pdf).grid(row=9, column=0, sticky='ew', pady=(18, 0))

    def choose_pdf(self) -> None:
        filename = filedialog.askopenfilename(title='Select PDF', filetypes=[('PDF documents', '*.pdf')])
        if filename:
            self.selected_pdf = Path(filename)
            self.pdf_source_var.set(filename)
            output = Path(self.settings.data.get('last_output', str(self.selected_pdf.parent))) / f'{self.selected_pdf.stem}.docx'
            self.pdf_output_var.set(str(output))
            self.show_pdf_preview(self.selected_pdf)

    def choose_word(self) -> None:
        filename = filedialog.askopenfilename(title='Select Word document', filetypes=[('Word documents', '*.docx *.doc')])
        if filename:
            self.selected_word = Path(filename)
            self.word_source_var.set(filename)
            output = Path(self.settings.data.get('last_output', str(self.selected_word.parent))) / f'{self.selected_word.stem}.pdf'
            self.pdf_output_var2.set(str(output))
            self.show_word_preview(self.selected_word)

    def choose_docx_output(self) -> None:
        filename = filedialog.asksaveasfilename(title='Save Word document', defaultextension='.docx', filetypes=[('Word document', '*.docx')])
        if filename:
            self.pdf_output_var.set(filename)

    def choose_pdf_output(self) -> None:
        filename = filedialog.asksaveasfilename(title='Save PDF', defaultextension='.pdf', filetypes=[('PDF document', '*.pdf')])
        if filename:
            self.pdf_output_var2.set(filename)

    def show_pdf_preview(self, path: Path) -> None:
        try:
            document = fitz.open(path)
            page = document.load_page(0)
            pix = page.get_pixmap(matrix=fitz.Matrix(1.1, 1.1), alpha=False)
            image = Image.frombytes('RGB', [pix.width, pix.height], pix.samples)
            image.thumbnail((360, 390))
            self.preview_image = ImageTk.PhotoImage(image)
            self.preview_box.configure(image=self.preview_image, text='', bg=self.palette['panel2'])
            self.file_title.configure(text=path.name)
            self.file_details.configure(text=f'{document.page_count} pages • {path.stat().st_size / 1024 / 1024:.2f} MB')
            document.close()
        except Exception as error:
            self.preview_box.configure(image='', text='Preview unavailable')
            self.file_title.configure(text=path.name)
            self.file_details.configure(text=str(error))

    def show_word_preview(self, path: Path) -> None:
        self.preview_image = None
        self.preview_box.configure(image='', text='W\n\nWORD DOCUMENT', font=('Segoe UI Semibold', 27), bg=self.palette['panel2'], fg=self.palette['accent2'])
        self.file_title.configure(text=path.name)
        self.file_details.configure(text=f'{path.stat().st_size / 1024:.1f} KB • ready to convert')

    def start_pdf_to_word(self) -> None:
        source = Path(self.pdf_source_var.get().strip())
        output = Path(self.pdf_output_var.get().strip())
        if not source.is_file() or source.suffix.lower() != '.pdf':
            messagebox.showerror(APP_NAME, 'Select a valid PDF file.')
            return
        if not output.name:
            messagebox.showerror(APP_NAME, 'Choose where to save the Word document.')
            return
        self._run_job(lambda: pdf_to_word(
            source, output,
            mode=self.pdf_mode_var.get(),
            page_range=self.page_range_var.get(),
            password=self.password_var.get(),
            quality=self.pdf_quality_var.get(),
            progress=self.update_progress,
            cancel_event=self.cancel_event,
        ), output)

    def start_word_to_pdf(self) -> None:
        source = Path(self.word_source_var.get().strip())
        output = Path(self.pdf_output_var2.get().strip())
        if not source.is_file() or source.suffix.lower() not in ('.docx', '.doc'):
            messagebox.showerror(APP_NAME, 'Select a valid Word document.')
            return
        if not output.name:
            messagebox.showerror(APP_NAME, 'Choose where to save the PDF.')
            return
        self._run_job(lambda: word_to_pdf(
            source, output,
            engine=self.word_engine_var.get(),
            progress=self.update_progress,
            cancel_event=self.cancel_event,
            app_dir=app_directory(),
        ), output)

    def _run_job(self, function, output: Path) -> None:
        if self.worker and self.worker.is_alive():
            return
        output.parent.mkdir(parents=True, exist_ok=True)
        self.cancel_event.clear()
        self.progress['value'] = 0
        self.cancel_button.configure(state='normal')
        self.open_output_button.configure(state='disabled')
        self.output_file = None

        def runner():
            try:
                result = function()
                self.after(0, lambda: self.job_complete(result, output))
            except ConversionCancelled:
                self.after(0, lambda: self.job_failed('Conversion cancelled.'))
            except Exception as error:
                self.after(0, lambda: self.job_failed(str(error)))

        self.worker = threading.Thread(target=runner, daemon=True)
        self.worker.start()

    def update_progress(self, value: int, message: str) -> None:
        self.after(0, lambda: self._set_progress(value, message))

    def _set_progress(self, value: int, message: str) -> None:
        self.progress['value'] = value
        self.status.configure(text=message)

    def job_complete(self, result, output: Path) -> None:
        self.output_file = output
        self.progress['value'] = 100
        self.cancel_button.configure(state='disabled')
        self.open_output_button.configure(state='normal')
        self.status.configure(text=f'Completed • {output.name}')
        self.settings.data['last_output'] = str(output.parent)
        self.settings.save()
        messagebox.showinfo(APP_NAME, f'Conversion completed successfully.\n\n{output}')

    def job_failed(self, message: str) -> None:
        self.cancel_button.configure(state='disabled')
        self.status.configure(text=message)
        if message != 'Conversion cancelled.':
            messagebox.showerror(APP_NAME, message)

    def cancel_conversion(self) -> None:
        self.cancel_event.set()
        self.status.configure(text='Stopping safely…')
        self.cancel_button.configure(state='disabled')

    def open_output_folder(self) -> None:
        if not self.output_file:
            return
        folder = self.output_file.parent
        try:
            if os.name == 'nt':
                os.startfile(folder)
            elif sys.platform == 'darwin':
                subprocess.Popen(['open', str(folder)])
            else:
                subprocess.Popen(['xdg-open', str(folder)])
        except Exception as error:
            messagebox.showerror(APP_NAME, str(error))

    def toggle_theme(self) -> None:
        dark = self.settings.data.get('theme') == 'dark'
        self.settings.data['theme'] = 'light' if dark else 'dark'
        self.settings.save()
        messagebox.showinfo(APP_NAME, 'Theme changed. Restart the portable app to apply it completely.')

    def on_close(self) -> None:
        if self.worker and self.worker.is_alive():
            if not messagebox.askyesno(APP_NAME, 'A conversion is running. Stop it and close?'):
                return
            self.cancel_event.set()
        self.destroy()


if __name__ == '__main__':
    PDFWordStudio().mainloop()
