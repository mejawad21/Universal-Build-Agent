PDF WORD STUDIO — PORTABLE WINDOWS APPLICATION

HOW TO USE THE FINISHED PORTABLE BUILD
1. Download PDF-Word-Studio-Portable-Windows.zip.
2. Extract the ZIP anywhere: Desktop, USB drive, or a normal folder.
3. Open the extracted “PDF Word Studio” folder.
4. Double-click “PDF Word Studio.exe”.
5. No installer is required.

FEATURES
- PDF to editable Word.
- PDF to exact-layout Word using page images.
- Page ranges and PDF passwords.
- Word to PDF with automatic engine selection.
- Uses Microsoft Word when installed for maximum fidelity.
- Uses the bundled/detected LibreOffice runtime when available.
- Includes a built-in portable Word renderer as a fallback.
- PDF first-page preview, progress, cancellation, and output-folder shortcut.
- Dark/light premium interface.
- Files are processed locally. The app contains no upload code.

IMPORTANT QUALITY NOTE
PDF and Word have different layout models. Editable PDF-to-Word conversion may
change complex columns, forms, tables, or fonts. Exact-layout mode keeps the
visual appearance by inserting each PDF page as an image. The built-in Word-to-
PDF renderer handles ordinary paragraphs, headings, tables, and inline images,
but Microsoft Word or LibreOffice gives the best fidelity for complex documents.

BUILD
The included GitHub Actions workflow builds both:
- Recommended portable folder ZIP.
- Compact single EXE.

The recommended portable folder is more reliable and can include LibreOffice.
