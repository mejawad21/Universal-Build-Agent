from __future__ import annotations

import html
import io
import os
import shutil
import subprocess
import sys
import tempfile
import threading
from pathlib import Path
from typing import Callable, Iterable, Optional

import fitz
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Inches, Pt
from PIL import Image as PILImage
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    Image,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

ProgressCallback = Callable[[int, str], None]


class ConversionCancelled(RuntimeError):
    pass


def _check_cancel(cancel_event: Optional[threading.Event]) -> None:
    if cancel_event is not None and cancel_event.is_set():
        raise ConversionCancelled('Conversion cancelled.')


def _progress(callback: Optional[ProgressCallback], value: int, message: str) -> None:
    if callback:
        callback(max(0, min(100, int(value))), message)


def parse_page_range(value: str, page_count: int) -> list[int]:
    if page_count <= 0:
        raise ValueError('The PDF has no pages.')
    cleaned = (value or '').strip().lower()
    if not cleaned or cleaned == 'all':
        return list(range(page_count))

    pages: set[int] = set()
    for part in cleaned.split(','):
        item = part.strip()
        if not item:
            continue
        if '-' in item:
            pieces = item.split('-', 1)
            if len(pieces) != 2 or not pieces[0].strip() or not pieces[1].strip():
                raise ValueError('Invalid range. Use a format such as 1-3,5.')
            start = int(pieces[0].strip())
            end = int(pieces[1].strip())
            if start > end:
                start, end = end, start
            for page_number in range(start, end + 1):
                if not 1 <= page_number <= page_count:
                    raise ValueError(f'Page {page_number} is outside this PDF.')
                pages.add(page_number - 1)
        else:
            page_number = int(item)
            if not 1 <= page_number <= page_count:
                raise ValueError(f'Page {page_number} is outside this PDF.')
            pages.add(page_number - 1)

    if not pages:
        raise ValueError('No pages were selected.')
    return sorted(pages)


def _authenticate_pdf(document: fitz.Document, password: str) -> None:
    if not document.needs_pass:
        return
    if not password or not document.authenticate(password):
        raise ValueError('This PDF is password protected. Enter the correct password.')


def _visible_chars(value: str) -> int:
    return sum(1 for character in value if not character.isspace())


def _render_page_to_png(page: fitz.Page, target: Path, dpi: int) -> tuple[int, int]:
    matrix = fitz.Matrix(dpi / 72.0, dpi / 72.0)
    pixmap = page.get_pixmap(matrix=matrix, alpha=False)
    pixmap.save(str(target))
    return pixmap.width, pixmap.height


def _set_document_page(section, page: fitz.Page, exact: bool) -> None:
    rect = page.rect
    section.page_width = Inches(rect.width / 72.0)
    section.page_height = Inches(rect.height / 72.0)
    margin = Inches(0.05 if exact else 0.55)
    section.top_margin = margin
    section.bottom_margin = margin
    section.left_margin = margin
    section.right_margin = margin


def _font_flags(font_name: str) -> tuple[bool, bool]:
    lower = (font_name or '').lower()
    bold = any(token in lower for token in ('bold', 'black', 'heavy', 'demi'))
    italic = any(token in lower for token in ('italic', 'oblique'))
    return bold, italic


def _add_text_page(document: Document, page: fitz.Page) -> int:
    data = page.get_text('dict', sort=True)
    sizes: list[float] = []
    for block in data.get('blocks', []):
        if block.get('type') != 0:
            continue
        for line in block.get('lines', []):
            for span in line.get('spans', []):
                text = span.get('text', '')
                if text.strip():
                    sizes.append(float(span.get('size', 10.5)))
    base_size = sorted(sizes)[len(sizes) // 2] if sizes else 10.5
    written = 0

    for block in data.get('blocks', []):
        block_type = block.get('type')
        if block_type == 1 and block.get('image'):
            try:
                image_stream = io.BytesIO(block['image'])
                paragraph = document.add_paragraph()
                paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
                run = paragraph.add_run()
                run.add_picture(image_stream, width=Inches(5.8))
                written += 1
            except Exception:
                pass
            continue
        if block_type != 0:
            continue

        lines = block.get('lines', [])
        plain_lines: list[str] = []
        block_sizes: list[float] = []
        for line in lines:
            text = ''.join(span.get('text', '') for span in line.get('spans', [])).strip()
            if text:
                plain_lines.append(text)
            for span in line.get('spans', []):
                if span.get('text', '').strip():
                    block_sizes.append(float(span.get('size', base_size)))
        block_text = ' '.join(plain_lines).strip()
        if not block_text:
            continue

        average_size = sum(block_sizes) / max(1, len(block_sizes))
        is_heading = len(block_text) <= 100 and average_size >= base_size * 1.28
        paragraph = document.add_paragraph()
        if is_heading:
            paragraph.style = 'Heading 1' if average_size >= base_size * 1.6 else 'Heading 2'
        else:
            paragraph.paragraph_format.space_after = Pt(5)
            paragraph.paragraph_format.line_spacing = 1.08

        for line_index, line in enumerate(lines):
            spans = line.get('spans', [])
            if line_index and paragraph.runs:
                paragraph.add_run(' ')
            for span in spans:
                text = span.get('text', '')
                if not text:
                    continue
                run = paragraph.add_run(text)
                run.font.size = Pt(max(8.0, min(28.0, float(span.get('size', base_size)))))
                bold, italic = _font_flags(span.get('font', ''))
                run.bold = bold
                run.italic = italic
        written += _visible_chars(block_text)
    return written


def pdf_to_word(
    pdf_path: str | Path,
    output_path: str | Path,
    mode: str = 'editable',
    page_range: str = '',
    password: str = '',
    quality: str = 'high',
    progress: Optional[ProgressCallback] = None,
    cancel_event: Optional[threading.Event] = None,
) -> dict:
    source = Path(pdf_path)
    destination = Path(output_path)
    if not source.is_file():
        raise FileNotFoundError('Select a valid PDF file.')
    if destination.suffix.lower() != '.docx':
        destination = destination.with_suffix('.docx')
    destination.parent.mkdir(parents=True, exist_ok=True)

    _progress(progress, 2, 'Opening PDF…')
    document_pdf = fitz.open(source)
    try:
        _authenticate_pdf(document_pdf, password)
        selected_pages = parse_page_range(page_range, document_pdf.page_count)
        exact_mode = mode.lower() == 'exact'
        dpi = 220 if quality.lower() == 'high' else 150
        word = Document()
        editable_pages = 0
        image_pages = 0

        with tempfile.TemporaryDirectory(prefix='pdfword-') as temp_dir:
            temp_root = Path(temp_dir)
            for position, page_index in enumerate(selected_pages):
                _check_cancel(cancel_event)
                page = document_pdf.load_page(page_index)
                percent = 8 + int((position / max(1, len(selected_pages))) * 78)
                _progress(progress, percent, f'Converting page {page_index + 1} of {document_pdf.page_count}…')

                section = word.sections[-1]
                _set_document_page(section, page, exact_mode)
                page_text = page.get_text('text', sort=True)
                use_image = exact_mode or _visible_chars(page_text) < 25

                if use_image:
                    image_path = temp_root / f'page-{page_index + 1}.png'
                    width_px, height_px = _render_page_to_png(page, image_path, dpi)
                    usable_width = section.page_width - section.left_margin - section.right_margin
                    usable_height = section.page_height - section.top_margin - section.bottom_margin
                    image_ratio = width_px / max(1, height_px)
                    page_ratio = usable_width / max(1, usable_height)
                    paragraph = word.add_paragraph()
                    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    run = paragraph.add_run()
                    if image_ratio >= page_ratio:
                        run.add_picture(str(image_path), width=usable_width)
                    else:
                        run.add_picture(str(image_path), height=usable_height)
                    image_pages += 1
                else:
                    _add_text_page(word, page)
                    editable_pages += 1

                if position + 1 < len(selected_pages):
                    word.add_page_break()

        _check_cancel(cancel_event)
        _progress(progress, 91, 'Writing Word document…')
        word.core_properties.title = source.stem
        word.core_properties.subject = 'Converted from PDF by PDF Word Studio'
        word.save(destination)
        _progress(progress, 100, 'Word document created.')
        return {
            'output': str(destination),
            'pages': len(selected_pages),
            'editable_pages': editable_pages,
            'image_pages': image_pages,
            'mode': 'Exact layout' if exact_mode else 'Editable text',
        }
    finally:
        document_pdf.close()


def _find_word_executable() -> Optional[str]:
    if os.name != 'nt':
        return None
    try:
        import win32com.client  # noqa: F401
        return 'COM'
    except Exception:
        return None


def _find_libreoffice(app_dir: Optional[Path] = None) -> Optional[Path]:
    candidates: list[Path] = []
    if app_dir:
        candidates.extend([
            app_dir / 'runtime' / 'LibreOffice' / 'program' / 'soffice.exe',
            app_dir / 'LibreOffice' / 'program' / 'soffice.exe',
        ])
    for environment_name in ('PROGRAMFILES', 'PROGRAMFILES(X86)'):
        base = os.environ.get(environment_name)
        if base:
            candidates.append(Path(base) / 'LibreOffice' / 'program' / 'soffice.exe')
    command = shutil.which('soffice') or shutil.which('libreoffice')
    if command:
        candidates.append(Path(command))
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return None


def _word_to_pdf_ms_word(source: Path, destination: Path) -> None:
    import pythoncom
    import win32com.client

    pythoncom.CoInitialize()
    word = None
    document = None
    try:
        word = win32com.client.DispatchEx('Word.Application')
        word.Visible = False
        word.DisplayAlerts = 0
        document = word.Documents.Open(str(source.resolve()), ReadOnly=True)
        document.ExportAsFixedFormat(str(destination.resolve()), 17)
    finally:
        if document is not None:
            document.Close(False)
        if word is not None:
            word.Quit()
        pythoncom.CoUninitialize()


def _word_to_pdf_libreoffice(source: Path, destination: Path, soffice: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='pdfword-lo-') as temp_dir:
        out_dir = Path(temp_dir)
        command = [
            str(soffice),
            '--headless',
            '--nologo',
            '--nodefault',
            '--nolockcheck',
            '--convert-to',
            'pdf:writer_pdf_Export',
            '--outdir',
            str(out_dir),
            str(source),
        ]
        startup = None
        creation_flags = 0
        if os.name == 'nt':
            startup = subprocess.STARTUPINFO()
            startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            creation_flags = subprocess.CREATE_NO_WINDOW
        result = subprocess.run(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=180,
            startupinfo=startup,
            creationflags=creation_flags,
            check=False,
        )
        generated = out_dir / f'{source.stem}.pdf'
        if result.returncode != 0 or not generated.is_file():
            details = (result.stderr or result.stdout or '').strip()
            raise RuntimeError(f'LibreOffice conversion failed. {details}')
        shutil.copy2(generated, destination)


def _iter_block_items(document: Document):
    from docx.table import Table as DocxTable
    from docx.text.paragraph import Paragraph as DocxParagraph

    body = document.element.body
    for child in body.iterchildren():
        if child.tag == qn('w:p'):
            yield DocxParagraph(child, document)
        elif child.tag == qn('w:tbl'):
            yield DocxTable(child, document)


def _paragraph_alignment(paragraph) -> int:
    alignment = paragraph.alignment
    if alignment == WD_ALIGN_PARAGRAPH.CENTER:
        return TA_CENTER
    if alignment == WD_ALIGN_PARAGRAPH.RIGHT:
        return TA_RIGHT
    if alignment == WD_ALIGN_PARAGRAPH.JUSTIFY:
        return TA_JUSTIFY
    return TA_LEFT


def _extract_run_images(document: Document, paragraph, temp_dir: Path) -> list[Path]:
    images: list[Path] = []
    image_index = 0
    for run in paragraph.runs:
        for blip in run._r.xpath('.//a:blip'):
            relationship_id = blip.get(qn('r:embed'))
            if not relationship_id:
                continue
            try:
                part = document.part.related_parts[relationship_id]
                extension = Path(part.partname).suffix or '.png'
                target = temp_dir / f'embedded-{id(paragraph)}-{image_index}{extension}'
                target.write_bytes(part.blob)
                images.append(target)
                image_index += 1
            except Exception:
                continue
    return images


def _paragraph_markup(paragraph) -> str:
    pieces: list[str] = []
    for run in paragraph.runs:
        value = html.escape(run.text or '').replace('\n', '<br/>')
        if not value:
            continue
        if run.bold:
            value = f'<b>{value}</b>'
        if run.italic:
            value = f'<i>{value}</i>'
        if run.underline:
            value = f'<u>{value}</u>'
        pieces.append(value)
    if not pieces:
        return html.escape(paragraph.text or '')
    return ''.join(pieces)


def _word_to_pdf_basic(source: Path, destination: Path, progress: Optional[ProgressCallback], cancel_event) -> None:
    document = Document(source)
    section = document.sections[0]
    page_width = float(section.page_width) / 914400.0 * inch
    page_height = float(section.page_height) / 914400.0 * inch
    left_margin = float(section.left_margin) / 914400.0 * inch
    right_margin = float(section.right_margin) / 914400.0 * inch
    top_margin = float(section.top_margin) / 914400.0 * inch
    bottom_margin = float(section.bottom_margin) / 914400.0 * inch

    styles = getSampleStyleSheet()
    body_style = ParagraphStyle(
        'PortableBody',
        parent=styles['BodyText'],
        fontName='Helvetica',
        fontSize=10.5,
        leading=14,
        spaceAfter=5,
        textColor=colors.HexColor('#20242C'),
    )
    heading_style = ParagraphStyle(
        'PortableHeading',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=16,
        leading=20,
        spaceAfter=8,
        textColor=colors.HexColor('#4338CA'),
    )

    story = []
    blocks = list(_iter_block_items(document))
    with tempfile.TemporaryDirectory(prefix='pdfword-docx-') as temp_dir_name:
        temp_dir = Path(temp_dir_name)
        for index, block in enumerate(blocks):
            _check_cancel(cancel_event)
            _progress(progress, 18 + int(index / max(1, len(blocks)) * 65), 'Rendering Word content…')
            from docx.table import Table as DocxTable
            from docx.text.paragraph import Paragraph as DocxParagraph

            if isinstance(block, DocxParagraph):
                image_paths = _extract_run_images(document, block, temp_dir)
                for image_path in image_paths:
                    try:
                        with PILImage.open(image_path) as image_info:
                            width, height = image_info.size
                        maximum_width = page_width - left_margin - right_margin
                        maximum_height = page_height - top_margin - bottom_margin
                        ratio = min(maximum_width / max(1, width), maximum_height / max(1, height))
                        story.append(Image(str(image_path), width=width * ratio, height=height * ratio))
                        story.append(Spacer(1, 6))
                    except Exception:
                        pass

                text = _paragraph_markup(block).strip()
                if not text:
                    story.append(Spacer(1, 5))
                    continue
                style_name = (block.style.name or '').lower() if block.style else ''
                selected_style = heading_style if 'heading' in style_name or 'title' in style_name else body_style.clone(f'body-{index}')
                selected_style.alignment = _paragraph_alignment(block)
                story.append(Paragraph(text, selected_style))

            elif isinstance(block, DocxTable):
                table_data = []
                for row in block.rows:
                    table_data.append([Paragraph(html.escape(cell.text or ''), body_style) for cell in row.cells])
                if table_data:
                    available_width = page_width - left_margin - right_margin
                    column_count = max(1, len(table_data[0]))
                    report_table = Table(table_data, colWidths=[available_width / column_count] * column_count, repeatRows=1)
                    report_table.setStyle(TableStyle([
                        ('GRID', (0, 0), (-1, -1), 0.4, colors.HexColor('#B8BECC')),
                        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#E8E7FF')),
                        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                        ('LEFTPADDING', (0, 0), (-1, -1), 5),
                        ('RIGHTPADDING', (0, 0), (-1, -1), 5),
                        ('TOPPADDING', (0, 0), (-1, -1), 5),
                        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
                    ]))
                    story.append(report_table)
                    story.append(Spacer(1, 8))

        _check_cancel(cancel_event)
        _progress(progress, 88, 'Writing PDF…')
        pdf = SimpleDocTemplate(
            str(destination),
            pagesize=(page_width, page_height),
            leftMargin=left_margin,
            rightMargin=right_margin,
            topMargin=top_margin,
            bottomMargin=bottom_margin,
            title=source.stem,
            author='PDF Word Studio',
        )
        pdf.build(story)


def word_to_pdf(
    word_path: str | Path,
    output_path: str | Path,
    engine: str = 'auto',
    progress: Optional[ProgressCallback] = None,
    cancel_event: Optional[threading.Event] = None,
    app_dir: Optional[str | Path] = None,
) -> dict:
    source = Path(word_path)
    destination = Path(output_path)
    if not source.is_file() or source.suffix.lower() not in ('.docx', '.doc'):
        raise FileNotFoundError('Select a valid Word document.')
    if destination.suffix.lower() != '.pdf':
        destination = destination.with_suffix('.pdf')
    destination.parent.mkdir(parents=True, exist_ok=True)
    _check_cancel(cancel_event)
    _progress(progress, 5, 'Choosing the best conversion engine…')

    selected = engine.lower().strip()
    portable_root = Path(app_dir) if app_dir else None
    word_available = _find_word_executable() is not None
    libreoffice_path = _find_libreoffice(portable_root)

    if selected == 'auto':
        if word_available:
            selected = 'microsoft word'
        elif libreoffice_path:
            selected = 'libreoffice'
        else:
            selected = 'built-in'

    _check_cancel(cancel_event)
    if selected in ('microsoft word', 'word'):
        if not word_available:
            raise RuntimeError('Microsoft Word is not available. Choose Auto or Built-in.')
        _progress(progress, 25, 'Converting with Microsoft Word…')
        _word_to_pdf_ms_word(source, destination)
        engine_used = 'Microsoft Word'
    elif selected == 'libreoffice':
        if not libreoffice_path:
            raise RuntimeError('LibreOffice is not available. Choose Auto or Built-in.')
        _progress(progress, 25, 'Converting with LibreOffice…')
        _word_to_pdf_libreoffice(source, destination, libreoffice_path)
        engine_used = 'LibreOffice'
    else:
        _progress(progress, 12, 'Using the built-in portable renderer…')
        _word_to_pdf_basic(source, destination, progress, cancel_event)
        engine_used = 'Built-in portable renderer'

    _check_cancel(cancel_event)
    if not destination.is_file() or destination.stat().st_size == 0:
        raise RuntimeError('The PDF could not be created.')
    _progress(progress, 100, 'PDF created successfully.')
    return {'output': str(destination), 'engine': engine_used}
