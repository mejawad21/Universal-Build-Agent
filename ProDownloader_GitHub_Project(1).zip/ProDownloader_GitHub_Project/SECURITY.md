# Security Policy

Please report vulnerabilities privately to the repository owner rather than opening a public issue. Include reproduction steps, affected Android versions, and potential impact.

The project intentionally does not implement DRM bypass, credential interception, certificate disabling, protected-platform stream extraction, or access-control circumvention.
