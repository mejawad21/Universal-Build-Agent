# Contributing

1. Fork the repository and create a focused branch.
2. Keep downloads limited to permitted direct HTTP/HTTPS sources.
3. Add or update tests for behavior changes.
4. Run `./gradlew testDebugUnitTest lintDebug assembleDebug`.
5. Open a pull request describing the change and its user impact.
