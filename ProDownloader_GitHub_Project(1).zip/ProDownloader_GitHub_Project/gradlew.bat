@echo off
setlocal EnableExtensions
set "GRADLE_VERSION=9.4.1"
if defined GRADLE_USER_HOME (set "BASE_DIR=%GRADLE_USER_HOME%\pro-downloader-bootstrap") else (set "BASE_DIR=%USERPROFILE%\.gradle\pro-downloader-bootstrap")
set "DIST_DIR=%BASE_DIR%\gradle-%GRADLE_VERSION%"
set "ZIP_FILE=%BASE_DIR%\gradle-%GRADLE_VERSION%-bin.zip"
set "URL=https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip"
set "EXPECTED=2ab2958f2a1e51120c326cad6f385153bb11ee93b3c216c5fccebfdfbb7ec6cb"
if exist "%DIST_DIR%\bin\gradle.bat" goto run
if not exist "%BASE_DIR%" mkdir "%BASE_DIR%"
if not exist "%ZIP_FILE%" powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing '%URL%' -OutFile '%ZIP_FILE%'"
for /f "tokens=*" %%H in ('powershell -NoProfile -Command "(Get-FileHash -Algorithm SHA256 '%ZIP_FILE%').Hash.ToLower()"') do set "ACTUAL=%%H"
if /I not "%ACTUAL%"=="%EXPECTED%" (
  echo Gradle checksum mismatch 1>&2
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ZIP_FILE%' '%BASE_DIR%'"
:run
call "%DIST_DIR%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
