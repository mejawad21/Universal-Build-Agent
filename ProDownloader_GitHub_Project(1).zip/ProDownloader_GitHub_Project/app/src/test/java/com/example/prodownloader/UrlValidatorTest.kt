package com.example.prodownloader

import com.example.prodownloader.util.UrlValidator
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UrlValidatorTest {
    @Test
    fun acceptsHttpAndHttpsUrls() {
        assertTrue(UrlValidator.isSupported("https://example.com/file.mp4"))
        assertTrue(UrlValidator.isSupported("http://example.com/archive.zip"))
    }

    @Test
    fun rejectsUnsupportedOrIncompleteUrls() {
        assertFalse(UrlValidator.isSupported("ftp://example.com/file.zip"))
        assertFalse(UrlValidator.isSupported("example.com/file.zip"))
        assertFalse(UrlValidator.isSupported("not a url"))
    }
}
