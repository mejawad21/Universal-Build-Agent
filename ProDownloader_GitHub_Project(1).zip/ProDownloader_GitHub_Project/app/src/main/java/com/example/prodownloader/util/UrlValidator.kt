package com.example.prodownloader.util

import java.net.URI

object UrlValidator {
    fun isSupported(value: String): Boolean = runCatching {
        val uri = URI(value.trim())
        (uri.scheme.equals("https", ignoreCase = true) ||
            uri.scheme.equals("http", ignoreCase = true)) &&
            !uri.host.isNullOrBlank()
    }.getOrDefault(false)
}
