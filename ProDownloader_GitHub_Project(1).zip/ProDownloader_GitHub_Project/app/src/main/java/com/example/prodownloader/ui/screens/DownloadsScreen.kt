package com.example.prodownloader.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.prodownloader.data.DownloadEntity
import com.example.prodownloader.data.DownloadStatus
import com.example.prodownloader.ui.components.DownloadCard

private enum class DownloadFilter { ALL, ACTIVE, COMPLETED, FAILED }

@Composable
fun DownloadsScreen(
    contentPadding: PaddingValues,
    downloads: List<DownloadEntity>,
    onPause: (String) -> Unit,
    onResume: (String) -> Unit,
    onRetry: (String) -> Unit,
    onCancel: (String) -> Unit,
    onDelete: (String) -> Unit,
    onOpen: (DownloadEntity) -> Unit,
    onShare: (DownloadEntity) -> Unit,
    onClearFinished: () -> Unit,
) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(DownloadFilter.ALL) }
    val filtered = downloads.filter { item ->
        val matchesQuery = item.fileName.contains(query, ignoreCase = true) ||
            item.url.contains(query, ignoreCase = true)
        val matchesFilter = when (filter) {
            DownloadFilter.ALL -> true
            DownloadFilter.ACTIVE -> item.status in setOf(
                DownloadStatus.QUEUED,
                DownloadStatus.DOWNLOADING,
                DownloadStatus.PAUSED,
            )
            DownloadFilter.COMPLETED -> item.status == DownloadStatus.COMPLETED
            DownloadFilter.FAILED -> item.status in setOf(
                DownloadStatus.FAILED,
                DownloadStatus.CANCELED,
            )
        }
        matchesQuery && matchesFilter
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = contentPadding.calculateTopPadding() + 18.dp,
            bottom = contentPadding.calculateBottomPadding() + 24.dp,
        ),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text("Downloads", style = androidx.compose.material3.MaterialTheme.typography.headlineMedium)
                OutlinedButton(onClick = onClearFinished) { Text("Clear finished") }
            }
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                label = { Text("Search downloads") },
                singleLine = true,
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DownloadFilter.entries.forEach { value ->
                    FilterChip(
                        selected = filter == value,
                        onClick = { filter = value },
                        label = { Text(value.name.lowercase().replaceFirstChar { it.uppercase() }) },
                    )
                }
            }
        }

        if (filtered.isEmpty()) {
            item {
                Column(Modifier.padding(vertical = 32.dp)) {
                    Text("Nothing here")
                    Text("Your matching downloads will appear on this screen.")
                }
            }
        } else {
            items(filtered, key = { it.id }) { item ->
                DownloadCard(
                    item = item,
                    onPause = { onPause(item.id) },
                    onResume = { onResume(item.id) },
                    onRetry = { onRetry(item.id) },
                    onCancel = { onCancel(item.id) },
                    onDelete = { onDelete(item.id) },
                    onOpen = { onOpen(item) },
                    onShare = { onShare(item) },
                )
            }
        }
    }
}
