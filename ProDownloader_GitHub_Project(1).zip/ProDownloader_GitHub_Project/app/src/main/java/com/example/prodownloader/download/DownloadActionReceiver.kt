package com.example.prodownloader.download

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.prodownloader.ProDownloaderApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class DownloadActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra(EXTRA_ID) ?: return
        val pending = goAsync()
        val scheduler = (context.applicationContext as ProDownloaderApplication).container.scheduler
        CoroutineScope(Dispatchers.IO).launch {
            try {
                when (intent.action) {
                    ACTION_PAUSE -> scheduler.pause(id)
                    ACTION_CANCEL -> scheduler.cancel(id)
                }
            } finally {
                pending.finish()
            }
        }
    }

    companion object {
        const val EXTRA_ID = "download_id"
        const val ACTION_PAUSE = "com.example.prodownloader.PAUSE"
        const val ACTION_CANCEL = "com.example.prodownloader.CANCEL"
    }
}
