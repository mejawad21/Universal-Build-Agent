package com.example.prodownloader.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF9C82FF),
    onPrimary = Color(0xFF1C0E52),
    primaryContainer = Color(0xFF332269),
    secondary = Color(0xFF58D7C6),
    background = Color(0xFF0B0D12),
    surface = Color(0xFF121620),
    surfaceVariant = Color(0xFF1B2130),
    onBackground = Color(0xFFF2F3F8),
    onSurface = Color(0xFFF2F3F8),
    error = Color(0xFFFF6B78),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF5D3FD3),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE7DFFF),
    secondary = Color(0xFF00796B),
    background = Color(0xFFF6F7FB),
    surface = Color.White,
    surfaceVariant = Color(0xFFE8EAF2),
    onBackground = Color(0xFF171821),
    onSurface = Color(0xFF171821),
    error = Color(0xFFBA1A1A),
)

@Composable
fun ProDownloaderTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        content = content,
    )
}
