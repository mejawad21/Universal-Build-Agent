package com.example.prodownloader.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.CloudDownload
import androidx.compose.material.icons.outlined.ContentPaste
import androidx.compose.material.icons.outlined.HighQuality
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.prodownloader.data.DownloadEntity
import com.example.prodownloader.data.DownloadStatus
import com.example.prodownloader.util.formatBytes

@Composable
fun HomeScreen(
    contentPadding: PaddingValues,
    downloads: List<DownloadEntity>,
    defaultWifiOnly: Boolean,
    onAdd: (String, String?, Boolean) -> Unit,
    onOpenDownloads: () -> Unit,
) {
    var url by remember { mutableStateOf("") }
    var fileName by remember { mutableStateOf("") }
    var wifiOnly by remember(defaultWifiOnly) { mutableStateOf(defaultWifiOnly) }
    val clipboard = LocalClipboardManager.current
    val active = downloads.count {
        it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.QUEUED
    }
    val completed = downloads.count { it.status == DownloadStatus.COMPLETED }
    val totalBytes = downloads.filter { it.status == DownloadStatus.COMPLETED }.sumOf { it.totalBytes.coerceAtLeast(0L) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 20.dp,
            end = 20.dp,
            top = contentPadding.calculateTopPadding() + 20.dp,
            bottom = contentPadding.calculateBottomPadding() + 24.dp,
        ),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Text("Pro Downloader", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Fast multi-download manager for direct file links",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                ),
            ) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.CloudDownload, contentDescription = null)
                        Text(
                            "  Add direct downloads",
                            style = MaterialTheme.typography.titleLarge,
                        )
                    }
                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(
                        value = url,
                        onValueChange = { url = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Direct file URL(s), one per line") },
                        minLines = 3,
                        maxLines = 6,
                        trailingIcon = {
                            IconButton(
                                onClick = {
                                    clipboard.getText()?.text?.let { url = it }
                                },
                            ) {
                                Icon(Icons.Outlined.ContentPaste, contentDescription = "Paste")
                            }
                        },
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = fileName,
                        onValueChange = { fileName = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("File name (optional for one URL)") },
                        singleLine = true,
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column {
                            Text("Wi-Fi only", fontWeight = FontWeight.SemiBold)
                            Text(
                                "Wait for an unmetered network",
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                        Switch(checked = wifiOnly, onCheckedChange = { wifiOnly = it })
                    }
                    Spacer(Modifier.height(14.dp))
                    Button(
                        onClick = {
                            onAdd(url, fileName.takeIf { it.isNotBlank() }, wifiOnly)
                            if (url.isNotBlank()) {
                                url = ""
                                fileName = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Icon(Icons.Outlined.Bolt, contentDescription = null)
                        Text("  Add to download queue")
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                StatCard("Active", active.toString(), Modifier.weight(1f))
                StatCard("Completed", completed.toString(), Modifier.weight(1f))
                StatCard("Saved", formatBytes(totalBytes), Modifier.weight(1f))
            }
        }

        item {
            Card {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Outlined.HighQuality, contentDescription = null)
                    Column(Modifier.padding(start = 12.dp)) {
                        Text("Original source quality", fontWeight = FontWeight.SemiBold)
                        Text(
                            "Files are saved byte-for-byte from the supplied URL—no recompression.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Recent", style = MaterialTheme.typography.titleLarge)
                OutlinedButton(onClick = onOpenDownloads) { Text("View all") }
            }
        }

        if (downloads.isEmpty()) {
            item {
                Text(
                    "No downloads yet. Paste one or more permitted direct file URLs above.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        } else {
            items(downloads.take(4), key = { it.id }) { item ->
                Card {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                item.fileName,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                item.status.name.lowercase().replaceFirstChar { it.uppercase() },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Text(
                            if (item.totalBytes > 0) formatBytes(item.totalBytes) else "—",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(value, style = MaterialTheme.typography.titleMedium)
            Text(
                label,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
