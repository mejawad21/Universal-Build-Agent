package com.example.prodownloader.core

import android.content.Context
import androidx.room.Room
import com.example.prodownloader.data.AppDatabase
import com.example.prodownloader.data.DownloadRepository
import com.example.prodownloader.data.SettingsStore
import com.example.prodownloader.download.DownloadScheduler
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    val database: AppDatabase = Room.databaseBuilder(
        appContext,
        AppDatabase::class.java,
        "pro_downloader.db",
    ).build()

    val repository = DownloadRepository(database.downloadDao())
    val settings = SettingsStore(appContext)

    val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    val scheduler = DownloadScheduler(
        context = appContext,
        repository = repository,
    )
}
