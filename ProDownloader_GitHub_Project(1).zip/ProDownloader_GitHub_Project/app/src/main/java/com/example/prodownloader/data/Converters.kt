package com.example.prodownloader.data

import androidx.room.TypeConverter

class Converters {
    @TypeConverter
    fun statusToString(status: DownloadStatus): String = status.name

    @TypeConverter
    fun stringToStatus(value: String): DownloadStatus = DownloadStatus.valueOf(value)
}
