package com.example.prodownloader.ui.screens

import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(
    contentPadding: PaddingValues,
    wifiOnly: Boolean,
    darkTheme: Boolean,
    autoRetry: Boolean,
    onWifiOnlyChange: (Boolean) -> Unit,
    onDarkThemeChange: (Boolean) -> Unit,
    onAutoRetryChange: (Boolean) -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = contentPadding.calculateTopPadding() + 18.dp,
            bottom = contentPadding.calculateBottomPadding() + 24.dp,
        ),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { Text("Settings", style = MaterialTheme.typography.headlineMedium) }
        item {
            SettingToggle(
                icon = { Icon(Icons.Outlined.Wifi, contentDescription = null) },
                title = "Wi-Fi only by default",
                subtitle = "New downloads wait for an unmetered connection",
                checked = wifiOnly,
                onCheckedChange = onWifiOnlyChange,
            )
        }
        item {
            SettingToggle(
                icon = { Icon(Icons.Outlined.Refresh, contentDescription = null) },
                title = "Automatic retry",
                subtitle = "Retry temporary network failures up to two times",
                checked = autoRetry,
                onCheckedChange = onAutoRetryChange,
            )
        }
        item {
            SettingToggle(
                icon = { Icon(Icons.Outlined.DarkMode, contentDescription = null) },
                title = "Dark theme",
                subtitle = "Use the premium dark interface",
                checked = darkTheme,
                onCheckedChange = onDarkThemeChange,
            )
        }
        item {
            InfoCard(
                icon = { Icon(Icons.Outlined.Folder, contentDescription = null) },
                title = "Storage",
                body = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    "Completed files are published to Downloads/ProDownloader."
                } else {
                    "Completed files are stored in the app download folder and remain shareable."
                },
            )
        }
        item {
            InfoCard(
                icon = { Icon(Icons.Outlined.Info, contentDescription = null) },
                title = "Permitted sources only",
                body = "This app downloads direct HTTP/HTTPS files provided by servers that permit downloading. It does not bypass DRM, paywalls, authentication, or platform restrictions.",
            )
        }
        item {
            InfoCard(
                icon = { Icon(Icons.Outlined.Info, contentDescription = null) },
                title = "Version 1.0.0",
                body = "Kotlin, Jetpack Compose, Room, WorkManager, and OkHttp.",
            )
        }
    }
}

@Composable
private fun SettingToggle(
    icon: @Composable () -> Unit,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Card {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            icon()
            Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(checked = checked, onCheckedChange = onCheckedChange)
        }
    }
}

@Composable
private fun InfoCard(
    icon: @Composable () -> Unit,
    title: String,
    body: String,
) {
    Card {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.Top,
        ) {
            icon()
            Column(Modifier.padding(start = 14.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(
                    body,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
