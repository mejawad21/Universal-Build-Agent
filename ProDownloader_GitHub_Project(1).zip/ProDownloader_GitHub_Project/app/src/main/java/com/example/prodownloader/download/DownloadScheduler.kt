package com.example.prodownloader.download

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.example.prodownloader.data.DownloadEntity
import com.example.prodownloader.data.DownloadRepository
import com.example.prodownloader.data.DownloadStatus
import com.example.prodownloader.util.FileNameResolver
import java.util.UUID
import java.util.concurrent.TimeUnit

class DownloadScheduler(
    private val context: Context,
    private val repository: DownloadRepository,
) {
    private val workManager = WorkManager.getInstance(context)

    suspend fun enqueueNew(url: String, customFileName: String?, wifiOnly: Boolean): String {
        val id = UUID.randomUUID().toString()
        val fileName = customFileName
            ?.let(FileNameResolver::sanitize)
            ?.takeIf(String::isNotBlank)
            ?: FileNameResolver.fromUrl(url)

        repository.upsert(
            DownloadEntity(
                id = id,
                url = url.trim(),
                fileName = fileName,
                wifiOnly = wifiOnly,
            ),
        )
        enqueueExisting(id, wifiOnly)
        return id
    }

    suspend fun enqueueExisting(id: String, wifiOnly: Boolean? = null) {
        val item = repository.getById(id) ?: return
        val useWifiOnly = wifiOnly ?: item.wifiOnly
        repository.upsert(
            item.copy(
                status = DownloadStatus.QUEUED,
                errorMessage = null,
                wifiOnly = useWifiOnly,
                updatedAt = System.currentTimeMillis(),
            ),
        )

        val constraints = Constraints.Builder()
            .setRequiredNetworkType(
                if (useWifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED,
            )
            .build()

        val request = OneTimeWorkRequestBuilder<FileDownloadWorker>()
            .setInputData(Data.Builder().putString(FileDownloadWorker.KEY_ID, id).build())
            .setConstraints(constraints)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
            .addTag(TAG_DOWNLOAD)
            .addTag(tagFor(id))
            .build()

        workManager.enqueueUniqueWork(
            workName(id),
            ExistingWorkPolicy.REPLACE,
            request,
        )
    }

    suspend fun pause(id: String) {
        repository.updateStatus(id, DownloadStatus.PAUSED)
        workManager.cancelUniqueWork(workName(id))
    }

    suspend fun resume(id: String) {
        enqueueExisting(id)
    }

    suspend fun cancel(id: String) {
        repository.updateStatus(id, DownloadStatus.CANCELED)
        workManager.cancelUniqueWork(workName(id))
        StorageHelper.deletePartial(context, id)
    }

    suspend fun retry(id: String) {
        enqueueExisting(id)
    }

    suspend fun delete(id: String) {
        workManager.cancelUniqueWork(workName(id))
        StorageHelper.deletePartial(context, id)
        repository.delete(id)
    }

    companion object {
        private const val TAG_DOWNLOAD = "pro_downloader"
        private fun workName(id: String) = "download_$id"
        private fun tagFor(id: String) = "download_tag_$id"
    }
}
