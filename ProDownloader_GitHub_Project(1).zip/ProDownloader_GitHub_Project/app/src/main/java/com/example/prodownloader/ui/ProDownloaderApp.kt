package com.example.prodownloader.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.prodownloader.ui.screens.DownloadsScreen
import com.example.prodownloader.ui.screens.HomeScreen
import com.example.prodownloader.ui.screens.SettingsScreen
import com.example.prodownloader.ui.theme.ProDownloaderTheme

@Composable
fun ProDownloaderApp(viewModel: MainViewModel) {
    val darkTheme by viewModel.darkTheme.collectAsStateWithLifecycle()
    val downloads by viewModel.downloads.collectAsStateWithLifecycle()
    val wifiOnly by viewModel.wifiOnly.collectAsStateWithLifecycle()
    val autoRetry by viewModel.autoRetry.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        viewModel.messages.collect { snackbar.showSnackbar(it) }
    }

    ProDownloaderTheme(darkTheme = darkTheme) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = {
                NavigationBar {
                    val items = listOf(
                        Triple("Home", Icons.Outlined.Home, 0),
                        Triple("Downloads", Icons.Outlined.Download, 1),
                        Triple("Settings", Icons.Outlined.Settings, 2),
                    )
                    items.forEach { (label, icon, index) ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label) },
                        )
                    }
                }
            },
        ) { padding ->
            when (selectedTab) {
                0 -> HomeScreen(
                    contentPadding = padding,
                    downloads = downloads,
                    defaultWifiOnly = wifiOnly,
                    onAdd = viewModel::addDownloads,
                    onOpenDownloads = { selectedTab = 1 },
                )
                1 -> DownloadsScreen(
                    contentPadding = padding,
                    downloads = downloads,
                    onPause = viewModel::pause,
                    onResume = viewModel::resume,
                    onRetry = viewModel::retry,
                    onCancel = viewModel::cancel,
                    onDelete = viewModel::delete,
                    onOpen = viewModel::open,
                    onShare = viewModel::share,
                    onClearFinished = viewModel::clearFinished,
                )
                else -> SettingsScreen(
                    contentPadding = padding,
                    wifiOnly = wifiOnly,
                    darkTheme = darkTheme,
                    autoRetry = autoRetry,
                    onWifiOnlyChange = viewModel::setWifiOnly,
                    onDarkThemeChange = viewModel::setDarkTheme,
                    onAutoRetryChange = viewModel::setAutoRetry,
                )
            }
        }
    }
}
