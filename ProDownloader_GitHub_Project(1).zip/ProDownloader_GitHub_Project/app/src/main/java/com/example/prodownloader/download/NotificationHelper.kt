package com.example.prodownloader.download

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.ForegroundInfo
import com.example.prodownloader.MainActivity
import com.example.prodownloader.R

object NotificationHelper {
    private const val CHANNEL_ID = "downloads"

    fun foreground(
        context: Context,
        id: String,
        fileName: String,
        progress: Int,
        indeterminate: Boolean,
    ): ForegroundInfo {
        ensureChannel(context)
        val openIntent = PendingIntent.getActivity(
            context,
            id.hashCode(),
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val pauseIntent = actionIntent(context, id, DownloadActionReceiver.ACTION_PAUSE, 1)
        val cancelIntent = actionIntent(context, id, DownloadActionReceiver.ACTION_CANCEL, 2)

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_download_notification)
            .setContentTitle(fileName)
            .setContentText(if (indeterminate) "Downloading…" else "$progress% downloaded")
            .setContentIntent(openIntent)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setProgress(100, progress, indeterminate)
            .addAction(0, "Pause", pauseIntent)
            .addAction(0, "Cancel", cancelIntent)
            .build()

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(
                notificationId(id),
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
            )
        } else {
            ForegroundInfo(notificationId(id), notification)
        }
    }

    fun completed(context: Context, id: String, fileName: String) {
        ensureChannel(context)
        val openIntent = PendingIntent.getActivity(
            context,
            id.hashCode(),
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_download_notification)
            .setContentTitle("Download complete")
            .setContentText(fileName)
            .setContentIntent(openIntent)
            .setAutoCancel(true)
            .build()
        runCatching {
            NotificationManagerCompat.from(context).notify(notificationId(id) + 1, notification)
        }
    }

    private fun actionIntent(
        context: Context,
        id: String,
        action: String,
        requestOffset: Int,
    ): PendingIntent = PendingIntent.getBroadcast(
        context,
        id.hashCode() + requestOffset,
        Intent(context, DownloadActionReceiver::class.java).apply {
            this.action = action
            putExtra(DownloadActionReceiver.EXTRA_ID, id)
        },
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "Downloads",
                    NotificationManager.IMPORTANCE_LOW,
                ).apply {
                    description = "Download progress and completion"
                },
            )
        }
    }

    private fun notificationId(id: String): Int = id.hashCode() and 0x7fffffff
}
