package com.example.prodownloader.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.prodownloader.core.AppContainer
import com.example.prodownloader.data.DownloadEntity
import com.example.prodownloader.util.IntentUtils
import com.example.prodownloader.util.UrlValidator
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(
    application: Application,
    private val container: AppContainer,
) : AndroidViewModel(application) {

    val downloads = container.repository.observeAll().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = emptyList(),
    )
    val wifiOnly = container.settings.wifiOnly
    val darkTheme = container.settings.darkTheme
    val autoRetry = container.settings.autoRetry

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val messages = _messages.asSharedFlow()

    fun addDownloads(rawUrls: String, customName: String?, wifiOnly: Boolean) {
        val urls = rawUrls
            .lineSequence()
            .map(String::trim)
            .filter(String::isNotBlank)
            .distinct()
            .toList()

        if (urls.isEmpty()) {
            _messages.tryEmit("Paste at least one direct HTTP or HTTPS file URL")
            return
        }

        val validUrls = urls.filter(UrlValidator::isSupported)
        val invalidCount = urls.size - validUrls.size
        if (validUrls.isEmpty()) {
            _messages.tryEmit("No valid direct HTTP or HTTPS file URLs found")
            return
        }

        viewModelScope.launch {
            validUrls.forEach { url ->
                container.scheduler.enqueueNew(
                    url = url,
                    customFileName = customName?.takeIf { validUrls.size == 1 },
                    wifiOnly = wifiOnly,
                )
            }
            val added = validUrls.size
            val message = buildString {
                append(if (added == 1) "Download added to queue" else "$added downloads added to queue")
                if (invalidCount > 0) append("; $invalidCount invalid link(s) ignored")
            }
            _messages.emit(message)
        }
    }

    fun pause(id: String) = viewModelScope.launch { container.scheduler.pause(id) }
    fun resume(id: String) = viewModelScope.launch { container.scheduler.resume(id) }
    fun retry(id: String) = viewModelScope.launch { container.scheduler.retry(id) }
    fun cancel(id: String) = viewModelScope.launch { container.scheduler.cancel(id) }

    fun delete(id: String) = viewModelScope.launch {
        container.scheduler.delete(id)
        _messages.emit("Download removed")
    }

    fun clearFinished() = viewModelScope.launch {
        container.repository.clearFinished()
        _messages.emit("Finished items cleared")
    }

    fun open(download: DownloadEntity) {
        val uri = download.localUri ?: return
        IntentUtils.open(getApplication(), uri, download.mimeType)
    }

    fun share(download: DownloadEntity) {
        val uri = download.localUri ?: return
        IntentUtils.share(getApplication(), uri, download.mimeType)
    }

    fun setWifiOnly(value: Boolean) = container.settings.setWifiOnly(value)
    fun setDarkTheme(value: Boolean) = container.settings.setDarkTheme(value)
    fun setAutoRetry(value: Boolean) = container.settings.setAutoRetry(value)
}

class MainViewModelFactory(
    private val application: Application,
    private val container: AppContainer,
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return MainViewModel(application, container) as T
    }
}
