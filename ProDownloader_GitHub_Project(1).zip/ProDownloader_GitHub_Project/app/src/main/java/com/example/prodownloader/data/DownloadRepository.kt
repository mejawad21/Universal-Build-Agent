package com.example.prodownloader.data

import kotlinx.coroutines.flow.Flow

class DownloadRepository(
    private val dao: DownloadDao,
) {
    fun observeAll(): Flow<List<DownloadEntity>> = dao.observeAll()

    suspend fun getById(id: String): DownloadEntity? = dao.getById(id)

    suspend fun upsert(download: DownloadEntity) = dao.upsert(download)

    suspend fun updateStatus(
        id: String,
        status: DownloadStatus,
        errorMessage: String? = null,
    ) = dao.updateStatus(id, status, errorMessage)

    suspend fun updateProgress(
        id: String,
        bytesDownloaded: Long,
        totalBytes: Long,
        speed: Long,
        eta: Long,
    ) = dao.updateProgress(id, bytesDownloaded, totalBytes, speed, eta)

    suspend fun updateMetadata(id: String, fileName: String, mimeType: String?) =
        dao.updateMetadata(id, fileName, mimeType)

    suspend fun markCompleted(id: String, localUri: String, size: Long) =
        dao.markCompleted(
            id = id,
            localUri = localUri,
            bytesDownloaded = size,
            totalBytes = size,
        )

    suspend fun delete(id: String) = dao.delete(id)

    suspend fun clearFinished() = dao.clearFinished()
}
