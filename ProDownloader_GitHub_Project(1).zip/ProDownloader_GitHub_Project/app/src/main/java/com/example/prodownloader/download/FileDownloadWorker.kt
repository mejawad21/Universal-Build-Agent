package com.example.prodownloader.download

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.prodownloader.ProDownloaderApplication
import com.example.prodownloader.data.DownloadStatus
import com.example.prodownloader.util.FileNameResolver
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.IOException
import java.io.RandomAccessFile
import kotlin.math.max

class FileDownloadWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {

    private val container = (appContext.applicationContext as ProDownloaderApplication).container
    private val repository = container.repository
    private val client = container.httpClient

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val id = inputData.getString(KEY_ID) ?: return@withContext Result.failure()
        var item = repository.getById(id) ?: return@withContext Result.failure()
        if (item.status == DownloadStatus.CANCELED) return@withContext Result.success()

        repository.updateStatus(id, DownloadStatus.DOWNLOADING)
        setForeground(NotificationHelper.foreground(applicationContext, id, item.fileName, 0, true))

        val partial = StorageHelper.partialFile(applicationContext, id)
        var existing = partial.takeIf { it.exists() }?.length() ?: 0L

        try {
            val requestBuilder = Request.Builder()
                .url(item.url)
                .header("User-Agent", "ProDownloader/1.0 Android")
            if (existing > 0L) requestBuilder.header("Range", "bytes=$existing-")

            client.newCall(requestBuilder.build()).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IOException("Server returned HTTP ${response.code}")
                }
                val body = response.body ?: throw IOException("Empty response body")
                val acceptsResume = response.code == 206
                if (existing > 0L && !acceptsResume) {
                    partial.delete()
                    existing = 0L
                }

                val responseName = FileNameResolver.fromContentDisposition(
                    response.header("Content-Disposition"),
                )
                val finalName = responseName ?: item.fileName
                val mimeType = response.header("Content-Type")
                    ?.substringBefore(';')
                    ?.trim()
                    ?.takeIf { it.isNotBlank() }
                    ?: FileNameResolver.mimeFromName(finalName)
                repository.updateMetadata(id, finalName, mimeType)
                item = item.copy(fileName = finalName, mimeType = mimeType)

                val responseLength = body.contentLength()
                val total = if (responseLength >= 0L) existing + responseLength else -1L

                RandomAccessFile(partial, "rw").use { output ->
                    if (existing == 0L) output.setLength(0L)
                    output.seek(existing)

                    body.byteStream().use { input ->
                        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                        var downloaded = existing
                        var lastBytes = downloaded
                        var lastTimestamp = System.currentTimeMillis()
                        var lastDatabaseUpdate = 0L

                        while (true) {
                            if (isStopped) throw CancellationException("Download stopped")
                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            downloaded += read

                            val now = System.currentTimeMillis()
                            if (now - lastDatabaseUpdate >= 350L) {
                                val elapsed = max(now - lastTimestamp, 1L)
                                val speed = ((downloaded - lastBytes) * 1000L) / elapsed
                                val eta = if (total > 0L && speed > 0L) {
                                    (total - downloaded).coerceAtLeast(0L) / speed
                                } else {
                                    -1L
                                }
                                repository.updateProgress(id, downloaded, total, speed, eta)
                                val percent = if (total > 0L) {
                                    ((downloaded * 100L) / total).toInt().coerceIn(0, 100)
                                } else {
                                    0
                                }
                                setForeground(
                                    NotificationHelper.foreground(
                                        applicationContext,
                                        id,
                                        finalName,
                                        percent,
                                        total <= 0L,
                                    ),
                                )
                                lastBytes = downloaded
                                lastTimestamp = now
                                lastDatabaseUpdate = now
                            }
                        }
                    }
                }

                val size = partial.length()
                val uri = StorageHelper.publish(
                    context = applicationContext,
                    partial = partial,
                    fileName = finalName,
                    mimeType = mimeType,
                )
                repository.markCompleted(id, uri.toString(), size)
                NotificationHelper.completed(applicationContext, id, finalName)
                Result.success()
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Throwable) {
            val latest = repository.getById(id)
            if (latest?.status == DownloadStatus.PAUSED || latest?.status == DownloadStatus.CANCELED) {
                return@withContext Result.success()
            }

            val message = error.message ?: "Download failed"
            val canRetry = container.settings.autoRetry.value && runAttemptCount < 2
            if (canRetry) {
                repository.updateStatus(id, DownloadStatus.QUEUED, message)
                Result.retry()
            } else {
                repository.updateStatus(id, DownloadStatus.FAILED, message)
                Result.failure()
            }
        }
    }

    companion object {
        const val KEY_ID = "download_id"
        private const val DEFAULT_BUFFER_SIZE = 64 * 1024
    }
}
