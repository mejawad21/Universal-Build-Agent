package com.example.prodownloader.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private val _wifiOnly = MutableStateFlow(prefs.getBoolean(KEY_WIFI_ONLY, false))
    val wifiOnly: StateFlow<Boolean> = _wifiOnly.asStateFlow()

    private val _darkTheme = MutableStateFlow(prefs.getBoolean(KEY_DARK_THEME, true))
    val darkTheme: StateFlow<Boolean> = _darkTheme.asStateFlow()

    private val _autoRetry = MutableStateFlow(prefs.getBoolean(KEY_AUTO_RETRY, true))
    val autoRetry: StateFlow<Boolean> = _autoRetry.asStateFlow()

    fun setWifiOnly(value: Boolean) {
        prefs.edit().putBoolean(KEY_WIFI_ONLY, value).apply()
        _wifiOnly.value = value
    }

    fun setDarkTheme(value: Boolean) {
        prefs.edit().putBoolean(KEY_DARK_THEME, value).apply()
        _darkTheme.value = value
    }

    fun setAutoRetry(value: Boolean) {
        prefs.edit().putBoolean(KEY_AUTO_RETRY, value).apply()
        _autoRetry.value = value
    }

    companion object {
        private const val KEY_WIFI_ONLY = "wifi_only"
        private const val KEY_DARK_THEME = "dark_theme"
        private const val KEY_AUTO_RETRY = "auto_retry"
    }
}
