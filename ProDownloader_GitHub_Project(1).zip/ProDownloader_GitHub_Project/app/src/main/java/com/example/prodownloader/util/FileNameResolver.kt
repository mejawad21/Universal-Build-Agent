package com.example.prodownloader.util

import android.webkit.MimeTypeMap
import java.net.URI
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

object FileNameResolver {
    fun fromUrl(url: String): String {
        val raw = runCatching { URI(url).path.substringAfterLast('/') }.getOrDefault("")
        val decoded = runCatching {
            URLDecoder.decode(raw, StandardCharsets.UTF_8.name())
        }.getOrDefault(raw)

        return sanitize(decoded).ifBlank {
            "download_${System.currentTimeMillis()}.bin"
        }
    }

    fun fromContentDisposition(header: String?): String? {
        if (header.isNullOrBlank()) return null
        val utf8 = Regex("filename\\*=UTF-8''([^;]+)", RegexOption.IGNORE_CASE)
            .find(header)
            ?.groupValues
            ?.getOrNull(1)
            ?.let { URLDecoder.decode(it, StandardCharsets.UTF_8.name()) }
        val regular = Regex("filename=\\\"?([^\\\";]+)\\\"?", RegexOption.IGNORE_CASE)
            .find(header)
            ?.groupValues
            ?.getOrNull(1)
        return sanitize(utf8 ?: regular.orEmpty()).takeIf { it.isNotBlank() }
    }

    fun sanitize(value: String): String = value
        .replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_")
        .trim()
        .take(180)

    fun mimeFromName(fileName: String): String {
        val extension = fileName.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
            ?: "application/octet-stream"
    }
}
