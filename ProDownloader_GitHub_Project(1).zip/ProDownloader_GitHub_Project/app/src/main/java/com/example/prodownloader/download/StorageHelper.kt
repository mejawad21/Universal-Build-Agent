package com.example.prodownloader.download

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.example.prodownloader.util.FileNameResolver
import java.io.File
import java.io.FileOutputStream

object StorageHelper {
    private const val FOLDER = "ProDownloader"

    fun partialFile(context: Context, id: String): File {
        val directory = File(
            context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
            "$FOLDER/.partial",
        ).apply { mkdirs() }
        return File(directory, "$id.part")
    }

    fun deletePartial(context: Context, id: String) {
        partialFile(context, id).delete()
    }

    fun publish(
        context: Context,
        partial: File,
        fileName: String,
        mimeType: String,
    ): Uri {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            publishToMediaStore(context, partial, fileName, mimeType)
        } else {
            publishToAppFolder(context, partial, fileName)
        }
    }

    private fun publishToMediaStore(
        context: Context,
        partial: File,
        fileName: String,
        mimeType: String,
    ): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, fileName)
            put(MediaStore.Downloads.MIME_TYPE, mimeType)
            put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/$FOLDER")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val uri = checkNotNull(
            resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values),
        ) { "Unable to create destination file" }

        try {
            resolver.openOutputStream(uri, "w").use { output ->
                checkNotNull(output) { "Unable to open destination file" }
                partial.inputStream().use { input -> input.copyTo(output) }
            }
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            partial.delete()
            return uri
        } catch (error: Throwable) {
            resolver.delete(uri, null, null)
            throw error
        }
    }

    private fun publishToAppFolder(
        context: Context,
        partial: File,
        fileName: String,
    ): Uri {
        val directory = File(
            context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
            FOLDER,
        ).apply { mkdirs() }
        val target = uniqueFile(directory, FileNameResolver.sanitize(fileName))
        partial.inputStream().use { input ->
            FileOutputStream(target).use { output -> input.copyTo(output) }
        }
        partial.delete()
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.files",
            target,
        )
    }

    private fun uniqueFile(directory: File, fileName: String): File {
        val safe = fileName.ifBlank { "download.bin" }
        var candidate = File(directory, safe)
        if (!candidate.exists()) return candidate

        val extension = safe.substringAfterLast('.', "")
        val stem = if (extension.isBlank()) safe else safe.removeSuffix(".$extension")
        var index = 1
        while (candidate.exists()) {
            val suffix = if (extension.isBlank()) "" else ".$extension"
            candidate = File(directory, "$stem ($index)$suffix")
            index++
        }
        return candidate
    }
}
