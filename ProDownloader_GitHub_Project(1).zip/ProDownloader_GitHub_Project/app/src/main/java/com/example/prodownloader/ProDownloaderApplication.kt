package com.example.prodownloader

import android.app.Application
import com.example.prodownloader.core.AppContainer

class ProDownloaderApplication : Application() {
    val container: AppContainer by lazy { AppContainer(this) }
}
