package com.example.prodownloader.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): DownloadEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(download: DownloadEntity)

    @Query(
        """
        UPDATE downloads
        SET status = :status,
            errorMessage = :errorMessage,
            updatedAt = :updatedAt
        WHERE id = :id
        """,
    )
    suspend fun updateStatus(
        id: String,
        status: DownloadStatus,
        errorMessage: String? = null,
        updatedAt: Long = System.currentTimeMillis(),
    )

    @Query(
        """
        UPDATE downloads
        SET bytesDownloaded = :bytesDownloaded,
            totalBytes = :totalBytes,
            speedBytesPerSecond = :speed,
            etaSeconds = :eta,
            updatedAt = :updatedAt
        WHERE id = :id
        """,
    )
    suspend fun updateProgress(
        id: String,
        bytesDownloaded: Long,
        totalBytes: Long,
        speed: Long,
        eta: Long,
        updatedAt: Long = System.currentTimeMillis(),
    )

    @Query(
        """
        UPDATE downloads
        SET fileName = :fileName,
            mimeType = :mimeType,
            updatedAt = :updatedAt
        WHERE id = :id
        """,
    )
    suspend fun updateMetadata(
        id: String,
        fileName: String,
        mimeType: String?,
        updatedAt: Long = System.currentTimeMillis(),
    )

    @Query(
        """
        UPDATE downloads
        SET status = :status,
            localUri = :localUri,
            bytesDownloaded = :bytesDownloaded,
            totalBytes = :totalBytes,
            speedBytesPerSecond = 0,
            etaSeconds = 0,
            errorMessage = NULL,
            updatedAt = :updatedAt
        WHERE id = :id
        """,
    )
    suspend fun markCompleted(
        id: String,
        status: DownloadStatus = DownloadStatus.COMPLETED,
        localUri: String,
        bytesDownloaded: Long,
        totalBytes: Long,
        updatedAt: Long = System.currentTimeMillis(),
    )

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun delete(id: String)

    @Query("DELETE FROM downloads WHERE status IN ('COMPLETED', 'FAILED', 'CANCELED')")
    suspend fun clearFinished()
}
