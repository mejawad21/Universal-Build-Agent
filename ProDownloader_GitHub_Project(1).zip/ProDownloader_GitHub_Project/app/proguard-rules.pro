# Room and WorkManager ship their own consumer rules.
# Keep the worker constructor available for WorkManager reflection.
-keep class com.example.prodownloader.download.FileDownloadWorker { <init>(...); }
