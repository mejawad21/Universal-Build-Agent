package com.velo.player;
import java.util.ArrayList;
import java.util.List;
public class SubtitleParser {
    public static final class Cue{
        public final long start,end;public final String text;
        Cue(long a,long b,String c){start=a;end=b;text=c;}
    }
    static long parseTime(String s){
        String[] t=s.trim().replace(',','.').split(":");
        if(t.length!=3&&t.length!=2)return -1;
        try{
            double seconds=Double.parseDouble(t[t.length-1]);
            long minutes=Long.parseLong(t[t.length-2]);
            long hours=t.length==3?Long.parseLong(t[0]):0;
            return (long)((hours*3600+minutes*60+seconds)*1000);
        }catch(Exception e){return -1;}
    }
    public static List<Cue> parse(String s){
        ArrayList<Cue> result=new ArrayList<>();
        String[] blocks=s.replace("\uFEFF","").replace("\r","").split("\n\\s*\n");
        for(String block:blocks){
            String[] lines=block.split("\n");int arrow=-1;
            for(int i=0;i<lines.length;i++)if(lines[i].contains("-->")){arrow=i;break;}
            if(arrow<0)continue;
            String[] times=lines[arrow].split("-->");
            if(times.length!=2)continue;
            long start=parseTime(times[0]),end=parseTime(times[1].trim().split("\\s+")[0]);
            if(start<0||end<=start)continue;
            StringBuilder text=new StringBuilder();
            for(int i=arrow+1;i<lines.length;i++){
                String line=lines[i].replaceAll("<[^>]*>","").trim();
                if(!line.isEmpty()){if(text.length()>0)text.append('\n');text.append(line);}
            }
            if(text.length()>0)result.add(new Cue(start,end,text.toString()));
        }
        return result;
    }
    public static String at(List<Cue> cues,long ms){
        for(Cue c:cues)if(c.start<=ms&&ms<=c.end)return c.text;
        return "";
    }
}
