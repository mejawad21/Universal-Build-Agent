package com.velo.player;

import android.app.Activity;
import android.app.PictureInPictureParams;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.PlaybackParams;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Rational;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class PlayerActivity extends Activity implements TextureView.SurfaceTextureListener {
    static final int WHITE=0xFFF6FAFF, GREEN=0xFF64DEB0, GRAY=0xFFB0BBCA;
    final Handler handler=new Handler(Looper.getMainLooper());
    MediaPlayer player;
    TextureView video;
    FrameLayout root,gestures;
    LinearLayout toolbar,footer;
    TextView playButton,now,total,subView,bubble,lockButton;
    SeekBar scrub;
    AudioManager audio;
    String videoUri,title;
    int videoW=0,videoH=0,duration=0,fitMode=0,originPosition=0,originalVolume=0;
    boolean prepared=false,isLocked=false,isPip=false,controlVisible=true,scrubbing=false;
    float originX,originY,originalBrightness=.5f,rate=1f;
    String moving="";
    long lastTap=0;float tapX=0;
    List<SubtitleParser.Cue> cues=Collections.emptyList();
    int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    GradientDrawable shape(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
    TextView label(String txt,int sp,int color){
        TextView v=new TextView(this);v.setText(txt);v.setTextSize(sp);v.setTextColor(color);
        v.setGravity(Gravity.CENTER);return v;
    }
    TextView button(String txt,Runnable r){
        TextView b=label(txt,19,WHITE);b.setBackground(shape(0x55000000,11));
        b.setOnClickListener(v->r.run());return b;
    }
    LinearLayout.LayoutParams lp(int w,int h){
        return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));
    }
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        videoUri=getIntent().getStringExtra("uri");title=getIntent().getStringExtra("title");
        if(videoUri==null){finish();return;}
        if(title==null)title="Video";
        audio=(AudioManager)getSystemService(AUDIO_SERVICE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        setup();systemBars();
    }
    void systemBars(){
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }
    void setup(){
        root=new FrameLayout(this);root.setBackgroundColor(Color.BLACK);setContentView(root);
        video=new TextureView(this);video.setSurfaceTextureListener(this);
        root.addView(video,new FrameLayout.LayoutParams(-1,-1));
        video.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->updateScale());
        gestures=new FrameLayout(this);root.addView(gestures,new FrameLayout.LayoutParams(-1,-1));
        gestures.setOnTouchListener((v,e)->touch(e));

        subView=label("",18,WHITE);subView.setShadowLayer(4,1,2,Color.BLACK);
        subView.setBackground(shape(0x66000000,6));subView.setPadding(dp(12),dp(4),dp(12),dp(4));
        FrameLayout.LayoutParams cc=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);
        cc.setMargins(dp(30),0,dp(30),dp(100));
        root.addView(subView,cc);subView.setVisibility(View.GONE);

        toolbar=new LinearLayout(this);toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(12),dp(7),dp(12),dp(7));toolbar.setBackgroundColor(0x99000000);
        root.addView(toolbar,new FrameLayout.LayoutParams(-1,dp(65),Gravity.TOP));
        toolbar.addView(button("‹",this::finish),lp(43,43));
        TextView caption=label(title,14,WHITE);caption.setGravity(Gravity.CENTER_VERTICAL);
        caption.setSingleLine(true);caption.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(43),1);cp.leftMargin=dp(10);
        toolbar.addView(caption,cp);
        toolbar.addView(button("⤾",()->{
            setRequestedOrientation(getRequestedOrientation()==ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE?
                ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT:ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        }),lp(45,43));
        if(Build.VERSION.SDK_INT>=26)toolbar.addView(button("▣",this::pip),lp(45,43));

        footer=new LinearLayout(this);footer.setOrientation(LinearLayout.VERTICAL);
        footer.setPadding(dp(14),dp(8),dp(14),dp(8));footer.setBackgroundColor(0xBB000000);
        root.addView(footer,new FrameLayout.LayoutParams(-1,dp(122),Gravity.BOTTOM));
        LinearLayout progress=new LinearLayout(this);progress.setGravity(Gravity.CENTER_VERTICAL);
        now=label("00:00",12,WHITE);total=label("00:00",12,GRAY);
        progress.addView(now,lp(54,34));
        scrub=new SeekBar(this);scrub.setMax(1000);
        scrub.setProgressTintList(android.content.res.ColorStateList.valueOf(GREEN));
        scrub.setThumbTintList(android.content.res.ColorStateList.valueOf(GREEN));
        progress.addView(scrub,new LinearLayout.LayoutParams(0,dp(34),1));
        progress.addView(total,lp(54,34));footer.addView(progress,lp(-1,39));
        scrub.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onStartTrackingTouch(SeekBar s){scrubbing=true;}
            public void onProgressChanged(SeekBar s,int p,boolean fromUser){
                if(fromUser)now.setText(time((long)duration*p/1000));
            }
            public void onStopTrackingTouch(SeekBar s){
                if(prepared)player.seekTo((int)((long)duration*s.getProgress()/1000));
                scrubbing=false;showControls();
            }
        });

        LinearLayout buttons=new LinearLayout(this);buttons.setGravity(Gravity.CENTER_VERTICAL);
        TextView ccButton=button("CC",this::selectSubtitle);ccButton.setTextSize(14);
        buttons.addView(ccButton,lp(43,49));
        TextView back=button("↶10",()->skip(-10000));back.setTextSize(15);buttons.addView(back,lp(60,49));
        playButton=button("Ⅱ",this::toggle);playButton.setTextColor(GREEN);playButton.setTextSize(27);
        buttons.addView(playButton,new LinearLayout.LayoutParams(0,dp(49),1));
        TextView forward=button("10↷",()->skip(10000));forward.setTextSize(15);
        buttons.addView(forward,lp(60,49));
        TextView speed=button("1×",()->{});speed.setTextSize(14);
        speed.setOnClickListener(v->speedMenu(speed));buttons.addView(speed,lp(43,49));
        buttons.addView(button("⛶",()->{
            fitMode=(fitMode+1)%3;updateScale();
            toast(fitMode==0?"Fit":fitMode==1?"Crop":"Stretch");
        }),lp(43,49));
        footer.addView(buttons,lp(-1,57));

        bubble=label("",15,WHITE);bubble.setBackground(shape(0xD0182132,12));
        root.addView(bubble,new FrameLayout.LayoutParams(dp(190),dp(46),Gravity.CENTER));
        bubble.setVisibility(View.GONE);
        lockButton=button("♧",()->{
            isLocked=!isLocked;lockButton.setText(isLocked?"🔒":"🔓");
            toast(isLocked?"Screen locked":"Screen unlocked");showControls();
        });
        FrameLayout.LayoutParams ll=new FrameLayout.LayoutParams(dp(46),dp(46),Gravity.LEFT|Gravity.CENTER_VERTICAL);
        ll.leftMargin=dp(17);root.addView(lockButton,ll);
        showControls();
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    String time(long ms){
        long s=Math.max(0,ms)/1000;
        return s>=3600?String.format(Locale.US,"%d:%02d:%02d",s/3600,s/60%60,s%60):
            String.format(Locale.US,"%02d:%02d",s/60,s%60);
    }
    void toggle(){
        if(!prepared)return;
        if(player.isPlaying()){player.pause();playButton.setText("▶");}
        else{player.start();playButton.setText("Ⅱ");}
        showControls();
    }
    void skip(int delta){
        if(prepared){
            player.seekTo(Math.max(0,Math.min(duration,player.getCurrentPosition()+delta)));
            info(delta>0?"+10 seconds":"−10 seconds");
        }
    }
    void info(String message){
        bubble.setText(message);bubble.setVisibility(View.VISIBLE);
        handler.removeCallbacks(hideBubble);handler.postDelayed(hideBubble,950);
    }
    final Runnable hideBubble=()->{if(bubble!=null)bubble.setVisibility(View.GONE);};
    void showControls(){
        controlVisible=true;
        if(!isPip){
            toolbar.setVisibility(isLocked?View.GONE:View.VISIBLE);
            footer.setVisibility(isLocked?View.GONE:View.VISIBLE);
            lockButton.setVisibility(View.VISIBLE);
        }
        handler.removeCallbacks(hideControls);handler.postDelayed(hideControls,4000);
    }
    final Runnable hideControls=()->{
        controlVisible=false;toolbar.setVisibility(View.GONE);footer.setVisibility(View.GONE);
        lockButton.setVisibility(View.GONE);
    };
    boolean touch(MotionEvent event){
        if(event.getActionMasked()==MotionEvent.ACTION_DOWN){
            originX=event.getX();originY=event.getY();moving="";
            originPosition=prepared?player.getCurrentPosition():0;
            originalVolume=audio.getStreamVolume(AudioManager.STREAM_MUSIC);
            WindowManager.LayoutParams p=getWindow().getAttributes();
            originalBrightness=p.screenBrightness<0?.5f:p.screenBrightness;
            return true;
        }
        if(event.getActionMasked()==MotionEvent.ACTION_MOVE){
            if(isLocked)return true;
            float dx=event.getX()-originX,dy=event.getY()-originY;
            if(moving.isEmpty()&&(Math.abs(dx)>dp(20)||Math.abs(dy)>dp(20))){
                moving=Math.abs(dx)>Math.abs(dy)?"seek":originX<gestures.getWidth()/2f?"brightness":"volume";
            }
            if("seek".equals(moving)&&prepared){
                int p=Math.max(0,Math.min(duration,originPosition+
                    (int)(dx/Math.max(1,gestures.getWidth())*duration*.6f)));
                info("Seek  "+time(p));
            }else if("volume".equals(moving)){
                int max=audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                int level=Math.max(0,Math.min(max,(int)(originalVolume-
                    dy/Math.max(1,gestures.getHeight())*max*1.5f)));
                audio.setStreamVolume(AudioManager.STREAM_MUSIC,level,0);
                info("Volume  "+level*100/Math.max(1,max)+"%");
            }else if("brightness".equals(moving)){
                WindowManager.LayoutParams p=getWindow().getAttributes();
                p.screenBrightness=Math.max(.02f,Math.min(1f,originalBrightness-
                    dy/Math.max(1,gestures.getHeight())*1.5f));
                getWindow().setAttributes(p);
                info("Brightness  "+Math.round(p.screenBrightness*100)+"%");
            }
            return true;
        }
        if(event.getActionMasked()==MotionEvent.ACTION_UP){
            if("seek".equals(moving)&&prepared){
                float dx=event.getX()-originX;
                player.seekTo(Math.max(0,Math.min(duration,originPosition+
                    (int)(dx/Math.max(1,gestures.getWidth())*duration*.6f))));
            }else if(moving.isEmpty()){
                long tick=System.currentTimeMillis();
                if(tick-lastTap<330&&Math.abs(event.getX()-tapX)<dp(130)&&!isLocked){
                    if(event.getX()<gestures.getWidth()*.35f)skip(-10000);
                    else if(event.getX()>gestures.getWidth()*.65f)skip(10000);
                    else toggle();
                    lastTap=0;
                }else{
                    if(controlVisible){handler.removeCallbacks(hideControls);hideControls.run();}
                    else showControls();
                    lastTap=tick;tapX=event.getX();
                }
            }
            return true;
        }
        return true;
    }
    void speedMenu(TextView anchor){
        PopupMenu menu=new PopupMenu(this,anchor);
        float[] options={.5f,.75f,1f,1.25f,1.5f,2f};
        for(float speed:options)menu.getMenu().add(speed+"×");
        menu.setOnMenuItemClickListener(item->{
            try{
                rate=Float.parseFloat(item.getTitle().toString().replace("×",""));
                if(prepared){
                    PlaybackParams params=player.getPlaybackParams();
                    params.setSpeed(rate);player.setPlaybackParams(params);
                }
                anchor.setText(rate+"×");toast("Speed "+rate+"×");
            }catch(Exception e){toast("Speed adjustment not supported");}
            return true;
        });
        menu.show();
    }
    void selectSubtitle(){
        Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("*/*");pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(pick,89);
    }
    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(req==89&&result==RESULT_OK&&data!=null&&data.getData()!=null){
            Uri uri=data.getData();
            new Thread(()->{
                try(InputStream input=getContentResolver().openInputStream(uri);
                    BufferedReader reader=new BufferedReader(new InputStreamReader(input,StandardCharsets.UTF_8))){
                    StringBuilder s=new StringBuilder();String line;
                    while((line=reader.readLine())!=null&&s.length()<2000000)s.append(line).append('\n');
                    List<SubtitleParser.Cue> loaded=SubtitleParser.parse(s.toString());
                    runOnUiThread(()->{cues=loaded;toast(loaded.size()+" subtitle lines loaded");});
                }catch(Exception e){runOnUiThread(()->toast("Unable to read subtitles"));}
            }).start();
        }
    }
    void pip(){
        if(Build.VERSION.SDK_INT>=26&&getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)){
            try{
                PictureInPictureParams.Builder p=new PictureInPictureParams.Builder();
                if(videoW>0&&videoH>0)p.setAspectRatio(new Rational(videoW,videoH));
                enterPictureInPictureMode(p.build());
            }catch(Exception e){toast("Picture-in-picture not available");}
        }
    }
    @Override public void onPictureInPictureModeChanged(boolean value,Configuration c){
        super.onPictureInPictureModeChanged(value,c);isPip=value;
        if(value){
            toolbar.setVisibility(View.GONE);footer.setVisibility(View.GONE);
            lockButton.setVisibility(View.GONE);subView.setVisibility(View.GONE);
        }else showControls();
    }
    @Override public void onSurfaceTextureAvailable(SurfaceTexture texture,int w,int h){
        try{
            player=new MediaPlayer();
            player.setDataSource(this,Uri.parse(videoUri));
            player.setSurface(new Surface(texture));
            player.setAudioStreamType(AudioManager.STREAM_MUSIC);
            player.setOnVideoSizeChangedListener((mp,width,height)->{
                videoW=width;videoH=height;updateScale();
            });
            player.setOnPreparedListener(mp->{
                prepared=true;duration=Math.max(1,mp.getDuration());
                total.setText(time(duration));
                long saved=getSharedPreferences("resume",MODE_PRIVATE).getLong(videoUri,0);
                if(saved>5000&&saved<duration-5000)mp.seekTo((int)saved);
                mp.start();playButton.setText("Ⅱ");showControls();
                handler.post(progressTick);
            });
            player.setOnCompletionListener(mp->{
                playButton.setText("▶");showControls();
                getSharedPreferences("resume",MODE_PRIVATE).edit().remove(videoUri).apply();
            });
            player.setOnErrorListener((mp,what,extra)->{
                toast("This video codec is unsupported by your device");prepared=false;return true;
            });
            player.prepareAsync();
        }catch(Exception e){toast("Cannot open this video");finish();}
    }
    final Runnable progressTick=new Runnable(){
        @Override public void run(){
            if(prepared&&player!=null){
                try{
                    int p=player.getCurrentPosition();
                    if(!scrubbing){
                        now.setText(time(p));
                        scrub.setProgress((int)((long)p*1000/Math.max(1,duration)));
                    }
                    String sub=SubtitleParser.at(cues,p);
                    if(!sub.isEmpty()&&!isPip){
                        subView.setText(sub);subView.setVisibility(View.VISIBLE);
                    }else subView.setVisibility(View.GONE);
                }catch(Exception ignored){}
            }
            handler.postDelayed(this,350);
        }
    };
    void updateScale(){
        if(video==null||videoW<=0||videoH<=0)return;
        float w=video.getWidth(),h=video.getHeight();
        if(w<=0||h<=0)return;
        float va=(float)videoW/videoH,ba=w/h;
        float sx=1f,sy=1f;
        if(fitMode==0){if(va>ba)sy=ba/va;else sx=va/ba;}
        else if(fitMode==1){if(va>ba)sx=va/ba;else sy=ba/va;}
        Matrix m=new Matrix();m.setScale(sx,sy,w/2,h/2);
        video.setTransform(m);
    }
    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture texture,int w,int h){updateScale();}
    @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture texture){release();return true;}
    @Override public void onSurfaceTextureUpdated(SurfaceTexture texture){}
    void release(){
        if(player!=null){
            try{
                if(prepared&&player.getDuration()>0){
                    long current=player.getCurrentPosition();
                    if(current<player.getDuration()-5000)getSharedPreferences("resume",MODE_PRIVATE)
                        .edit().putLong(videoUri,current).apply();
                }
                player.release();
            }catch(Exception ignored){}
            prepared=false;player=null;
        }
    }
    @Override protected void onPause(){
        super.onPause();
        if(prepared&&player!=null){
            try{
                getSharedPreferences("resume",MODE_PRIVATE).edit()
                    .putLong(videoUri,player.getCurrentPosition()).apply();
                if(!isPip){player.pause();playButton.setText("▶");}
            }catch(Exception ignored){}
        }
    }
    @Override protected void onDestroy(){
        handler.removeCallbacksAndMessages(null);release();super.onDestroy();
    }
    @Override public void onConfigurationChanged(Configuration c){
        super.onConfigurationChanged(c);video.postDelayed(this::updateScale,140);
    }
    @Override public void onBackPressed(){
        if(isLocked){isLocked=false;showControls();}
        else super.onBackPressed();
    }
}
