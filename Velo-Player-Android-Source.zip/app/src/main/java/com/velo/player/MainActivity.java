package com.velo.player;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Locale;

public class MainActivity extends Activity {
    static final int BG=0xFF0B1019, PANEL=0xFF181F2E, WHITE=0xFFF7FAFD,
        SECONDARY=0xFF91A0B8, GREEN=0xFF64DEB0;
    final ArrayList<Video> all=new ArrayList<>(), shown=new ArrayList<>();
    final ArrayList<String> folders=new ArrayList<>();
    int tab=0; String searchText="", selectedFolder=null;
    TextView countLabel, heading, noVideos; ListView videoList;
    LinearLayout tabs, parent; VideoAdapter adapter;

    static class Video {
        Uri uri;String name,folder;long duration,size,added;
        Video(Uri u,String n,String f,long d,long s,long a){
            uri=u;name=n;folder=f;duration=d;size=s;added=a;
        }
    }
    int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    GradientDrawable shape(int color,int rad){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(rad));return g;}
    TextView tv(String value,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }
    LinearLayout.LayoutParams lp(int w,int h){
        return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));
    }
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        buildUi();
        permissionOrScan();
    }
    void buildUi(){
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        parent=new LinearLayout(this);parent.setOrientation(LinearLayout.VERTICAL);
        parent.setBackgroundColor(BG);parent.setPadding(dp(17),dp(12),dp(17),0);
        setContentView(parent);

        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo=tv("▶",25,BG,true);logo.setGravity(Gravity.CENTER);logo.setBackground(shape(GREEN,14));
        header.addView(logo,lp(49,49));
        LinearLayout titleGroup=new LinearLayout(this);titleGroup.setOrientation(LinearLayout.VERTICAL);
        titleGroup.setPadding(dp(12),0,0,0);
        titleGroup.addView(tv("VELO PLAYER",21,WHITE,true));
        titleGroup.addView(tv("Every frame, your way.",11,SECONDARY,false));
        header.addView(titleGroup,new LinearLayout.LayoutParams(0,dp(56),1));
        TextView refresh=tv("⟳",27,GREEN,true);refresh.setGravity(Gravity.CENTER);
        refresh.setOnClickListener(v->permissionOrScan());header.addView(refresh,lp(45,45));
        parent.addView(header,lp(-1,73));

        LinearLayout queryBox=new LinearLayout(this);queryBox.setGravity(Gravity.CENTER_VERTICAL);
        queryBox.setPadding(dp(13),0,dp(10),0);queryBox.setBackground(shape(PANEL,14));
        queryBox.addView(tv("⌕",26,SECONDARY,false),lp(30,50));
        EditText query=new EditText(this);query.setSingleLine(true);query.setTextSize(15);
        query.setHint("Search videos");query.setTextColor(WHITE);query.setHintTextColor(SECONDARY);
        query.setBackgroundColor(Color.TRANSPARENT);
        queryBox.addView(query,new LinearLayout.LayoutParams(0,dp(50),1));
        query.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int a,int c,int f){}
            public void onTextChanged(CharSequence s,int start,int before,int count){searchText=s.toString();filter();}
            public void afterTextChanged(Editable e){}
        });
        parent.addView(queryBox,lp(-1,51));

        tabs=new LinearLayout(this);tabs.setPadding(0,dp(17),0,dp(9));
        parent.addView(tabs,lp(-1,65));
        heading=tv("All videos",18,WHITE,true);parent.addView(heading,lp(-1,27));
        countLabel=tv("Loading videos...",12,SECONDARY,false);
        LinearLayout.LayoutParams countParams=lp(-1,26);countParams.bottomMargin=dp(8);
        parent.addView(countLabel,countParams);
        videoList=new ListView(this);
        videoList.setDivider(null);videoList.setDividerHeight(dp(8));videoList.setVerticalScrollBarEnabled(false);
        videoList.setSelector(android.R.color.transparent);
        adapter=new VideoAdapter();videoList.setAdapter(adapter);
        parent.addView(videoList,new LinearLayout.LayoutParams(-1,0,1));
        noVideos=tv("No videos found.\nOpen a video using the button below.",14,SECONDARY,false);
        noVideos.setGravity(Gravity.CENTER);noVideos.setVisibility(View.GONE);
        parent.addView(noVideos,new LinearLayout.LayoutParams(-1,0,1));
        Button open=new Button(this);open.setText("＋  Open video file");open.setAllCaps(false);
        open.setTextSize(15);open.setTextColor(BG);open.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        open.setBackground(shape(GREEN,14));open.setOnClickListener(v->openPicker());
        LinearLayout.LayoutParams button=lp(-1,54);
        button.setMargins(0,dp(13),0,dp(14));parent.addView(open,button);
        selectTab(0);
    }
    void drawTabs(){
        tabs.removeAllViews();
        String[] names={"All videos","Folders","Recent"};
        for(int i=0;i<3;i++){
            final int index=i;
            TextView chip=tv(names[i],13,i==tab?BG:SECONDARY,i==tab);
            chip.setGravity(Gravity.CENTER);
            chip.setBackground(shape(i==tab?GREEN:PANEL,12));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(39),1);
            if(i<2)p.rightMargin=dp(7);
            tabs.addView(chip,p);chip.setOnClickListener(v->selectTab(index));
        }
    }
    void selectTab(int value){tab=value;selectedFolder=null;drawTabs();filter();}
    void permissionOrScan(){
        if(Build.VERSION.SDK_INT>=33){
            if(checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO)!=PackageManager.PERMISSION_GRANTED){
                requestPermissions(new String[]{Manifest.permission.READ_MEDIA_VIDEO},5);return;
            }
        }else if(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},5);return;
        }
        scan();
    }
    @Override public void onRequestPermissionsResult(int code,String[] perm,int[] results){
        super.onRequestPermissionsResult(code,perm,results);
        if(code==5)scan();
    }
    void scan(){
        countLabel.setText("Scanning...");
        new Thread(()->{
            ArrayList<Video> found=new ArrayList<>();
            try{
                String pathColumn=Build.VERSION.SDK_INT>=29?
                    MediaStore.Video.Media.RELATIVE_PATH:MediaStore.Video.Media.DATA;
                String[] cols={MediaStore.Video.Media._ID,MediaStore.Video.Media.DISPLAY_NAME,
                    MediaStore.Video.Media.DURATION,MediaStore.Video.Media.SIZE,
                    MediaStore.Video.Media.DATE_ADDED,pathColumn};
                try(Cursor c=getContentResolver().query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                    cols,null,null,MediaStore.Video.Media.DATE_ADDED+" DESC")){
                    if(c!=null)while(c.moveToNext()){
                        long id=c.getLong(0);
                        String name=c.getString(1);if(name==null)name="Video "+id;
                        long length=c.isNull(2)?0:c.getLong(2);
                        long size=c.isNull(3)?0:c.getLong(3);
                        long date=c.isNull(4)?0:c.getLong(4);
                        String path=c.getString(5),folder="Videos";
                        if(path!=null){
                            String[] bits=path.replace('\\','/').split("/");
                            for(int i=bits.length-1;i>=0;i--){
                                if(Build.VERSION.SDK_INT<29&&i==bits.length-1)continue;
                                if(!bits[i].isEmpty()){folder=bits[i];break;}
                            }
                        }
                        found.add(new Video(ContentUris.withAppendedId(
                            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,id),name,folder,length,size,date));
                    }
                }
            }catch(Exception e){android.util.Log.w("VeloPlayer","Media scan failed",e);}
            runOnUiThread(()->{all.clear();all.addAll(found);filter();});
        }).start();
    }
    void filter(){
        if(adapter==null)return;
        shown.clear();folders.clear();
        ArrayList<Video> ordered=new ArrayList<>(all);
        if(tab==0)Collections.sort(ordered,(a,b)->a.name.compareToIgnoreCase(b.name));
        else Collections.sort(ordered,(a,b)->Long.compare(b.added,a.added));
        LinkedHashMap<String,Integer> counts=new LinkedHashMap<>();
        for(Video f:ordered){
            counts.put(f.folder,counts.getOrDefault(f.folder,0)+1);
            if((selectedFolder==null||selectedFolder.equals(f.folder))&&
               f.name.toLowerCase(Locale.ROOT).contains(searchText.toLowerCase(Locale.ROOT)))shown.add(f);
        }
        for(String name:counts.keySet())if(name.toLowerCase(Locale.ROOT).contains(
            searchText.toLowerCase(Locale.ROOT)))folders.add(name);
        if(tab==1&&selectedFolder==null)Collections.sort(folders,String::compareToIgnoreCase);
        heading.setText(tab==1?(selectedFolder==null?"Video folders":selectedFolder):
            tab==2?"Recently added":"All videos");
        countLabel.setText(all.size()+" videos on your device");
        boolean empty=tab==1&&selectedFolder==null?folders.isEmpty():shown.isEmpty();
        videoList.setVisibility(empty?View.GONE:View.VISIBLE);
        noVideos.setVisibility(empty?View.VISIBLE:View.GONE);
        adapter.notifyDataSetChanged();
    }
    void openPicker(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("video/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i,31);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==31&&result==RESULT_OK&&data!=null&&data.getData()!=null){
            Uri u=data.getData();
            try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}
            catch(Exception ignored){}
            open(u,"Selected video");
        }
    }
    void open(Uri u,String name){
        Intent p=new Intent(this,PlayerActivity.class);
        p.putExtra("uri",u.toString());p.putExtra("title",name);startActivity(p);
    }
    @Override public void onBackPressed(){
        if(tab==1&&selectedFolder!=null){selectedFolder=null;filter();}
        else super.onBackPressed();
    }
    String clock(long ms){
        long s=ms/1000;
        return s>=3600?String.format(Locale.US,"%d:%02d:%02d",s/3600,s/60%60,s%60):
            String.format(Locale.US,"%02d:%02d",s/60,s%60);
    }
    class VideoAdapter extends BaseAdapter {
        @Override public int getCount(){return tab==1&&selectedFolder==null?folders.size():shown.size();}
        @Override public Object getItem(int p){return tab==1&&selectedFolder==null?folders.get(p):shown.get(p);}
        @Override public long getItemId(int p){return p;}
        @Override public View getView(int index,View recycled,ViewGroup unused){
            boolean folderRow=tab==1&&selectedFolder==null;
            LinearLayout row=new LinearLayout(MainActivity.this);
            row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(12),dp(8),dp(12),dp(8));
            row.setBackground(shape(PANEL,15));
            TextView tile=tv(folderRow?"▣":"▶",25,GREEN,true);
            tile.setGravity(Gravity.CENTER);tile.setBackground(shape(0xFF29364B,11));
            row.addView(tile,lp(81,66));
            LinearLayout info=new LinearLayout(MainActivity.this);
            info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(12),0,dp(7),0);
            String headline,subline;
            if(folderRow){
                headline=folders.get(index);
                int n=0;for(Video v:all)if(v.folder.equals(headline))n++;
                subline=n+" videos";
            }else{
                Video v=shown.get(index);headline=v.name;
                subline=clock(v.duration)+"  ·  "+v.folder+"  ·  "+v.size/1048576+" MB";
            }
            TextView name=tv(headline,14,WHITE,true);name.setMaxLines(2);
            name.setEllipsize(TextUtils.TruncateAt.END);info.addView(name,lp(-1,-2));
            TextView secondary=tv(subline,11,SECONDARY,false);secondary.setSingleLine(true);
            secondary.setEllipsize(TextUtils.TruncateAt.END);
            secondary.setPadding(0,dp(5),0,0);info.addView(secondary,lp(-1,-2));
            row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
            row.addView(tv("›",26,SECONDARY,false),lp(18,50));
            row.setOnClickListener(v->{
                if(folderRow){selectedFolder=folders.get(index);filter();}
                else{Video f=shown.get(index);open(f.uri,f.name);}
            });
            return row;
        }
    }
}
