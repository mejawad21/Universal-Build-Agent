# Velo Player 1.0

Independent local Android video player inspired by familiar swipe-based mobile video players. Not affiliated with MX Player.

* Dark video library, search, folders and recently added
* System video picker; no account or network required
* Fullscreen video playback and resume position
* Double tap left/right to jump 10 seconds
* Swipe to adjust brightness (left), volume (right) and seek horizontally
* Play/pause, speed 0.5–2x, fit/crop/stretch, orientation toggle and screen lock
* Load SRT/VTT subtitles via file picker
* Picture-in-picture on supported devices

## Notes
Uses Android's native MediaPlayer. Video/audio compatibility depends on codecs available on your phone; it cannot decode every MX Player format. This is a first build with no advertisements, no tracking, and no internet permission.

## Build
Use JDK17 and Android SDK 35. Open in Android Studio or use Gradle to run assembleDebug.
The output is app/build/outputs/apk/debug/app-debug.apk.
