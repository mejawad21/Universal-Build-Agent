package com.example.fireassist.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.GpsFixed
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.fireassist.data.AimResult
import com.example.fireassist.data.AimScoring
import kotlinx.coroutines.delay
import kotlin.math.hypot
import kotlin.random.Random

@Composable
internal fun AimTrainerScreen(
    history: List<AimResult>,
    onSave: (AimResult) -> Unit,
) {
    val haptic = LocalHapticFeedback.current
    var duration by remember { mutableIntStateOf(30) }
    var running by remember { mutableStateOf(false) }
    var remaining by remember { mutableIntStateOf(duration) }
    var hits by remember { mutableIntStateOf(0) }
    var attempts by remember { mutableIntStateOf(0) }
    var targetX by remember { mutableFloatStateOf(0.5f) }
    var targetY by remember { mutableFloatStateOf(0.5f) }
    var targetShownAt by remember { mutableLongStateOf(0L) }
    var reactionTotal by remember { mutableLongStateOf(0L) }
    var saved by remember { mutableStateOf(false) }

    fun moveTarget() {
        targetX = Random.nextFloat().coerceIn(0.12f, 0.88f)
        targetY = Random.nextFloat().coerceIn(0.15f, 0.85f)
        targetShownAt = System.currentTimeMillis()
    }

    fun start() {
        hits = 0
        attempts = 0
        reactionTotal = 0L
        remaining = duration
        saved = false
        running = true
        moveTarget()
    }

    LaunchedEffect(running) {
        while (running && remaining > 0) {
            delay(1_000)
            remaining -= 1
            if (remaining <= 0) running = false
        }
    }

    LaunchedEffect(running, remaining, saved) {
        if (!running && remaining == 0 && !saved) {
            val average = if (hits > 0) reactionTotal / hits else 0L
            onSave(
                AimResult(
                    timestamp = System.currentTimeMillis(),
                    durationSeconds = duration,
                    hits = hits,
                    attempts = attempts,
                    averageReactionMs = average,
                ),
            )
            saved = true
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Text(
                "Aim & reaction trainer",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Black,
            )
            Text("Tap the moving target. Missed taps lower your accuracy.")
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(15, 30, 60).forEach { seconds ->
                    AssistChip(
                        onClick = {
                            if (!running) {
                                duration = seconds
                                remaining = seconds
                            }
                        },
                        label = { Text("${seconds}s") },
                        leadingIcon = if (duration == seconds) {
                            { Icon(Icons.Outlined.CheckCircle, contentDescription = null) }
                        } else null,
                    )
                }
            }
        }

        item {
            Card(shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        StatText("TIME", remaining.toString())
                        StatText("HITS", hits.toString())
                        StatText("ACCURACY", "${AimScoring.accuracyPercent(hits, attempts)}%")
                    }
                    Spacer(Modifier.height(12.dp))
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(0.78f)
                            .background(
                                MaterialTheme.colorScheme.surfaceVariant,
                                RoundedCornerShape(20.dp),
                            )
                            .pointerInput(running, targetX, targetY) {
                                detectTapGestures { tap ->
                                    if (!running) return@detectTapGestures
                                    attempts += 1
                                    val center = Offset(
                                        size.width * targetX,
                                        size.height * targetY,
                                    )
                                    val radius = minOf(size.width, size.height) * 0.075f
                                    val distance = hypot(
                                        (tap.x - center.x).toDouble(),
                                        (tap.y - center.y).toDouble(),
                                    )
                                    if (distance <= radius) {
                                        hits += 1
                                        reactionTotal += System.currentTimeMillis() - targetShownAt
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        moveTarget()
                                    }
                                }
                            },
                    ) {
                        if (running) {
                            val center = Offset(size.width * targetX, size.height * targetY)
                            val radius = size.minDimension * 0.075f
                            drawCircle(Color(0xFFFF6A2A), radius, center)
                            drawCircle(
                                color = Color.White,
                                radius = radius * 0.58f,
                                center = center,
                                style = Stroke(width = radius * 0.18f),
                            )
                            drawLine(
                                Color.White,
                                Offset(center.x - radius, center.y),
                                Offset(center.x + radius, center.y),
                                strokeWidth = 3f,
                            )
                            drawLine(
                                Color.White,
                                Offset(center.x, center.y - radius),
                                Offset(center.x, center.y + radius),
                                strokeWidth = 3f,
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = { if (running) running = false else start() },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Icon(
                            if (running) Icons.Outlined.Refresh else Icons.Outlined.GpsFixed,
                            contentDescription = null,
                        )
                        Text(if (running) "  Stop drill" else "  Start drill")
                    }
                }
            }
        }

        if (!running && remaining == 0) {
            item {
                val average = if (hits > 0) reactionTotal / hits else 0L
                Card {
                    Column(Modifier.padding(18.dp)) {
                        Text("Drill complete", fontWeight = FontWeight.Black)
                        Text(
                            "Score: ${AimScoring.score(hits, attempts, average)} • " +
                                "Average reaction: $average ms",
                        )
                    }
                }
            }
        }

        if (history.isNotEmpty()) {
            item {
                Text(
                    "Recent drills",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                )
            }
            items(history.take(5), key = { it.timestamp }) { result ->
                Card {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Column {
                            Text(
                                "${result.hits} hits • ${result.accuracy}% accuracy",
                                fontWeight = FontWeight.Bold,
                            )
                            Text(dateText(result.timestamp), style = MaterialTheme.typography.bodySmall)
                        }
                        Text(
                            AimScoring.score(
                                result.hits,
                                result.attempts,
                                result.averageReactionMs,
                            ).toString(),
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StatText(label: String, value: String) {
    Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall)
        Text(value, fontWeight = FontWeight.Black)
    }
}
