package com.example.fireassist.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.GpsFixed
import androidx.compose.material.icons.outlined.Gamepad
import androidx.compose.material.icons.outlined.OpenInNew
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.fireassist.data.HudPoint
import com.example.fireassist.data.SensitivitySettings
import kotlin.math.roundToInt

@Composable
internal fun SetupScreen(
    sensitivity: SensitivitySettings,
    hudPoints: List<HudPoint>,
    onSensitivityChange: (SensitivitySettings) -> Unit,
    onResetSensitivity: () -> Unit,
    onHudMove: (String, Float, Float) -> Unit,
    onHudResize: (String, Float) -> Unit,
    onResetHud: () -> Unit,
) {
    var selected by remember { mutableIntStateOf(0) }

    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = selected) {
            Tab(
                selected = selected == 0,
                onClick = { selected = 0 },
                text = { Text("Sensitivity") },
            )
            Tab(
                selected = selected == 1,
                onClick = { selected = 1 },
                text = { Text("HUD planner") },
            )
        }

        if (selected == 0) {
            SensitivityScreen(
                settings = sensitivity,
                onChange = onSensitivityChange,
                onReset = onResetSensitivity,
            )
        } else {
            HudPlannerScreen(
                points = hudPoints,
                onMove = onHudMove,
                onResize = onHudResize,
                onReset = onResetHud,
            )
        }
    }
}

@Composable
private fun SensitivityScreen(
    settings: SensitivitySettings,
    onChange: (SensitivitySettings) -> Unit,
    onReset: () -> Unit,
) {
    LazyColumn(
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Text(
                "Sensitivity notebook",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Black,
            )
            Text(
                "Keep a personal preset here, test it in training mode, and adjust " +
                    "gradually. FireAssist never changes game settings automatically.",
            )
        }
        item { SensitivitySlider("General", settings.general, Icons.Outlined.Gamepad) { onChange(settings.copy(general = it)) } }
        item { SensitivitySlider("Red Dot", settings.redDot, Icons.Outlined.GpsFixed) { onChange(settings.copy(redDot = it)) } }
        item { SensitivitySlider("2× Scope", settings.scope2x, Icons.Outlined.GpsFixed) { onChange(settings.copy(scope2x = it)) } }
        item { SensitivitySlider("4× Scope", settings.scope4x, Icons.Outlined.GpsFixed) { onChange(settings.copy(scope4x = it)) } }
        item { SensitivitySlider("Sniper Scope", settings.sniper, Icons.Outlined.GpsFixed) { onChange(settings.copy(sniper = it)) } }
        item { SensitivitySlider("Free Look", settings.freeLook, Icons.Outlined.OpenInNew) { onChange(settings.copy(freeLook = it)) } }
        item {
            OutlinedButton(onClick = onReset, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Outlined.Refresh, contentDescription = null)
                Text("  Reset starter preset")
            }
        }
    }
}

@Composable
private fun SensitivitySlider(
    label: String,
    value: Int,
    icon: ImageVector,
    onValueChange: (Int) -> Unit,
) {
    Card {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Text(
                    label,
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 12.dp),
                    fontWeight = FontWeight.Bold,
                )
                Text(value.toString(), fontWeight = FontWeight.Black)
            }
            Slider(
                value = value.toFloat(),
                onValueChange = { onValueChange(it.roundToInt()) },
                valueRange = 0f..200f,
                steps = 199,
            )
        }
    }
}

@Composable
private fun HudPlannerScreen(
    points: List<HudPoint>,
    onMove: (String, Float, Float) -> Unit,
    onResize: (String, Float) -> Unit,
    onReset: () -> Unit,
) {
    var selectedId by remember { mutableStateOf(points.firstOrNull()?.id) }
    var containerSize by remember { mutableStateOf(IntSize.Zero) }

    LazyColumn(
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Text(
                "HUD practice board",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Black,
            )
            Text(
                "Drag the sample controls to plan a comfortable layout. Copy the " +
                    "positions manually inside the game's own HUD editor.",
            )
        }

        item {
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .background(
                        MaterialTheme.colorScheme.surfaceVariant,
                        RoundedCornerShape(22.dp),
                    )
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outline,
                        RoundedCornerShape(22.dp),
                    )
                    .onSizeChanged { containerSize = it },
            ) {
                val density = LocalDensity.current

                Canvas(Modifier.fillMaxSize()) {
                    val stepX = size.width / 8f
                    val stepY = size.height / 5f
                    repeat(9) { index ->
                        drawLine(
                            color = Color.White.copy(alpha = 0.07f),
                            start = Offset(stepX * index, 0f),
                            end = Offset(stepX * index, size.height),
                        )
                    }
                    repeat(6) { index ->
                        drawLine(
                            color = Color.White.copy(alpha = 0.07f),
                            start = Offset(0f, stepY * index),
                            end = Offset(size.width, stepY * index),
                        )
                    }
                }

                points.forEach { point ->
                    val diameterPx = minOf(
                        containerSize.width,
                        containerSize.height,
                    ).toFloat() * point.size
                    val diameterDp = with(density) { diameterPx.toDp() }

                    Box(
                        modifier = Modifier
                            .offset {
                                IntOffset(
                                    x = (containerSize.width * point.x - diameterPx / 2f)
                                        .roundToInt(),
                                    y = (containerSize.height * point.y - diameterPx / 2f)
                                        .roundToInt(),
                                )
                            }
                            .size(diameterDp.coerceAtLeast(40.dp))
                            .background(
                                if (selectedId == point.id) {
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.75f)
                                } else {
                                    Color.Black.copy(alpha = 0.48f)
                                },
                                CircleShape,
                            )
                            .border(2.dp, Color.White.copy(alpha = 0.75f), CircleShape)
                            .pointerInput(point.id, point.x, point.y, containerSize) {
                                detectDragGestures(
                                    onDragStart = { selectedId = point.id },
                                ) { change, dragAmount ->
                                    change.consume()
                                    if (containerSize.width > 0 && containerSize.height > 0) {
                                        onMove(
                                            point.id,
                                            point.x + dragAmount.x / containerSize.width,
                                            point.y + dragAmount.y / containerSize.height,
                                        )
                                    }
                                }
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            point.label,
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 8.sp,
                            textAlign = TextAlign.Center,
                        )
                    }
                }
            }
        }

        item {
            val selected = points.firstOrNull { it.id == selectedId }
            AnimatedVisibility(visible = selected != null) {
                if (selected != null) {
                    Card {
                        Column(Modifier.padding(16.dp)) {
                            Text("${selected.label} size", fontWeight = FontWeight.Bold)
                            Slider(
                                value = selected.size,
                                onValueChange = { onResize(selected.id, it) },
                                valueRange = 0.08f..0.24f,
                            )
                        }
                    }
                }
            }
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(points.size) { index ->
                    val point = points[index]
                    AssistChip(
                        onClick = { selectedId = point.id },
                        label = { Text(point.label) },
                    )
                }
            }
        }

        item {
            OutlinedButton(onClick = onReset, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Outlined.Refresh, contentDescription = null)
                Text("  Reset HUD board")
            }
        }
    }
}
