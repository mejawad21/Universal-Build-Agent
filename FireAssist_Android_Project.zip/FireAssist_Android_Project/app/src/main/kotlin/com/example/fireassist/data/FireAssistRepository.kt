package com.example.fireassist.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

class FireAssistRepository(context: Context) {
    private val preferences =
        context.getSharedPreferences("fire_assist_data", Context.MODE_PRIVATE)

    private val _sensitivity = MutableStateFlow(loadSensitivity())
    val sensitivity: StateFlow<SensitivitySettings> = _sensitivity.asStateFlow()

    private val _hudPoints = MutableStateFlow(loadHud())
    val hudPoints: StateFlow<List<HudPoint>> = _hudPoints.asStateFlow()

    private val _sessions = MutableStateFlow(loadSessions())
    val sessions: StateFlow<List<MatchSession>> = _sessions.asStateFlow()

    private val _aimResults = MutableStateFlow(loadAimResults())
    val aimResults: StateFlow<List<AimResult>> = _aimResults.asStateFlow()

    private val _checklist = MutableStateFlow(loadChecklist())
    val checklist: StateFlow<Map<String, Boolean>> = _checklist.asStateFlow()

    fun saveSensitivity(value: SensitivitySettings) {
        _sensitivity.value = value
        preferences.edit()
            .putInt("s_general", value.general)
            .putInt("s_red_dot", value.redDot)
            .putInt("s_2x", value.scope2x)
            .putInt("s_4x", value.scope4x)
            .putInt("s_sniper", value.sniper)
            .putInt("s_free_look", value.freeLook)
            .apply()
    }

    fun resetSensitivity() = saveSensitivity(SensitivitySettings())

    fun saveHud(points: List<HudPoint>) {
        _hudPoints.value = points
        val array = JSONArray()
        points.forEach { point ->
            array.put(
                JSONObject()
                    .put("id", point.id)
                    .put("label", point.label)
                    .put("x", point.x.toDouble())
                    .put("y", point.y.toDouble())
                    .put("size", point.size.toDouble()),
            )
        }
        preferences.edit().putString("hud", array.toString()).apply()
    }

    fun resetHud() = saveHud(defaultHud())

    fun addSession(session: MatchSession) {
        _sessions.value = (listOf(session) + _sessions.value).take(100)
        saveSessions()
    }

    fun deleteSession(id: Long) {
        _sessions.value = _sessions.value.filterNot { it.id == id }
        saveSessions()
    }

    fun saveAimResult(result: AimResult) {
        _aimResults.value = (listOf(result) + _aimResults.value).take(30)
        saveAimResults()
    }

    fun setChecklistItem(id: String, checked: Boolean) {
        val updated = _checklist.value.toMutableMap().apply { put(id, checked) }
        _checklist.value = updated
        preferences.edit()
            .putString("checklist", JSONObject(updated).toString())
            .apply()
    }

    fun resetChecklist() {
        _checklist.value = defaultChecklist()
        preferences.edit()
            .putString("checklist", JSONObject(_checklist.value).toString())
            .apply()
    }

    private fun loadSensitivity() = SensitivitySettings(
        general = preferences.getInt("s_general", 90),
        redDot = preferences.getInt("s_red_dot", 85),
        scope2x = preferences.getInt("s_2x", 80),
        scope4x = preferences.getInt("s_4x", 70),
        sniper = preferences.getInt("s_sniper", 50),
        freeLook = preferences.getInt("s_free_look", 75),
    )

    private fun loadHud(): List<HudPoint> = runCatching {
        val raw = preferences.getString("hud", null) ?: return defaultHud()
        val array = JSONArray(raw)
        buildList {
            for (index in 0 until array.length()) {
                val item = array.getJSONObject(index)
                add(
                    HudPoint(
                        id = item.getString("id"),
                        label = item.getString("label"),
                        x = item.getDouble("x").toFloat(),
                        y = item.getDouble("y").toFloat(),
                        size = item.getDouble("size").toFloat(),
                    ),
                )
            }
        }
    }.getOrDefault(defaultHud())

    private fun loadSessions(): List<MatchSession> = runCatching {
        val array = JSONArray(preferences.getString("sessions", "[]"))
        buildList {
            for (index in 0 until array.length()) {
                val item = array.getJSONObject(index)
                add(
                    MatchSession(
                        id = item.getLong("id"),
                        timestamp = item.getLong("timestamp"),
                        mode = item.getString("mode"),
                        kills = item.getInt("kills"),
                        placement = item.getInt("placement"),
                        damage = item.getInt("damage"),
                        notes = item.optString("notes"),
                    ),
                )
            }
        }
    }.getOrDefault(emptyList())

    private fun loadAimResults(): List<AimResult> = runCatching {
        val array = JSONArray(preferences.getString("aim_results", "[]"))
        buildList {
            for (index in 0 until array.length()) {
                val item = array.getJSONObject(index)
                add(
                    AimResult(
                        timestamp = item.getLong("timestamp"),
                        durationSeconds = item.getInt("duration"),
                        hits = item.getInt("hits"),
                        attempts = item.getInt("attempts"),
                        averageReactionMs = item.getLong("reaction"),
                    ),
                )
            }
        }
    }.getOrDefault(emptyList())

    private fun loadChecklist(): Map<String, Boolean> = runCatching {
        val json = JSONObject(
            preferences.getString(
                "checklist",
                JSONObject(defaultChecklist()).toString(),
            ) ?: "{}",
        )
        defaultChecklist().keys.associateWith { id -> json.optBoolean(id, false) }
    }.getOrDefault(defaultChecklist())

    private fun saveSessions() {
        val array = JSONArray()
        _sessions.value.forEach { session ->
            array.put(
                JSONObject()
                    .put("id", session.id)
                    .put("timestamp", session.timestamp)
                    .put("mode", session.mode)
                    .put("kills", session.kills)
                    .put("placement", session.placement)
                    .put("damage", session.damage)
                    .put("notes", session.notes),
            )
        }
        preferences.edit().putString("sessions", array.toString()).apply()
    }

    private fun saveAimResults() {
        val array = JSONArray()
        _aimResults.value.forEach { result ->
            array.put(
                JSONObject()
                    .put("timestamp", result.timestamp)
                    .put("duration", result.durationSeconds)
                    .put("hits", result.hits)
                    .put("attempts", result.attempts)
                    .put("reaction", result.averageReactionMs),
            )
        }
        preferences.edit().putString("aim_results", array.toString()).apply()
    }

    companion object {
        fun defaultHud() = listOf(
            HudPoint("fire", "FIRE", 0.83f, 0.55f, 0.15f),
            HudPoint("scope", "SCOPE", 0.72f, 0.35f, 0.12f),
            HudPoint("jump", "JUMP", 0.84f, 0.78f, 0.12f),
            HudPoint("crouch", "CROUCH", 0.69f, 0.79f, 0.11f),
            HudPoint("joystick", "MOVE", 0.15f, 0.75f, 0.18f),
        )

        fun defaultChecklist() = linkedMapOf(
            "battery" to false,
            "network" to false,
            "background" to false,
            "notifications" to false,
            "temperature" to false,
            "warmup" to false,
        )
    }
}
