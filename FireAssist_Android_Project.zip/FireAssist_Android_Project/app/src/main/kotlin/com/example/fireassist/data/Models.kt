package com.example.fireassist.data

data class SensitivitySettings(
    val general: Int = 90,
    val redDot: Int = 85,
    val scope2x: Int = 80,
    val scope4x: Int = 70,
    val sniper: Int = 50,
    val freeLook: Int = 75,
)

data class HudPoint(
    val id: String,
    val label: String,
    val x: Float,
    val y: Float,
    val size: Float,
)

data class MatchSession(
    val id: Long,
    val timestamp: Long,
    val mode: String,
    val kills: Int,
    val placement: Int,
    val damage: Int,
    val notes: String,
)

data class AimResult(
    val timestamp: Long,
    val durationSeconds: Int,
    val hits: Int,
    val attempts: Int,
    val averageReactionMs: Long,
) {
    val accuracy: Int
        get() = AimScoring.accuracyPercent(hits, attempts)
}

object AimScoring {
    fun accuracyPercent(hits: Int, attempts: Int): Int {
        if (attempts <= 0) return 0
        return ((hits.toDouble() / attempts.toDouble()) * 100.0)
            .toInt()
            .coerceIn(0, 100)
    }

    fun score(hits: Int, attempts: Int, averageReactionMs: Long): Int {
        if (attempts <= 0 || hits <= 0) return 0
        val accuracy = accuracyPercent(hits, attempts)
        val speedBonus = (1200L - averageReactionMs).coerceIn(0L, 1000L) / 10L
        return (hits * 100 + accuracy * 5 + speedBonus).toInt()
    }
}
