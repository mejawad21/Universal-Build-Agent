package com.example.fireassist

import android.app.Application
import com.example.fireassist.data.FireAssistRepository

class FireAssistApplication : Application() {
    val repository: FireAssistRepository by lazy { FireAssistRepository(this) }
}
