package com.example.fireassist.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.GpsFixed
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.fireassist.ui.theme.FireAssistTheme

private enum class MainTab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Outlined.Home),
    TRAIN("Train", Icons.Outlined.GpsFixed),
    SETUP("Setup", Icons.Outlined.Tune),
    STATS("Stats", Icons.Outlined.Speed),
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FireAssistApp(viewModel: FireAssistViewModel) {
    val sensitivity by viewModel.sensitivity.collectAsStateWithLifecycle()
    val hudPoints by viewModel.hudPoints.collectAsStateWithLifecycle()
    val sessions by viewModel.sessions.collectAsStateWithLifecycle()
    val aimResults by viewModel.aimResults.collectAsStateWithLifecycle()
    val checklist by viewModel.checklist.collectAsStateWithLifecycle()
    var selectedTab by remember { mutableIntStateOf(0) }

    FireAssistTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        androidx.compose.foundation.layout.Row {
                            Icon(Icons.Outlined.Bolt, contentDescription = null)
                            Text("  FireAssist", fontWeight = FontWeight.Black)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = androidx.compose.material3.MaterialTheme.colorScheme.background,
                    ),
                )
            },
            bottomBar = {
                NavigationBar(modifier = Modifier.navigationBarsPadding()) {
                    MainTab.entries.forEachIndexed { index, tab ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label) },
                        )
                    }
                }
            },
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
            ) {
                when (MainTab.entries[selectedTab]) {
                    MainTab.HOME -> HomeScreen(
                        checklist = checklist,
                        onChecklistChange = viewModel::setChecklistItem,
                        onResetChecklist = viewModel::resetChecklist,
                        openTrainer = { selectedTab = MainTab.TRAIN.ordinal },
                    )
                    MainTab.TRAIN -> AimTrainerScreen(
                        history = aimResults,
                        onSave = viewModel::saveAimResult,
                    )
                    MainTab.SETUP -> SetupScreen(
                        sensitivity = sensitivity,
                        hudPoints = hudPoints,
                        onSensitivityChange = viewModel::saveSensitivity,
                        onResetSensitivity = viewModel::resetSensitivity,
                        onHudMove = viewModel::updateHudPoint,
                        onHudResize = viewModel::resizeHudPoint,
                        onResetHud = viewModel::resetHud,
                    )
                    MainTab.STATS -> StatsScreen(
                        sessions = sessions,
                        aimResults = aimResults,
                        onAdd = viewModel::addSession,
                        onDelete = viewModel::deleteSession,
                    )
                }
            }
        }
    }
}
