package com.example.fireassist.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.fireassist.data.AimResult
import com.example.fireassist.data.FireAssistRepository
import com.example.fireassist.data.HudPoint
import com.example.fireassist.data.MatchSession
import com.example.fireassist.data.SensitivitySettings
import kotlinx.coroutines.flow.StateFlow

class FireAssistViewModel(
    private val repository: FireAssistRepository,
) : ViewModel() {
    val sensitivity: StateFlow<SensitivitySettings> = repository.sensitivity
    val hudPoints: StateFlow<List<HudPoint>> = repository.hudPoints
    val sessions: StateFlow<List<MatchSession>> = repository.sessions
    val aimResults: StateFlow<List<AimResult>> = repository.aimResults
    val checklist: StateFlow<Map<String, Boolean>> = repository.checklist

    fun saveSensitivity(value: SensitivitySettings) = repository.saveSensitivity(value)
    fun resetSensitivity() = repository.resetSensitivity()

    fun updateHudPoint(id: String, x: Float, y: Float) {
        repository.saveHud(
            repository.hudPoints.value.map { point ->
                if (point.id == id) {
                    point.copy(
                        x = x.coerceIn(0.04f, 0.96f),
                        y = y.coerceIn(0.08f, 0.92f),
                    )
                } else point
            },
        )
    }

    fun resizeHudPoint(id: String, size: Float) {
        repository.saveHud(
            repository.hudPoints.value.map { point ->
                if (point.id == id) point.copy(size = size.coerceIn(0.08f, 0.24f))
                else point
            },
        )
    }

    fun resetHud() = repository.resetHud()
    fun addSession(session: MatchSession) = repository.addSession(session)
    fun deleteSession(id: Long) = repository.deleteSession(id)
    fun saveAimResult(result: AimResult) = repository.saveAimResult(result)
    fun setChecklistItem(id: String, checked: Boolean) =
        repository.setChecklistItem(id, checked)
    fun resetChecklist() = repository.resetChecklist()

    class Factory(
        private val repository: FireAssistRepository,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return FireAssistViewModel(repository) as T
        }
    }
}
