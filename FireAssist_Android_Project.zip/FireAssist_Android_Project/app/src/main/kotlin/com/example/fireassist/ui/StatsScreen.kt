package com.example.fireassist.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.fireassist.data.AimResult
import com.example.fireassist.data.AimScoring
import com.example.fireassist.data.MatchSession
import java.util.Locale

@Composable
internal fun StatsScreen(
    sessions: List<MatchSession>,
    aimResults: List<AimResult>,
    onAdd: (MatchSession) -> Unit,
    onDelete: (Long) -> Unit,
) {
    var mode by remember { mutableStateOf("Battle Royale") }
    var kills by remember { mutableStateOf("") }
    var placement by remember { mutableStateOf("") }
    var damage by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    val totalKills = sessions.sumOf { it.kills }
    val wins = sessions.count { it.placement == 1 }
    val averageKills = if (sessions.isEmpty()) 0.0
    else totalKills.toDouble() / sessions.size.toDouble()
    val bestAim = aimResults.maxOfOrNull {
        AimScoring.score(it.hits, it.attempts, it.averageReactionMs)
    } ?: 0

    LazyColumn(
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Text(
                "Progress tracker",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Black,
            )
            Text("Log matches to spot trends in your own performance.")
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallMetric(Modifier.weight(1f), "MATCHES", sessions.size.toString())
                SmallMetric(Modifier.weight(1f), "WINS", wins.toString())
                SmallMetric(
                    Modifier.weight(1f),
                    "AVG KILLS",
                    String.format(Locale.US, "%.1f", averageKills),
                )
                SmallMetric(Modifier.weight(1f), "BEST AIM", bestAim.toString())
            }
        }

        item {
            Card {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text("Add match", fontWeight = FontWeight.Black)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Battle Royale", "Clash Squad").forEach { value ->
                            AssistChip(
                                onClick = { mode = value },
                                label = { Text(value) },
                                leadingIcon = if (mode == value) {
                                    {
                                        Icon(
                                            Icons.Outlined.CheckCircle,
                                            contentDescription = null,
                                        )
                                    }
                                } else null,
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NumberField(
                            modifier = Modifier.weight(1f),
                            label = "Kills",
                            value = kills,
                            onChange = { kills = it },
                        )
                        NumberField(
                            modifier = Modifier.weight(1f),
                            label = "Placement",
                            value = placement,
                            onChange = { placement = it },
                        )
                        NumberField(
                            modifier = Modifier.weight(1f),
                            label = "Damage",
                            value = damage,
                            onChange = { damage = it },
                        )
                    }
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it.take(180) },
                        label = { Text("Notes") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2,
                    )
                    Button(
                        onClick = {
                            onAdd(
                                MatchSession(
                                    id = System.currentTimeMillis(),
                                    timestamp = System.currentTimeMillis(),
                                    mode = mode,
                                    kills = (kills.toIntOrNull() ?: 0).coerceAtLeast(0),
                                    placement = (placement.toIntOrNull() ?: 0).coerceAtLeast(0),
                                    damage = (damage.toIntOrNull() ?: 0).coerceAtLeast(0),
                                    notes = notes.trim(),
                                ),
                            )
                            kills = ""
                            placement = ""
                            damage = ""
                            notes = ""
                        },
                        enabled = kills.isNotBlank() || placement.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Icon(Icons.Outlined.Save, contentDescription = null)
                        Text("  Save match")
                    }
                }
            }
        }

        item {
            Text(
                "Match history",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black,
            )
        }

        if (sessions.isEmpty()) {
            item {
                OutlinedCard {
                    Text(
                        "No matches logged yet.",
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        textAlign = TextAlign.Center,
                    )
                }
            }
        }

        items(sessions, key = { it.id }) { session ->
            Card {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "${session.mode} • ${session.kills} kills",
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            "Placement ${session.placement} • ${session.damage} damage",
                            style = MaterialTheme.typography.bodySmall,
                        )
                        if (session.notes.isNotBlank()) {
                            Text(
                                session.notes,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        Text(
                            dateText(session.timestamp),
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }
                    IconButton(onClick = { onDelete(session.id) }) {
                        Icon(
                            Icons.Outlined.DeleteOutline,
                            contentDescription = "Delete match",
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun NumberField(
    modifier: Modifier,
    label: String,
    value: String,
    onChange: (String) -> Unit,
) {
    OutlinedTextField(
        value = value,
        onValueChange = { input ->
            onChange(input.filter { it.isDigit() }.take(5))
        },
        label = { Text(label) },
        modifier = modifier,
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
    )
}
