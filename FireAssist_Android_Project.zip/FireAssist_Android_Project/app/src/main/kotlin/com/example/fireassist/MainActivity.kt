package com.example.fireassist

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.fireassist.ui.FireAssistApp
import com.example.fireassist.ui.FireAssistViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val repository = (application as FireAssistApplication).repository
        setContent {
            val viewModel: FireAssistViewModel = viewModel(
                factory = FireAssistViewModel.Factory(repository),
            )
            FireAssistApp(viewModel)
        }
    }
}
