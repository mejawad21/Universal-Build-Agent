package com.example.fireassist.ui

import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BatteryChargingFull
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.GpsFixed
import androidx.compose.material.icons.outlined.Gamepad
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.OpenInNew
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private data class ChecklistDefinition(
    val id: String,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
)

private val checklistDefinitions = listOf(
    ChecklistDefinition("battery", "Battery ready", "Charge enough for the full session.", Icons.Outlined.BatteryChargingFull),
    ChecklistDefinition("network", "Stable connection", "Use your most stable Wi-Fi or mobile data.", Icons.Outlined.Wifi),
    ChecklistDefinition("background", "Close heavy apps", "Reduce unnecessary memory and processor use.", Icons.Outlined.Memory),
    ChecklistDefinition("notifications", "Reduce interruptions", "Use Do Not Disturb when appropriate.", Icons.Outlined.CheckCircle),
    ChecklistDefinition("temperature", "Device temperature normal", "Let the phone cool before a long session.", Icons.Outlined.Bolt),
    ChecklistDefinition("warmup", "Warm-up complete", "Finish a short reaction and accuracy drill.", Icons.Outlined.GpsFixed),
)

@Composable
internal fun HomeScreen(
    checklist: Map<String, Boolean>,
    onChecklistChange: (String, Boolean) -> Unit,
    onResetChecklist: () -> Unit,
    openTrainer: () -> Unit,
) {
    val context = LocalContext.current
    val device = remember { deviceSummary(context) }
    val completed = checklist.values.count { it }

    LazyColumn(
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Card(
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
            ) {
                Column(Modifier.padding(22.dp)) {
                    Icon(
                        Icons.Outlined.SportsEsports,
                        contentDescription = null,
                        modifier = Modifier.size(42.dp),
                        tint = Color.White,
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Ready for your next match?",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                    )
                    Text(
                        "Warm up, review your setup, then launch the game.",
                        color = Color.White.copy(alpha = 0.88f),
                    )
                    Spacer(Modifier.height(18.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { launchGame(context, "com.dts.freefireth") },
                            modifier = Modifier.weight(1f),
                        ) {
                            Icon(Icons.Outlined.Gamepad, contentDescription = null)
                            Text("  Free Fire")
                        }
                        Button(
                            onClick = { launchGame(context, "com.dts.freefiremax") },
                            modifier = Modifier.weight(1f),
                        ) {
                            Text("MAX")
                        }
                    }
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Outlined.Memory,
                    title = device.first,
                    subtitle = "Available RAM",
                )
                MetricCard(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Outlined.Settings,
                    title = "Android ${Build.VERSION.RELEASE}",
                    subtitle = device.second,
                )
            }
        }

        item {
            OutlinedCard(onClick = openTrainer, modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        Icons.Outlined.GpsFixed,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(40.dp),
                    )
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 14.dp),
                    ) {
                        Text("60-second aim warm-up", fontWeight = FontWeight.Bold)
                        Text(
                            "Train reaction time and target accuracy before playing.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    Icon(Icons.Outlined.OpenInNew, contentDescription = null)
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "Pre-match checklist",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                    )
                    Text("$completed of ${checklist.size} ready")
                }
                IconButton(onClick = onResetChecklist) {
                    Icon(Icons.Outlined.CheckCircle, contentDescription = "Reset checklist")
                }
            }
        }

        items(checklistDefinitions, key = { it.id }) { item ->
            Card {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(item.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 12.dp),
                    ) {
                        Text(item.title, fontWeight = FontWeight.SemiBold)
                        Text(item.subtitle, style = MaterialTheme.typography.bodySmall)
                    }
                    Checkbox(
                        checked = checklist[item.id] == true,
                        onCheckedChange = { onChecklistChange(item.id, it) },
                    )
                }
            }
        }

        item {
            FilledTonalButton(
                onClick = {
                    safeStartActivity(context, Intent(Settings.ACTION_DISPLAY_SETTINGS))
                },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Icon(Icons.Outlined.Settings, contentDescription = null)
                Text("  Open display settings")
            }
        }

        item {
            Card {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.Top,
                ) {
                    Icon(Icons.Outlined.Info, contentDescription = null)
                    Text(
                        "Fair-play companion only. FireAssist does not use overlays, " +
                            "accessibility automation, macros, auto-aim, game memory access, " +
                            "or game-file modification.",
                        modifier = Modifier.padding(start = 12.dp),
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        }
    }
}

@Composable
private fun MetricCard(
    modifier: Modifier,
    icon: ImageVector,
    title: String,
    subtitle: String,
) {
    Card(modifier = modifier) {
        Column(Modifier.padding(16.dp)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(12.dp))
            Text(title, fontWeight = FontWeight.Black)
            Text(subtitle, style = MaterialTheme.typography.bodySmall)
        }
    }
}
