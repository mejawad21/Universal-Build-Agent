package com.example.fireassist.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val Orange = Color(0xFFFF6A2A)
private val Amber = Color(0xFFFFB047)
private val DarkBackground = Color(0xFF0A0B0E)
private val DarkSurface = Color(0xFF15171C)

private val DarkColors = darkColorScheme(
    primary = Orange,
    secondary = Amber,
    background = DarkBackground,
    surface = DarkSurface,
    surfaceVariant = Color(0xFF22252C),
    onPrimary = Color.White,
    onBackground = Color(0xFFF4F4F5),
    onSurface = Color(0xFFF4F4F5),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFFB93600),
    secondary = Color(0xFF8B4C00),
    background = Color(0xFFFFF8F4),
    surface = Color.White,
    surfaceVariant = Color(0xFFFFE5D6),
)

@Composable
fun FireAssistTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            WindowCompat.getInsetsController(window, view)
                .isAppearanceLightStatusBars = !dark
        }
    }
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        content = content,
    )
}
