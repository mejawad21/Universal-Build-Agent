package com.example.fireassist.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AimScoringTest {
    @Test
    fun accuracyHandlesNoAttempts() {
        assertEquals(0, AimScoring.accuracyPercent(0, 0))
    }

    @Test
    fun accuracyUsesHitsAndAttempts() {
        assertEquals(75, AimScoring.accuracyPercent(15, 20))
    }

    @Test
    fun fasterReactionProducesHigherScore() {
        val fast = AimScoring.score(10, 12, 300)
        val slow = AimScoring.score(10, 12, 900)
        assertTrue(fast > slow)
    }
}
