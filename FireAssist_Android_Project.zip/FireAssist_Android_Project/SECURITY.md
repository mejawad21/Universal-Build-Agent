# Security and fair-play policy

FireAssist must remain a standalone training and tracking companion.

Changes that introduce game-memory reading, packet interception, automated aiming, automated input, accessibility-based gameplay, root-only game modifications, or bypasses of anti-cheat controls are outside this project's scope.

Report security issues privately to the repository maintainer.
