# FireAssist — Fair-play Free Fire companion

FireAssist is a modern Android companion that helps a player prepare, practise, and track progress without modifying or automating the game.

## Features

### Home
- Launch shortcut for Free Fire and Free Fire MAX
- Google Play fallback when the selected game is not installed
- Available-memory and Android-version summary
- Pre-match checklist
- Display-settings shortcut

### Aim trainer
- 15, 30, and 60-second drills
- Moving targets
- Hits, attempts, accuracy, reaction time, and score
- Local drill history

### Sensitivity notebook
- General
- Red Dot
- 2× Scope
- 4× Scope
- Sniper Scope
- Free Look
- Local preset storage

The values are notes only. The app does not write into game settings.

### HUD practice board
- Movable Fire, Scope, Jump, Crouch, and Move controls
- Adjustable control sizes
- Saved layout
- Copy the plan manually using the game's own HUD editor

### Progress tracker
- Battle Royale and Clash Squad match logging
- Kills, placement, damage, and notes
- Match totals, wins, average kills, and best aim score
- Local history

## Fair-play design

FireAssist deliberately does not request or use:

- Accessibility Service
- Display-over-other-apps permission
- Root access
- Game-memory access
- Game-file modification
- Auto-aim
- Recoil scripts
- Macros
- Automated touches
- Packet manipulation

It is an independent companion and is not affiliated with or endorsed by Garena.

## Build

Requirements:

- Android Studio
- JDK 17
- Android SDK 36

Build:

```bash
./gradlew testDebugUnitTest
./gradlew assembleDebug
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## GitHub build

Push the project to GitHub, open **Actions → Build Android APK**, and run the workflow. Download `FireAssist-debug-apk` after completion.

## Launch support

The app checks these public Android package IDs only to open an installed game or its Play Store page:

- `com.dts.freefireth`
- `com.dts.freefiremax`

## License

MIT License.
