-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keepclassmembers class * extends android.app.Activity {
    public void onPictureInPictureModeChanged(boolean, android.content.res.Configuration);
}
