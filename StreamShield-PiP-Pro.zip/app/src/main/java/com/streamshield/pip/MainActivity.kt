package com.streamshield.pip

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.app.PictureInPictureParams
import android.app.RemoteAction
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.Gravity
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.ByteArrayInputStream

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var dashboardContainer: LinearLayout
    private lateinit var rootContainer: FrameLayout
    private lateinit var tvStatusBadge: TextView
    private lateinit var tvShieldMetrics: TextView
    private lateinit var etUrlInput: EditText

    private var currentAspectRatio = Rational(16, 9)
    private var isPlaying = true
    private var blockedTrackerCount = 0
    private var totalRequestsCount = 0

    private val adHostDenyList = setOf(
        "doubleclick.net",
        "googlesyndication.com",
        "adservice.google.com",
        "adnxs.com",
        "scorecardresearch.com"
    )

    class PipActionReceiver : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {}
    }

    private val pipReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                ACTION_TOGGLE_PLAYBACK -> toggleVideoPlayback()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildCockpitLayout()
        setupWebView()
        setupPredictiveBack()
        updatePipParams()

        val filter = IntentFilter(ACTION_TOGGLE_PLAYBACK)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(pipReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(pipReceiver, filter)
        }

        val defaultUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
        etUrlInput.setText(defaultUrl)
        loadUrlInShield(defaultUrl)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            loadWithOverviewMode = true
            useWideViewPort = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }

        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val host = request?.url?.host?.lowercase() ?: ""
                totalRequestsCount++
                val isBlocked = adHostDenyList.any { denied -> host.contains(denied) }
                if (isBlocked) {
                    blockedTrackerCount++
                    runOnUiThread { updateTelemetryUi() }
                    return WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream("".toByteArray()))
                }
                runOnUiThread { updateTelemetryUi() }
                return super.shouldInterceptRequest(view, request)
            }
        }

        webView.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            if (!isInPictureInPictureMode) {
                updatePipParams()
            }
        }
    }

    private fun setupPredictiveBack() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    private fun loadUrlInShield(url: String) {
        val target = if (!url.startsWith("http://") && !url.startsWith("https://")) {
            "https://" + url
        } else {
            url
        }

        if (target.endsWith(".mp4") || target.endsWith(".webm") || target.endsWith(".mkv")) {
            val html = """
                <!DOCTYPE html>
                <html>
                <head>
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <style>
                        body, html { margin:0; padding:0; width:100%; height:100%; background-color:#000; display:flex; justify-content:center; align-items:center; }
                        video { width:100%; height:100%; object-fit:contain; }
                    </style>
                </head>
                <body>
                    <video id="pipVideo" src="$target" autoplay controls playsinline></video>
                </body>
                </html>
            """.trimIndent()
            webView.loadDataWithBaseURL("https://localhost", html, "text/html", "UTF-8", null)
        } else {
            webView.loadUrl(target)
        }
    }

    private fun toggleVideoPlayback() {
        isPlaying = !isPlaying
        val js = if (isPlaying) {
            "(function() { var v = document.querySelector('video'); if (v) v.play(); })()"
        } else {
            "(function() { var v = document.querySelector('video'); if (v) v.pause(); })()"
        }
        webView.evaluateJavascript(js, null)
        updatePipParams()
    }

    private fun enterPipSafe() {
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            return
        }
        val params = buildPipParams()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            enterPictureInPictureMode(params)
        }
    }

    private fun buildPipParams(): PictureInPictureParams {
        val visibleRect = Rect()
        webView.getGlobalVisibleRect(visibleRect)

        val builder = PictureInPictureParams.Builder()
            .setAspectRatio(currentAspectRatio)
            .setSourceRectHint(visibleRect)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            builder.setAutoEnterEnabled(true)
            builder.setSeamlessResizeEnabled(true)
        }

        val actions = mutableListOf<RemoteAction>()
        val playPauseIcon = if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
        val playPauseTitle = if (isPlaying) getString(R.string.action_pause) else getString(R.string.action_play)

        val intent = Intent(ACTION_TOGGLE_PLAYBACK).setPackage(packageName)
        val pendingIntent = PendingIntent.getBroadcast(
            this,
            100,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        actions.add(
            RemoteAction(
                Icon.createWithResource(this, playPauseIcon),
                playPauseTitle,
                playPauseTitle,
                pendingIntent
            )
        )

        builder.setActions(actions)
        return builder.build()
    }

    private fun updatePipParams() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        ) {
            try {
                setPictureInPictureParams(buildPipParams())
            } catch (_: Exception) {}
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            enterPipSafe()
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode) {
            dashboardContainer.visibility = View.GONE
            rootContainer.setBackgroundColor(Color.BLACK)
            webView.layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        } else {
            dashboardContainer.visibility = View.VISIBLE
            rootContainer.setBackgroundColor(Color.parseColor("#0F141C"))
            updateTelemetryUi()
        }
    }

    private fun updateTelemetryUi() {
        tvStatusBadge.text = if (isInPictureInPictureMode) "PIP MODE" else "ACTIVE SHIELD"
        tvShieldMetrics.text = "Trackers Blocked: " + blockedTrackerCount + "  |  Requests: " + totalRequestsCount
    }

    private fun buildCockpitLayout() {
        rootContainer = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#0F141C"))
        }

        dashboardContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 24)
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }

        val titleText = TextView(this).apply {
            text = "StreamShield Pro"
            textSize = 22f
            setTextColor(Color.WHITE)
            paint.isFakeBoldText = true
        }

        tvStatusBadge = TextView(this).apply {
            text = "DIAGNOSTIC IDLE"
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 12f
            setPadding(0, 4, 0, 16)
        }

        val metricsCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#192231"))
            setPadding(24, 20, 24, 20)
        }

        tvShieldMetrics = TextView(this).apply {
            text = "Trackers Blocked: 0  |  Requests: 0"
            setTextColor(Color.parseColor("#90A4AE"))
            textSize = 13f
        }
        metricsCard.addView(tvShieldMetrics)

        etUrlInput = EditText(this).apply {
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            hint = "Enter direct video link or web URL"
            setSingleLine()
            setPadding(20, 20, 20, 20)
            setBackgroundColor(Color.parseColor("#151D2A"))
        }

        val btnLoad = Button(this).apply {
            text = "Load Stream"
            setBackgroundColor(Color.parseColor("#00E5FF"))
            setTextColor(Color.BLACK)
            setOnClickListener {
                loadUrlInShield(etUrlInput.text.toString().trim())
            }
        }

        val ratioContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 16, 0, 16)
        }

        val btn16x9 = Button(this).apply {
            text = "16:9"
            setOnClickListener {
                currentAspectRatio = Rational(16, 9)
                updatePipParams()
            }
        }
        val btn1x1 = Button(this).apply {
            text = "1:1"
            setOnClickListener {
                currentAspectRatio = Rational(1, 1)
                updatePipParams()
            }
        }
        val btn9x16 = Button(this).apply {
            text = "9:16"
            setOnClickListener {
                currentAspectRatio = Rational(9, 16)
                updatePipParams()
            }
        }
        ratioContainer.addView(btn16x9)
        ratioContainer.addView(btn1x1)
        ratioContainer.addView(btn9x16)

        val btnEnterPip = Button(this).apply {
            text = "Enter Floating PiP"
            setBackgroundColor(Color.parseColor("#00E676"))
            setTextColor(Color.BLACK)
            setCompoundDrawablesWithIntrinsicBounds(
                ContextCompat.getDrawable(this@MainActivity, R.drawable.ic_pip_enter),
                null,
                null,
                null
            )
            setOnClickListener {
                enterPipSafe()
            }
        }

        val videoFrame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1.0f
            ).apply {
                topMargin = 20
                bottomMargin = 20
            }
            setBackgroundColor(Color.BLACK)
        }

        webView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        videoFrame.addView(webView)

        dashboardContainer.addView(titleText)
        dashboardContainer.addView(tvStatusBadge)
        dashboardContainer.addView(metricsCard)
        dashboardContainer.addView(etUrlInput)
        dashboardContainer.addView(btnLoad)
        dashboardContainer.addView(ratioContainer)
        dashboardContainer.addView(videoFrame)
        dashboardContainer.addView(btnEnterPip)

        rootContainer.addView(dashboardContainer)
        setContentView(rootContainer)
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(pipReceiver)
        webView.destroy()
    }

    companion object {
        const val ACTION_TOGGLE_PLAYBACK = "com.streamshield.pip.ACTION_TOGGLE_PLAYBACK"
    }
}
