@echo off
cd /d %~dp0android
call gradlew.bat %*
