import 'package:flutter/material.dart';
import 'package:tubegrab/models/media_info.dart';

class MediaPreviewCard extends StatelessWidget {
  const MediaPreviewCard({
    super.key,
    required this.media,
    required this.selectedId,
    required this.onSelected,
    required this.onDownload,
  });

  final MediaInfo media;
  final String? selectedId;
  final ValueChanged<String> onSelected;
  final VoidCallback onDownload;

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(18),
              child: AspectRatio(
                aspectRatio: 16 / 9,
                child: media.thumbnailUrl.isEmpty
                    ? Container(
                        color: Theme.of(context).colorScheme.surfaceContainerHigh,
                        child: const Center(
                          child: Icon(Icons.ondemand_video_rounded, size: 54),
                        ),
                      )
                    : Image.network(
                        media.thumbnailUrl,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          color:
                              Theme.of(context).colorScheme.surfaceContainerHigh,
                          child: const Center(
                            child: Icon(Icons.broken_image_outlined, size: 42),
                          ),
                        ),
                      ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              media.title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                Expanded(
                  child: Text(
                    media.channel,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                if (media.durationSeconds > 0)
                  Text(_formatDuration(media.durationSeconds)),
              ],
            ),
            const SizedBox(height: 18),
            Text(
              'Choose format',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
            ),
            const SizedBox(height: 8),
            ...media.options.map(
              (option) => RadioListTile<String>(
                value: option.id,
                groupValue: selectedId,
                onChanged: (value) {
                  if (value != null) onSelected(value);
                },
                contentPadding: EdgeInsets.zero,
                title: Text(option.label),
                subtitle: Text(
                  '${option.format.toUpperCase()} • '
                  '${option.kind == MediaKind.audio ? 'Audio' : 'Video'}'
                  '${option.contentLength == null ? '' : ' • ${_formatBytes(option.contentLength!)}'}',
                ),
                secondary: Icon(
                  option.kind == MediaKind.audio
                      ? Icons.graphic_eq_rounded
                      : Icons.high_quality_rounded,
                ),
              ),
            ),
            const SizedBox(height: 10),
            FilledButton.icon(
              onPressed: selectedId == null ? null : onDownload,
              style: FilledButton.styleFrom(
                minimumSize: const Size.fromHeight(54),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              icon: const Icon(Icons.download_rounded),
              label: const Text('Download'),
            ),
          ],
        ),
      ),
    );
  }

  String _formatDuration(int seconds) {
    final duration = Duration(seconds: seconds);
    final hours = duration.inHours;
    final minutes = duration.inMinutes.remainder(60).toString().padLeft(2, '0');
    final secs = duration.inSeconds.remainder(60).toString().padLeft(2, '0');
    return hours > 0 ? '$hours:$minutes:$secs' : '$minutes:$secs';
  }

  String _formatBytes(int bytes) {
    if (bytes >= 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
    }
    if (bytes >= 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    return '${(bytes / 1024).toStringAsFixed(0)} KB';
  }
}
