import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:tubegrab/models/media_info.dart';

class ResolverException implements Exception {
  const ResolverException(this.message);
  final String message;

  @override
  String toString() => message;
}

class ResolverApi {
  ResolverApi({
    http.Client? client,
    String? baseUrl,
  })  : _client = client ?? http.Client(),
        _baseUrl = baseUrl ??
            const String.fromEnvironment(
              'TUBEGRAB_API_BASE_URL',
              defaultValue: '',
            );

  final http.Client _client;
  final String _baseUrl;

  Future<MediaInfo> fetch(String sourceUrl) async {
    final uri = Uri.tryParse(sourceUrl.trim());
    if (uri == null || uri.scheme != 'https' || uri.host.isEmpty) {
      throw const ResolverException('Enter a valid HTTPS media link.');
    }

    if (_isDirectMedia(uri)) {
      return _directMedia(uri);
    }

    if (_baseUrl.isEmpty) {
      throw const ResolverException(
        'This link needs a configured authorized resolver backend. '
        'Build with --dart-define=TUBEGRAB_API_BASE_URL=https://your-api.example',
      );
    }

    final endpoint = Uri.parse('${_baseUrl.replaceAll(RegExp(r'/$'), '')}/v1/resolve');
    final response = await _client
        .post(
          endpoint,
          headers: const {'content-type': 'application/json'},
          body: jsonEncode({'url': uri.toString()}),
        )
        .timeout(const Duration(seconds: 25));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      final message = _readError(response.body) ??
          'Resolver returned HTTP ${response.statusCode}.';
      throw ResolverException(message);
    }

    final json = jsonDecode(response.body);
    if (json is! Map<String, dynamic>) {
      throw const ResolverException('Resolver returned an invalid response.');
    }

    final result = MediaInfo.fromJson(json, sourceUrl);
    if (result.options.isEmpty) {
      throw const ResolverException(
        'No authorized downloadable formats were returned.',
      );
    }
    return result;
  }

  bool _isDirectMedia(Uri uri) {
    final path = uri.path.toLowerCase();
    return const ['.mp4', '.m4a', '.mp3', '.webm', '.mov']
        .any(path.endsWith);
  }

  MediaInfo _directMedia(Uri uri) {
    final fileName = uri.pathSegments.isEmpty || uri.pathSegments.last.isEmpty
        ? 'tubegrab_download.mp4'
        : uri.pathSegments.last;
    final extension = fileName.split('.').last.toLowerCase();
    final audio = extension == 'mp3' || extension == 'm4a';
    final mimeType = switch (extension) {
      'mp3' => 'audio/mpeg',
      'm4a' => 'audio/mp4',
      'webm' => audio ? 'audio/webm' : 'video/webm',
      'mov' => 'video/quicktime',
      _ => 'video/mp4',
    };

    return MediaInfo(
      sourceUrl: uri.toString(),
      title: fileName,
      channel: uri.host,
      durationSeconds: 0,
      thumbnailUrl: '',
      options: [
        MediaOption(
          id: 'direct-$extension',
          label: audio ? 'Original audio' : 'Original video',
          kind: audio ? MediaKind.audio : MediaKind.video,
          format: extension,
          url: uri.toString(),
          fileName: fileName,
          mimeType: mimeType,
        ),
      ],
    );
  }

  String? _readError(String body) {
    try {
      final json = jsonDecode(body);
      if (json is Map<String, dynamic>) return json['error'] as String?;
    } catch (_) {
      return null;
    }
    return null;
  }
}
