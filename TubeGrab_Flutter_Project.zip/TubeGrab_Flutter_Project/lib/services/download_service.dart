import 'dart:async';
import 'dart:convert';

import 'package:background_downloader/background_downloader.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tubegrab/models/download_entry.dart';
import 'package:tubegrab/models/media_info.dart';

class DownloadService extends ChangeNotifier {
  static const _prefsKey = 'tubegrab_download_history_v1';
  static const _group = 'tubegrab';

  final Map<String, DownloadTask> _tasks = {};
  final List<DownloadEntry> _entries = [];
  StreamSubscription<TaskUpdate>? _subscription;

  List<DownloadEntry> get entries {
    final copy = List<DownloadEntry>.from(_entries);
    copy.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return List.unmodifiable(copy);
  }

  List<DownloadEntry> get active => entries
      .where((item) => !{
            DownloadState.complete,
            DownloadState.failed,
            DownloadState.canceled,
          }.contains(item.state))
      .toList();

  List<DownloadEntry> get completed =>
      entries.where((item) => item.state == DownloadState.complete).toList();

  Future<void> initialize() async {
    final prefs = await SharedPreferences.getInstance();
    _entries.addAll(DownloadEntry.decodeList(prefs.getString(_prefsKey)));

    FileDownloader().configureNotification(
      running: const TaskNotification(
        'Downloading {displayName}',
        '{progress} • {filename}',
      ),
      paused: const TaskNotification(
        'Download paused',
        '{displayName}',
      ),
      complete: const TaskNotification(
        'Download complete',
        '{displayName}',
      ),
      error: const TaskNotification(
        'Download failed',
        '{displayName}',
      ),
      canceled: const TaskNotification(
        'Download canceled',
        '{displayName}',
      ),
      progressBar: true,
      tapOpensFile: true,
    );

    _subscription = FileDownloader().updates.listen(_handleUpdate);
    await FileDownloader().start(
      doTrackTasks: true,
      doRescheduleKilledTasks: true,
    );
    notifyListeners();
  }

  Future<void> enqueue(MediaInfo media, MediaOption option) async {
    final meta = jsonEncode({
      'title': media.title,
      'mime_type': option.mimeType,
      'is_audio': option.kind == MediaKind.audio,
    });

    final task = DownloadTask(
      url: option.url,
      filename: _safeFileName(option.fileName),
      directory: 'TubeGrab',
      baseDirectory: BaseDirectory.applicationSupport,
      group: _group,
      updates: Updates.statusAndProgress,
      retries: 3,
      allowPause: true,
      displayName: media.title,
      metaData: meta,
    );

    _tasks[task.taskId] = task;
    _upsert(
      DownloadEntry(
        taskId: task.taskId,
        title: media.title,
        fileName: task.filename,
        mimeType: option.mimeType,
        isAudio: option.kind == MediaKind.audio,
        createdAt: DateTime.now(),
        state: DownloadState.queued,
        expectedBytes: option.contentLength,
      ),
    );

    final accepted = await FileDownloader().enqueue(task);
    if (!accepted) {
      _update(
        task.taskId,
        (entry) => entry.copyWith(
          state: DownloadState.failed,
          error: 'The Android download queue rejected this task.',
        ),
      );
    }
  }

  Future<void> pause(DownloadEntry entry) async {
    final task = await _task(entry.taskId);
    if (task != null) await FileDownloader().pause(task);
  }

  Future<void> resume(DownloadEntry entry) async {
    final task = await _task(entry.taskId);
    if (task != null) await FileDownloader().resume(task);
  }

  Future<void> cancel(DownloadEntry entry) =>
      FileDownloader().cancelTaskWithId(entry.taskId);

  Future<bool> open(DownloadEntry entry) async {
    final path = entry.localPath;
    if (path == null || path.isEmpty) return false;
    return FileDownloader().openFile(
      filePath: path,
      mimeType: entry.mimeType,
    );
  }

  Future<void> removeFromHistory(DownloadEntry entry) async {
    _entries.removeWhere((item) => item.taskId == entry.taskId);
    await _persist();
    notifyListeners();
  }

  Future<void> clearCompleted() async {
    _entries.removeWhere((item) => item.state == DownloadState.complete);
    await _persist();
    notifyListeners();
  }

  Future<DownloadTask?> _task(String taskId) async {
    if (_tasks.containsKey(taskId)) return _tasks[taskId];
    final task = await FileDownloader().taskForId(taskId);
    if (task is DownloadTask) {
      _tasks[taskId] = task;
      return task;
    }
    return null;
  }

  void _handleUpdate(TaskUpdate update) {
    if (update is TaskProgressUpdate) {
      final progress = update.progress.clamp(0.0, 1.0);
      _update(
        update.task.taskId,
        (entry) => entry.copyWith(
          state: DownloadState.running,
          progress: progress,
          speedMbps: update.hasNetworkSpeed ? update.networkSpeed : null,
          clearSpeed: !update.hasNetworkSpeed,
          timeRemaining:
              update.hasTimeRemaining ? update.timeRemaining : null,
          clearTimeRemaining: !update.hasTimeRemaining,
          expectedBytes:
              update.hasExpectedFileSize ? update.expectedFileSize : null,
          clearError: true,
        ),
      );
      return;
    }

    if (update is TaskStatusUpdate) {
      final task = update.task;
      if (task is DownloadTask) _tasks[task.taskId] = task;

      final status = update.status;
      if (status == TaskStatus.complete && task is DownloadTask) {
        unawaited(_finalize(task, update.mimeType));
      } else if (status == TaskStatus.running) {
        _setState(task.taskId, DownloadState.running);
      } else if (status == TaskStatus.enqueued) {
        _setState(task.taskId, DownloadState.queued);
      } else if (status == TaskStatus.paused) {
        _setState(task.taskId, DownloadState.paused);
      } else if (status == TaskStatus.waitingToRetry) {
        _setState(task.taskId, DownloadState.retrying);
      } else if (status == TaskStatus.canceled) {
        _setState(task.taskId, DownloadState.canceled);
      } else if (status == TaskStatus.failed ||
          status == TaskStatus.notFound) {
        _update(
          task.taskId,
          (entry) => entry.copyWith(
            state: DownloadState.failed,
            error: update.exception?.description ?? 'Download failed.',
            clearSpeed: true,
            clearTimeRemaining: true,
          ),
        );
      }
    }
  }

  Future<void> _finalize(DownloadTask task, String? detectedMime) async {
    final entry = _find(task.taskId);
    final mime = detectedMime ?? entry?.mimeType;

    String? path;
    try {
      path = await FileDownloader().moveToSharedStorage(
        task,
        SharedStorage.downloads,
        directory: 'TubeGrab',
        mimeType: mime,
      );
    } catch (_) {
      path = await task.filePath();
    }

    _update(
      task.taskId,
      (item) => item.copyWith(
        state: DownloadState.complete,
        progress: 1,
        localPath: path,
        clearSpeed: true,
        clearTimeRemaining: true,
        clearError: true,
      ),
    );
  }

  void _setState(String id, DownloadState state) {
    _update(
      id,
      (entry) => entry.copyWith(
        state: state,
        clearSpeed: state != DownloadState.running,
        clearTimeRemaining: state != DownloadState.running,
      ),
    );
  }

  DownloadEntry? _find(String id) {
    for (final entry in _entries) {
      if (entry.taskId == id) return entry;
    }
    return null;
  }

  void _upsert(DownloadEntry entry) {
    final index = _entries.indexWhere((item) => item.taskId == entry.taskId);
    if (index == -1) {
      _entries.add(entry);
    } else {
      _entries[index] = entry;
    }
    unawaited(_persist());
    notifyListeners();
  }

  void _update(
    String id,
    DownloadEntry Function(DownloadEntry entry) transform,
  ) {
    final index = _entries.indexWhere((item) => item.taskId == id);
    if (index == -1) return;
    _entries[index] = transform(_entries[index]);
    unawaited(_persist());
    notifyListeners();
  }

  Future<void> _persist() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefsKey, DownloadEntry.encodeList(_entries));
  }

  String _safeFileName(String raw) {
    final cleaned = raw
        .replaceAll(RegExp(r'[\\/:*?"<>|]'), '_')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    return cleaned.isEmpty ? 'tubegrab_download' : cleaned;
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }
}
