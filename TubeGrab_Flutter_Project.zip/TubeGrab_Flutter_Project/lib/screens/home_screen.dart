import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:tubegrab/models/media_info.dart';
import 'package:tubegrab/services/download_service.dart';
import 'package:tubegrab/services/resolver_api.dart';
import 'package:tubegrab/widgets/media_preview_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    super.key,
    required this.resolverApi,
    required this.downloadService,
    required this.openLibrary,
  });

  final ResolverApi resolverApi;
  final DownloadService downloadService;
  final VoidCallback openLibrary;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _controller = TextEditingController();
  MediaInfo? _media;
  String? _selectedOptionId;
  bool _fetching = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _paste() async {
    HapticFeedback.selectionClick();
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    if (!mounted) return;
    final text = data?.text?.trim();
    if (text != null && text.isNotEmpty) {
      _controller.text = text;
      _controller.selection =
          TextSelection.collapsed(offset: _controller.text.length);
    }
  }

  Future<void> _fetch() async {
    HapticFeedback.mediumImpact();
    FocusScope.of(context).unfocus();
    setState(() {
      _fetching = true;
      _media = null;
      _selectedOptionId = null;
    });

    try {
      final media = await widget.resolverApi.fetch(_controller.text);
      if (!mounted) return;
      setState(() {
        _media = media;
        _selectedOptionId =
            media.options.isEmpty ? null : media.options.first.id;
      });
    } on ResolverException catch (error) {
      if (!mounted) return;
      _show(error.message);
    } catch (_) {
      if (!mounted) return;
      _show('Unable to fetch media details. Check your resolver server.');
    } finally {
      if (mounted) setState(() => _fetching = false);
    }
  }

  Future<void> _download() async {
    final media = _media;
    final selected = media?.options
        .where((option) => option.id == _selectedOptionId)
        .firstOrNull;
    if (media == null || selected == null) return;

    HapticFeedback.heavyImpact();
    await widget.downloadService.enqueue(media, selected);
    if (!mounted) return;
    _show('Download added to the background queue.');
    widget.openLibrary();
  }

  void _show(String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: CustomScrollView(
        slivers: [
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 22, 20, 8),
            sliver: SliverToBoxAdapter(
              child: Row(
                children: [
                  Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.primary,
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: const Icon(Icons.download_rounded, color: Colors.white),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'TubeGrab',
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        Text('Save authorized media for offline playback'),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.all(20),
            sliver: SliverList.list(
              children: [
                Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(24),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        TextField(
                          controller: _controller,
                          keyboardType: TextInputType.url,
                          autocorrect: false,
                          enableSuggestions: false,
                          textInputAction: TextInputAction.go,
                          onSubmitted: (_) => _fetch(),
                          decoration: InputDecoration(
                            labelText: 'Video or media link',
                            hintText: 'https://…',
                            prefixIcon: const Icon(Icons.link_rounded),
                            suffixIcon: TextButton.icon(
                              onPressed: _paste,
                              icon: const Icon(Icons.content_paste_rounded),
                              label: const Text('Paste'),
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        FilledButton.icon(
                          onPressed: _fetching ? null : _fetch,
                          style: FilledButton.styleFrom(
                            minimumSize: const Size.fromHeight(54),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                            ),
                          ),
                          icon: _fetching
                              ? const SizedBox.square(
                                  dimension: 20,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2.5,
                                  ),
                                )
                              : const Icon(Icons.search_rounded),
                          label: Text(_fetching ? 'Fetching…' : 'Fetch'),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                if (_media != null)
                  MediaPreviewCard(
                    media: _media!,
                    selectedId: _selectedOptionId,
                    onSelected: (id) =>
                        setState(() => _selectedOptionId = id),
                    onDownload: _download,
                  )
                else if (!_fetching)
                  const _EmptyHome(),
                const SizedBox(height: 30),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _EmptyHome extends StatelessWidget {
  const _EmptyHome();

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            Icon(
              Icons.play_circle_outline_rounded,
              size: 64,
              color: Theme.of(context).colorScheme.primary,
            ),
            const SizedBox(height: 14),
            Text(
              'Paste a link to begin',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
            ),
            const SizedBox(height: 6),
            const Text(
              'Direct HTTPS media links work immediately. Platform links use '
              'the authorized resolver API configured at build time.',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
