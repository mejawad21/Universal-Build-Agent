import 'dart:io';

import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:tubegrab/models/download_entry.dart';
import 'package:video_player/video_player.dart';

class PlayerScreen extends StatelessWidget {
  const PlayerScreen({super.key, required this.entry});
  final DownloadEntry entry;

  @override
  Widget build(BuildContext context) {
    return entry.isAudio
        ? _AudioPlayerScreen(entry: entry)
        : _VideoPlayerScreen(entry: entry);
  }
}

class _VideoPlayerScreen extends StatefulWidget {
  const _VideoPlayerScreen({required this.entry});
  final DownloadEntry entry;

  @override
  State<_VideoPlayerScreen> createState() => _VideoPlayerScreenState();
}

class _VideoPlayerScreenState extends State<_VideoPlayerScreen> {
  VideoPlayerController? _controller;
  Object? _error;

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    final path = widget.entry.localPath;
    if (path == null) return;

    try {
      final controller = path.startsWith('content://')
          ? VideoPlayerController.contentUri(Uri.parse(path))
          : VideoPlayerController.file(File(path));
      await controller.initialize();
      await controller.setLooping(false);
      if (!mounted) {
        await controller.dispose();
        return;
      }
      setState(() => _controller = controller);
    } catch (error) {
      if (mounted) setState(() => _error = error);
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = _controller;
    return Scaffold(
      appBar: AppBar(title: Text(widget.entry.title)),
      body: Center(
        child: _error != null
            ? const Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'This file could not be played by the device decoder.',
                  textAlign: TextAlign.center,
                ),
              )
            : controller == null
                ? const CircularProgressIndicator()
                : Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      AspectRatio(
                        aspectRatio: controller.value.aspectRatio,
                        child: VideoPlayer(controller),
                      ),
                      const SizedBox(height: 18),
                      VideoProgressIndicator(
                        controller,
                        allowScrubbing: true,
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                      ),
                      ValueListenableBuilder(
                        valueListenable: controller,
                        builder: (_, value, __) => IconButton.filled(
                          onPressed: () {
                            value.isPlaying
                                ? controller.pause()
                                : controller.play();
                          },
                          iconSize: 34,
                          icon: Icon(
                            value.isPlaying
                                ? Icons.pause_rounded
                                : Icons.play_arrow_rounded,
                          ),
                        ),
                      ),
                    ],
                  ),
      ),
    );
  }
}

class _AudioPlayerScreen extends StatefulWidget {
  const _AudioPlayerScreen({required this.entry});
  final DownloadEntry entry;

  @override
  State<_AudioPlayerScreen> createState() => _AudioPlayerScreenState();
}

class _AudioPlayerScreenState extends State<_AudioPlayerScreen> {
  final AudioPlayer _player = AudioPlayer();
  Object? _error;

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    final path = widget.entry.localPath;
    if (path == null) return;
    try {
      final uri = path.startsWith('content://') ? Uri.parse(path) : Uri.file(path);
      await _player.setAudioSource(AudioSource.uri(uri));
    } catch (error) {
      if (mounted) setState(() => _error = error);
    }
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.entry.title)),
      body: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.graphic_eq_rounded,
              size: 112,
              color: Theme.of(context).colorScheme.primary,
            ),
            const SizedBox(height: 24),
            Text(
              widget.entry.title,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
            ),
            const SizedBox(height: 30),
            if (_error != null)
              const Text('This audio file could not be played.')
            else ...[
              StreamBuilder<Duration>(
                stream: _player.positionStream,
                initialData: Duration.zero,
                builder: (context, positionSnapshot) {
                  return StreamBuilder<Duration?>(
                    stream: _player.durationStream,
                    builder: (context, durationSnapshot) {
                      final duration = durationSnapshot.data ?? Duration.zero;
                      final position = positionSnapshot.data ?? Duration.zero;
                      final max = duration.inMilliseconds.toDouble().clamp(1, double.infinity);
                      return Slider(
                        value: position.inMilliseconds
                            .toDouble()
                            .clamp(0, max),
                        max: max,
                        onChanged: (value) =>
                            _player.seek(Duration(milliseconds: value.round())),
                      );
                    },
                  );
                },
              ),
              StreamBuilder<PlayerState>(
                stream: _player.playerStateStream,
                builder: (context, snapshot) {
                  final playing = snapshot.data?.playing ?? false;
                  return IconButton.filled(
                    onPressed: playing ? _player.pause : _player.play,
                    iconSize: 40,
                    icon: Icon(
                      playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                    ),
                  );
                },
              ),
            ],
          ],
        ),
      ),
    );
  }
}
