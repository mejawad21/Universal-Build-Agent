import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:tubegrab/models/download_entry.dart';
import 'package:tubegrab/screens/player_screen.dart';
import 'package:tubegrab/services/download_service.dart';

class LibraryScreen extends StatelessWidget {
  const LibraryScreen({super.key, required this.downloadService});

  final DownloadService downloadService;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: AnimatedBuilder(
        animation: downloadService,
        builder: (context, _) {
          final active = downloadService.active;
          final completed = downloadService.completed;

          return CustomScrollView(
            slivers: [
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(20, 22, 20, 8),
                sliver: SliverToBoxAdapter(
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Library',
                          style: Theme.of(context)
                              .textTheme
                              .headlineMedium
                              ?.copyWith(fontWeight: FontWeight.w900),
                        ),
                      ),
                      if (completed.isNotEmpty)
                        TextButton(
                          onPressed: downloadService.clearCompleted,
                          child: const Text('Clear history'),
                        ),
                    ],
                  ),
                ),
              ),
              if (active.isNotEmpty) ...[
                const _SectionTitle(title: 'Active downloads'),
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  sliver: SliverList.separated(
                    itemBuilder: (_, index) => _ActiveDownloadCard(
                      entry: active[index],
                      service: downloadService,
                    ),
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemCount: active.length,
                  ),
                ),
              ],
              const _SectionTitle(title: 'Saved files'),
              if (completed.isEmpty)
                const SliverPadding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  sliver: SliverToBoxAdapter(child: _EmptyLibrary()),
                )
              else
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 28),
                  sliver: SliverList.separated(
                    itemBuilder: (_, index) => _SavedFileCard(
                      entry: completed[index],
                      service: downloadService,
                    ),
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemCount: completed.length,
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.title});
  final String title;

  @override
  Widget build(BuildContext context) {
    return SliverPadding(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 10),
      sliver: SliverToBoxAdapter(
        child: Text(
          title,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w800,
              ),
        ),
      ),
    );
  }
}

class _ActiveDownloadCard extends StatelessWidget {
  const _ActiveDownloadCard({
    required this.entry,
    required this.service,
  });

  final DownloadEntry entry;
  final DownloadService service;

  @override
  Widget build(BuildContext context) {
    final percent = (entry.progress * 100).clamp(0, 100).round();
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                _MediaIcon(isAudio: entry.isAudio),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        entry.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        _statusText(entry),
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
                Text('$percent%'),
              ],
            ),
            const SizedBox(height: 14),
            LinearProgressIndicator(
              value: entry.state == DownloadState.retrying
                  ? null
                  : entry.progress.clamp(0, 1),
              minHeight: 7,
              borderRadius: BorderRadius.circular(20),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: Text(
                    [
                      if (entry.speedMbps != null)
                        '${entry.speedMbps!.toStringAsFixed(1)} MB/s',
                      if (entry.timeRemaining != null)
                        '${_duration(entry.timeRemaining!)} left',
                    ].join(' • '),
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ),
                if (entry.state == DownloadState.paused)
                  IconButton(
                    onPressed: () {
                      HapticFeedback.selectionClick();
                      service.resume(entry);
                    },
                    icon: const Icon(Icons.play_arrow_rounded),
                    tooltip: 'Resume',
                  )
                else
                  IconButton(
                    onPressed: () {
                      HapticFeedback.selectionClick();
                      service.pause(entry);
                    },
                    icon: const Icon(Icons.pause_rounded),
                    tooltip: 'Pause',
                  ),
                IconButton(
                  onPressed: () {
                    HapticFeedback.mediumImpact();
                    service.cancel(entry);
                  },
                  icon: const Icon(Icons.close_rounded),
                  tooltip: 'Cancel',
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  String _statusText(DownloadEntry entry) {
    return switch (entry.state) {
      DownloadState.queued => 'Waiting in queue',
      DownloadState.running => entry.fileName,
      DownloadState.paused => 'Paused',
      DownloadState.retrying => 'Waiting to retry',
      DownloadState.failed => entry.error ?? 'Failed',
      DownloadState.canceled => 'Canceled',
      DownloadState.complete => 'Complete',
    };
  }

  static String _duration(Duration duration) {
    final minutes = duration.inMinutes;
    final seconds = duration.inSeconds.remainder(60);
    return minutes > 0 ? '${minutes}m ${seconds}s' : '${seconds}s';
  }
}

class _SavedFileCard extends StatelessWidget {
  const _SavedFileCard({
    required this.entry,
    required this.service,
  });

  final DownloadEntry entry;
  final DownloadService service;

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        leading: _MediaIcon(isAudio: entry.isAudio),
        title: Text(
          entry.title,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
        subtitle: Text(entry.fileName),
        onTap: entry.localPath == null
            ? null
            : () {
                HapticFeedback.selectionClick();
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => PlayerScreen(entry: entry),
                  ),
                );
              },
        trailing: PopupMenuButton<String>(
          onSelected: (value) async {
            if (value == 'open') {
              await service.open(entry);
            } else if (value == 'remove') {
              await service.removeFromHistory(entry);
            }
          },
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'open', child: Text('Open externally')),
            PopupMenuItem(value: 'remove', child: Text('Remove from history')),
          ],
        ),
      ),
    );
  }
}

class _MediaIcon extends StatelessWidget {
  const _MediaIcon({required this.isAudio});
  final bool isAudio;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 48,
      height: 48,
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.16),
        borderRadius: BorderRadius.circular(15),
      ),
      child: Icon(
        isAudio ? Icons.graphic_eq_rounded : Icons.movie_rounded,
        color: Theme.of(context).colorScheme.primary,
      ),
    );
  }
}

class _EmptyLibrary extends StatelessWidget {
  const _EmptyLibrary();

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
      child: const Padding(
        padding: EdgeInsets.all(28),
        child: Column(
          children: [
            Icon(Icons.folder_open_rounded, size: 56),
            SizedBox(height: 12),
            Text(
              'No saved files yet',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
            ),
            SizedBox(height: 6),
            Text(
              'Completed downloads appear here and are also saved in '
              'Downloads/TubeGrab.',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
