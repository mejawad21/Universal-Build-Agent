enum MediaKind { video, audio }

class MediaOption {
  const MediaOption({
    required this.id,
    required this.label,
    required this.kind,
    required this.format,
    required this.url,
    required this.fileName,
    required this.mimeType,
    this.contentLength,
  });

  final String id;
  final String label;
  final MediaKind kind;
  final String format;
  final String url;
  final String fileName;
  final String mimeType;
  final int? contentLength;

  factory MediaOption.fromJson(Map<String, dynamic> json) {
    final kindValue = (json['kind'] as String? ?? 'video').toLowerCase();
    return MediaOption(
      id: json['id'] as String? ?? '${kindValue}_${json['format'] ?? 'file'}',
      label: json['label'] as String? ?? 'Download',
      kind: kindValue == 'audio' ? MediaKind.audio : MediaKind.video,
      format: json['format'] as String? ?? 'mp4',
      url: json['url'] as String? ?? '',
      fileName: json['filename'] as String? ?? 'tubegrab_download.mp4',
      mimeType: json['mime_type'] as String? ??
          (kindValue == 'audio' ? 'audio/mp4' : 'video/mp4'),
      contentLength: (json['content_length'] as num?)?.toInt(),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'label': label,
        'kind': kind.name,
        'format': format,
        'url': url,
        'filename': fileName,
        'mime_type': mimeType,
        'content_length': contentLength,
      };
}

class MediaInfo {
  const MediaInfo({
    required this.sourceUrl,
    required this.title,
    required this.channel,
    required this.durationSeconds,
    required this.thumbnailUrl,
    required this.options,
  });

  final String sourceUrl;
  final String title;
  final String channel;
  final int durationSeconds;
  final String thumbnailUrl;
  final List<MediaOption> options;

  factory MediaInfo.fromJson(Map<String, dynamic> json, String sourceUrl) {
    final rawOptions = json['options'] as List<dynamic>? ?? const [];
    return MediaInfo(
      sourceUrl: sourceUrl,
      title: json['title'] as String? ?? 'Untitled media',
      channel: json['channel'] as String? ?? 'Unknown creator',
      durationSeconds: (json['duration_seconds'] as num?)?.toInt() ?? 0,
      thumbnailUrl: json['thumbnail_url'] as String? ?? '',
      options: rawOptions
          .whereType<Map<String, dynamic>>()
          .map(MediaOption.fromJson)
          .where((item) => item.url.startsWith('https://'))
          .toList(),
    );
  }
}
