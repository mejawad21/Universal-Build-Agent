import 'dart:convert';

enum DownloadState {
  queued,
  running,
  paused,
  retrying,
  complete,
  failed,
  canceled,
}

class DownloadEntry {
  const DownloadEntry({
    required this.taskId,
    required this.title,
    required this.fileName,
    required this.mimeType,
    required this.isAudio,
    required this.createdAt,
    required this.state,
    this.progress = 0,
    this.speedMbps,
    this.timeRemaining,
    this.expectedBytes,
    this.localPath,
    this.error,
  });

  final String taskId;
  final String title;
  final String fileName;
  final String mimeType;
  final bool isAudio;
  final DateTime createdAt;
  final DownloadState state;
  final double progress;
  final double? speedMbps;
  final Duration? timeRemaining;
  final int? expectedBytes;
  final String? localPath;
  final String? error;

  DownloadEntry copyWith({
    DownloadState? state,
    double? progress,
    double? speedMbps,
    bool clearSpeed = false,
    Duration? timeRemaining,
    bool clearTimeRemaining = false,
    int? expectedBytes,
    String? localPath,
    String? error,
    bool clearError = false,
  }) {
    return DownloadEntry(
      taskId: taskId,
      title: title,
      fileName: fileName,
      mimeType: mimeType,
      isAudio: isAudio,
      createdAt: createdAt,
      state: state ?? this.state,
      progress: progress ?? this.progress,
      speedMbps: clearSpeed ? null : speedMbps ?? this.speedMbps,
      timeRemaining:
          clearTimeRemaining ? null : timeRemaining ?? this.timeRemaining,
      expectedBytes: expectedBytes ?? this.expectedBytes,
      localPath: localPath ?? this.localPath,
      error: clearError ? null : error ?? this.error,
    );
  }

  Map<String, dynamic> toJson() => {
        'task_id': taskId,
        'title': title,
        'file_name': fileName,
        'mime_type': mimeType,
        'is_audio': isAudio,
        'created_at': createdAt.toIso8601String(),
        'state': state.name,
        'progress': progress,
        'expected_bytes': expectedBytes,
        'local_path': localPath,
        'error': error,
      };

  factory DownloadEntry.fromJson(Map<String, dynamic> json) {
    return DownloadEntry(
      taskId: json['task_id'] as String,
      title: json['title'] as String? ?? 'Download',
      fileName: json['file_name'] as String? ?? 'file',
      mimeType: json['mime_type'] as String? ?? 'application/octet-stream',
      isAudio: json['is_audio'] as bool? ?? false,
      createdAt:
          DateTime.tryParse(json['created_at'] as String? ?? '') ?? DateTime.now(),
      state: DownloadState.values.firstWhere(
        (value) => value.name == json['state'],
        orElse: () => DownloadState.failed,
      ),
      progress: (json['progress'] as num?)?.toDouble() ?? 0,
      expectedBytes: (json['expected_bytes'] as num?)?.toInt(),
      localPath: json['local_path'] as String?,
      error: json['error'] as String?,
    );
  }

  static String encodeList(List<DownloadEntry> items) =>
      jsonEncode(items.map((item) => item.toJson()).toList());

  static List<DownloadEntry> decodeList(String? value) {
    if (value == null || value.isEmpty) return [];
    final decoded = jsonDecode(value) as List<dynamic>;
    return decoded
        .whereType<Map<String, dynamic>>()
        .map(DownloadEntry.fromJson)
        .toList();
  }
}
