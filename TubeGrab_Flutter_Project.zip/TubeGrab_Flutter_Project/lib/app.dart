import 'package:flutter/material.dart';
import 'package:tubegrab/core/app_theme.dart';
import 'package:tubegrab/screens/home_screen.dart';
import 'package:tubegrab/screens/library_screen.dart';
import 'package:tubegrab/services/download_service.dart';
import 'package:tubegrab/services/resolver_api.dart';

class TubeGrabApp extends StatelessWidget {
  const TubeGrabApp({super.key, required this.downloadService});

  final DownloadService downloadService;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TubeGrab',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: ThemeMode.dark,
      home: AppShell(
        downloadService: downloadService,
        resolverApi: ResolverApi(),
      ),
    );
  }
}

class AppShell extends StatefulWidget {
  const AppShell({
    super.key,
    required this.downloadService,
    required this.resolverApi,
  });

  final DownloadService downloadService;
  final ResolverApi resolverApi;

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      HomeScreen(
        resolverApi: widget.resolverApi,
        downloadService: widget.downloadService,
        openLibrary: () => setState(() => _index = 1),
      ),
      LibraryScreen(downloadService: widget.downloadService),
    ];

    return Scaffold(
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home_rounded),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.video_library_outlined),
            selectedIcon: Icon(Icons.video_library_rounded),
            label: 'Library',
          ),
        ],
      ),
    );
  }
}
