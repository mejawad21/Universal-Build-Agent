import 'package:flutter/material.dart';
import 'package:tubegrab/app.dart';
import 'package:tubegrab/services/download_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final downloadService = DownloadService();
  await downloadService.initialize();
  runApp(TubeGrabApp(downloadService: downloadService));
}
