# TubeGrab

TubeGrab is a modern Flutter Android download-manager client with a dark Material 3 interface.

## Included

- Link input with clipboard paste
- Metadata fetch and thumbnail preview
- Format/quality selection supplied by a resolver API
- Video and audio download options
- Android background downloads with notifications
- Progress percentage, speed, ETA, pause, resume, retry, and cancel
- Public `Downloads/TubeGrab` storage
- Download history
- In-app video and audio playback
- Home and Library bottom navigation
- Haptic feedback
- Direct HTTPS MP4, WebM, MOV, MP3, and M4A support
- Optional Node.js resolver gateway
- GitHub Actions APK build

## Important platform limitation

This repository does **not** bundle a YouTube scraper, signature deciphering code, DRM bypass, or access-control bypass. For platform URLs, connect an authorized backend that returns downloadable media the user owns or has permission to save.

Official platform download/offline features should be used where required by the platform's terms.

## Build locally

Install Flutter 3.44.7 or a compatible stable version, then run:

```bash
flutter pub get
flutter test
flutter analyze
flutter build apk --debug \
  --dart-define=TUBEGRAB_API_BASE_URL=https://your-resolver.example
```

APK output:

```text
build/app/outputs/flutter-apk/app-debug.apk
```

The app also works without a resolver for direct HTTPS media-file links.

## GitHub build

1. Push the project to GitHub.
2. Add a repository secret named `TUBEGRAB_API_BASE_URL`.
3. Open **Actions → Build Android APK → Run workflow**.
4. Download the `TubeGrab-debug-apk` artifact.

## Backend gateway

The `backend/` folder provides:

- `GET /health`
- `POST /v1/resolve`
- Direct HTTPS media-file resolution
- Optional forwarding to a licensed upstream resolver

Run it:

```bash
cd backend
npm start
```

The gateway intentionally does not contain extraction or scraping code.

## Android requirements

- Android 7.0 or newer (API 24)
- Internet connection
- Notification approval on Android 13+
- Storage is handled through Android shared/scoped storage

## Release signing

The included release build temporarily uses the debug signing configuration so a test APK can be produced immediately. Before publishing, create your own upload keystore and replace the signing configuration.

## License

MIT for the application source. Third-party Flutter packages retain their own licenses.
