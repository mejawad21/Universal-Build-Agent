import 'package:flutter_test/flutter_test.dart';
import 'package:tubegrab/models/media_info.dart';

void main() {
  test('parses authorized media options', () {
    final media = MediaInfo.fromJson(
      {
        'title': 'Example',
        'channel': 'Owner',
        'duration_seconds': 90,
        'thumbnail_url': 'https://example.com/thumb.jpg',
        'options': [
          {
            'id': '720',
            'label': '720p MP4',
            'kind': 'video',
            'format': 'mp4',
            'url': 'https://example.com/video.mp4',
            'filename': 'example.mp4',
            'mime_type': 'video/mp4',
          }
        ],
      },
      'https://example.com/watch',
    );

    expect(media.title, 'Example');
    expect(media.options.single.kind, MediaKind.video);
  });

  test('rejects non-https option URLs', () {
    final media = MediaInfo.fromJson(
      {
        'options': [
          {
            'url': 'http://insecure.example/file.mp4',
          }
        ],
      },
      'https://example.com',
    );
    expect(media.options, isEmpty);
  });
}
