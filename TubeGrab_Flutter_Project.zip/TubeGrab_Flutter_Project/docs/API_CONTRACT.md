# Resolver API contract

The Flutter app sends:

```http
POST /v1/resolve
Content-Type: application/json

{"url":"https://source.example/watch/123"}
```

A successful resolver returns:

```json
{
  "title": "Video title",
  "channel": "Creator name",
  "duration_seconds": 245,
  "thumbnail_url": "https://cdn.example/thumb.jpg",
  "options": [
    {
      "id": "video-1080",
      "label": "1080p MP4",
      "kind": "video",
      "format": "mp4",
      "url": "https://cdn.example/authorized-file.mp4",
      "filename": "video-title-1080p.mp4",
      "mime_type": "video/mp4",
      "content_length": 154238234
    },
    {
      "id": "audio-m4a",
      "label": "High-quality M4A",
      "kind": "audio",
      "format": "m4a",
      "url": "https://cdn.example/authorized-audio.m4a",
      "filename": "video-title.m4a",
      "mime_type": "audio/mp4"
    }
  ]
}
```

Requirements:

- Return only HTTPS URLs.
- Return only files the user is authorized to save.
- Signed URLs should remain valid long enough for background downloads.
- Support HTTP range requests for pause/resume.
- Set correct `Content-Type` and `Content-Length` headers.
- Do not return DRM-protected, paywalled, or access-controlled streams.
