import http from 'node:http';

const port = Number.parseInt(process.env.PORT ?? '8080', 10);
const upstreamUrl = process.env.UPSTREAM_RESOLVER_URL?.trim() ?? '';
const upstreamApiKey = process.env.UPSTREAM_API_KEY?.trim() ?? '';

const mediaExtensions = new Map([
  ['.mp4', ['video', 'video/mp4']],
  ['.webm', ['video', 'video/webm']],
  ['.mov', ['video', 'video/quicktime']],
  ['.mp3', ['audio', 'audio/mpeg']],
  ['.m4a', ['audio', 'audio/mp4']],
]);

const server = http.createServer(async (request, response) => {
  setSecurityHeaders(response);

  if (request.method === 'GET' && request.url === '/health') {
    return json(response, 200, { status: 'ok' });
  }

  if (request.method !== 'POST' || request.url !== '/v1/resolve') {
    return json(response, 404, { error: 'Not found' });
  }

  try {
    const body = await readJson(request);
    const source = parseHttpsUrl(body.url);

    const direct = directMediaDetails(source);
    if (direct) return json(response, 200, direct);

    if (!upstreamUrl) {
      return json(response, 501, {
        error:
          'No authorized resolver is configured. Set UPSTREAM_RESOLVER_URL to a service you are licensed to use.',
      });
    }

    const upstreamResponse = await fetch(upstreamUrl, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        ...(upstreamApiKey ? { authorization: `Bearer ${upstreamApiKey}` } : {}),
      },
      body: JSON.stringify({ url: source.toString() }),
      signal: AbortSignal.timeout(25000),
    });

    const text = await upstreamResponse.text();
    response.writeHead(upstreamResponse.status, {
      'content-type':
        upstreamResponse.headers.get('content-type') ?? 'application/json',
    });
    response.end(text);
  } catch (error) {
    json(response, 400, {
      error: error instanceof Error ? error.message : 'Bad request',
    });
  }
});

server.listen(port, '0.0.0.0', () => {
  console.log(`TubeGrab resolver listening on :${port}`);
});

function directMediaDetails(url) {
  const pathname = url.pathname.toLowerCase();
  const match = [...mediaExtensions.entries()].find(([extension]) =>
    pathname.endsWith(extension),
  );
  if (!match) return null;

  const [extension, [kind, mimeType]] = match;
  const fileName =
    decodeURIComponent(url.pathname.split('/').pop() || '') ||
    `tubegrab${extension}`;

  return {
    title: fileName,
    channel: url.hostname,
    duration_seconds: 0,
    thumbnail_url: '',
    options: [
      {
        id: `direct-${extension.slice(1)}`,
        label: kind === 'audio' ? 'Original audio' : 'Original video',
        kind,
        format: extension.slice(1),
        url: url.toString(),
        filename: fileName,
        mime_type: mimeType,
      },
    ],
  };
}

function parseHttpsUrl(value) {
  if (typeof value !== 'string' || value.length > 2048) {
    throw new Error('A valid URL is required.');
  }
  const url = new URL(value);
  if (url.protocol !== 'https:') {
    throw new Error('Only HTTPS sources are accepted.');
  }
  if (
    url.hostname === 'localhost' ||
    url.hostname === '127.0.0.1' ||
    url.hostname === '::1' ||
    url.hostname.endsWith('.local')
  ) {
    throw new Error('Local network targets are not allowed.');
  }
  return url;
}

async function readJson(request) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > 16_384) throw new Error('Request body is too large.');
    chunks.push(chunk);
  }
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}

function setSecurityHeaders(response) {
  response.setHeader('x-content-type-options', 'nosniff');
  response.setHeader('cache-control', 'no-store');
  response.setHeader('content-security-policy', "default-src 'none'");
}

function json(response, status, body) {
  response.writeHead(status, { 'content-type': 'application/json; charset=utf-8' });
  response.end(JSON.stringify(body));
}
