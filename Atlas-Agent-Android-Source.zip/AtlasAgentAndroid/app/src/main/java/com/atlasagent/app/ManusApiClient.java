package com.atlasagent.app;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

final class ManusApiClient {
    private final String apiKey;

    ManusApiClient(String apiKey) {
        this.apiKey = apiKey.trim();
    }

    JSONObject verifyKey() throws Exception {
        return get("task.list?limit=1&order=desc");
    }

    JSONObject createTask(
            String prompt,
            String title,
            String profile,
            boolean interactive,
            String fileId
    ) throws Exception {
        JSONObject payload = new JSONObject();
        payload.put("message", buildMessage(prompt, fileId));
        payload.put("agent_profile", profile);
        payload.put("interactive_mode", interactive);
        payload.put("share_visibility", "private");

        if (title != null && !title.trim().isEmpty()) {
            payload.put("title", title.trim());
        }

        return post("task.create", payload);
    }

    JSONObject sendMessage(
            String taskId,
            String prompt,
            String profile,
            String fileId
    ) throws Exception {
        JSONObject payload = new JSONObject();
        payload.put("task_id", taskId);
        payload.put("message", buildMessage(prompt, fileId));

        if (profile != null && !profile.isEmpty()) {
            payload.put("agent_profile", profile);
        }

        return post("task.sendMessage", payload);
    }

    JSONObject listMessages(String taskId) throws Exception {
        String path = "task.listMessages?task_id="
                + encode(taskId)
                + "&order=asc&limit=200&verbose=true"
                + "&slides_format=pptx";

        return get(path);
    }

    JSONObject listTasks() throws Exception {
        return get("task.list?limit=50&order=desc&scope=standard");
    }

    JSONObject stopTask(String taskId) throws Exception {
        JSONObject payload = new JSONObject();
        payload.put("task_id", taskId);
        return post("task.stop", payload);
    }

    UploadResult uploadFile(
            ContentResolver resolver,
            Uri uri
    ) throws Exception {
        String filename = queryFilename(resolver, uri);

        JSONObject createPayload = new JSONObject();
        createPayload.put("filename", filename);

        JSONObject createResponse = post(
                "file.upload",
                createPayload
        );

        JSONObject file = createResponse.getJSONObject("file");
        String fileId = file.getString("id");
        String uploadUrl = createResponse.getString("upload_url");

        HttpURLConnection connection =
                (HttpURLConnection) new URL(uploadUrl).openConnection();

        connection.setRequestMethod("PUT");
        connection.setDoOutput(true);
        connection.setConnectTimeout(30000);
        connection.setReadTimeout(180000);

        String contentType = resolver.getType(uri);
        if (contentType != null && !contentType.isEmpty()) {
            connection.setRequestProperty(
                    "Content-Type",
                    contentType
            );
        }

        InputStream source = resolver.openInputStream(uri);
        if (source == null) {
            throw new ApiException(
                    "The selected file could not be opened."
            );
        }

        try (
                InputStream input = new BufferedInputStream(source);
                OutputStream output = connection.getOutputStream()
        ) {
            byte[] buffer = new byte[64 * 1024];
            int count;

            while ((count = input.read(buffer)) >= 0) {
                output.write(buffer, 0, count);
            }
        }

        int status = connection.getResponseCode();
        connection.disconnect();

        if (status < 200 || status >= 300) {
            throw new ApiException(
                    "File upload failed with HTTP " + status
            );
        }

        return new UploadResult(fileId, filename);
    }

    private JSONObject buildMessage(
            String prompt,
            String fileId
    ) throws JSONException {
        JSONArray content = new JSONArray();

        JSONObject text = new JSONObject();
        text.put("type", "text");
        text.put("text", prompt);
        content.put(text);

        if (fileId != null && !fileId.isEmpty()) {
            JSONObject file = new JSONObject();
            file.put("type", "file");
            file.put("file_id", fileId);
            content.put(file);
        }

        JSONObject message = new JSONObject();
        message.put("content", content);
        return message;
    }

    private JSONObject get(String path) throws Exception {
        HttpURLConnection connection =
                (HttpURLConnection) new URL(
                        AgentConfig.API_BASE + path
                ).openConnection();

        configure(connection);
        connection.setRequestMethod("GET");
        return readJson(connection);
    }

    private JSONObject post(
            String path,
            JSONObject payload
    ) throws Exception {
        HttpURLConnection connection =
                (HttpURLConnection) new URL(
                        AgentConfig.API_BASE + path
                ).openConnection();

        configure(connection);
        connection.setRequestMethod("POST");
        connection.setDoOutput(true);
        connection.setRequestProperty(
                "Content-Type",
                "application/json"
        );

        try (
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(
                                connection.getOutputStream(),
                                StandardCharsets.UTF_8
                        )
                )
        ) {
            writer.write(payload.toString());
        }

        return readJson(connection);
    }

    private void configure(HttpURLConnection connection) {
        connection.setConnectTimeout(30000);
        connection.setReadTimeout(180000);
        connection.setUseCaches(false);
        connection.setRequestProperty(
                "Accept",
                "application/json"
        );
        connection.setRequestProperty(
                "x-manus-api-key",
                apiKey
        );
    }

    private JSONObject readJson(
            HttpURLConnection connection
    ) throws Exception {
        int status = connection.getResponseCode();

        InputStream stream = status >= 200 && status < 300
                ? connection.getInputStream()
                : connection.getErrorStream();

        String body = readText(stream);
        connection.disconnect();

        JSONObject response;
        try {
            response = new JSONObject(body);
        } catch (JSONException error) {
            throw new ApiException(
                    "The server returned an invalid response."
            );
        }

        boolean ok = response.optBoolean(
                "ok",
                status >= 200 && status < 300
        );

        if (!ok || status < 200 || status >= 300) {
            JSONObject apiError = response.optJSONObject("error");

            String message = apiError == null
                    ? "API request failed with HTTP " + status
                    : apiError.optString(
                            "message",
                            "API request failed."
                    );

            throw new ApiException(message);
        }

        return response;
    }

    private String readText(InputStream stream) throws Exception {
        if (stream == null) {
            return "{}";
        }

        StringBuilder text = new StringBuilder();

        try (
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(
                                stream,
                                StandardCharsets.UTF_8
                        )
                )
        ) {
            String line;

            while ((line = reader.readLine()) != null) {
                text.append(line);
            }
        }

        return text.toString();
    }

    private String queryFilename(
            ContentResolver resolver,
            Uri uri
    ) {
        String result = "attachment.bin";

        try (
                Cursor cursor = resolver.query(
                        uri,
                        null,
                        null,
                        null,
                        null
                )
        ) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(
                        OpenableColumns.DISPLAY_NAME
                );

                if (index >= 0) {
                    String value = cursor.getString(index);
                    if (value != null && !value.isEmpty()) {
                        result = value;
                    }
                }
            }
        }

        return result;
    }

    private String encode(String value) throws Exception {
        return URLEncoder.encode(
                value,
                StandardCharsets.UTF_8.name()
        );
    }

    static final class UploadResult {
        final String fileId;
        final String filename;

        UploadResult(String fileId, String filename) {
            this.fileId = fileId;
            this.filename = filename;
        }
    }

    static final class ApiException extends Exception {
        ApiException(String message) {
            super(message);
        }
    }
}
