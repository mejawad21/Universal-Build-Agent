package com.atlasagent.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

final class SecureKeyStore {
    private static final String KEY_ALIAS = "atlas_agent_api_key";
    private static final String PREFS = "atlas_secure_preferences";
    private static final String PREF_DATA = "encrypted_api_key";
    private static final String PREF_IV = "encrypted_api_key_iv";

    private SecureKeyStore() {
    }

    static void save(Context context, String apiKey) throws Exception {
        SecretKey key = getOrCreateKey();
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key);

        byte[] encrypted = cipher.doFinal(
                apiKey.getBytes(StandardCharsets.UTF_8)
        );

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString(
                        PREF_DATA,
                        Base64.encodeToString(
                                encrypted,
                                Base64.NO_WRAP
                        )
                )
                .putString(
                        PREF_IV,
                        Base64.encodeToString(
                                cipher.getIV(),
                                Base64.NO_WRAP
                        )
                )
                .apply();
    }

    static String load(Context context) throws Exception {
        SharedPreferences preferences =
                context.getSharedPreferences(
                        PREFS,
                        Context.MODE_PRIVATE
                );

        String encryptedText =
                preferences.getString(PREF_DATA, "");
        String ivText =
                preferences.getString(PREF_IV, "");

        if (encryptedText.isEmpty() || ivText.isEmpty()) {
            return "";
        }

        SecretKey key = getOrCreateKey();
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(
                Cipher.DECRYPT_MODE,
                key,
                new GCMParameterSpec(
                        128,
                        Base64.decode(ivText, Base64.NO_WRAP)
                )
        );

        byte[] decrypted = cipher.doFinal(
                Base64.decode(
                        encryptedText,
                        Base64.NO_WRAP
                )
        );

        return new String(
                decrypted,
                StandardCharsets.UTF_8
        );
    }

    static void clear(Context context) {
        context.getSharedPreferences(
                PREFS,
                Context.MODE_PRIVATE
        ).edit().clear().apply();
    }

    private static SecretKey getOrCreateKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);

        if (keyStore.containsAlias(KEY_ALIAS)) {
            return (SecretKey) keyStore.getKey(KEY_ALIAS, null);
        }

        KeyGenerator generator = KeyGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_AES,
                "AndroidKeyStore"
        );

        generator.init(
                new KeyGenParameterSpec.Builder(
                        KEY_ALIAS,
                        KeyProperties.PURPOSE_ENCRYPT
                                | KeyProperties.PURPOSE_DECRYPT
                )
                        .setBlockModes(
                                KeyProperties.BLOCK_MODE_GCM
                        )
                        .setEncryptionPaddings(
                                KeyProperties.ENCRYPTION_PADDING_NONE
                        )
                        .setRandomizedEncryptionRequired(true)
                        .build()
        );

        return generator.generateKey();
    }
}
