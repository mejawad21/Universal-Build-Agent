package com.atlasagent.app;

final class AgentConfig {
    static final String API_BASE = "https://api.manus.ai/v2/";
    static final String DEFAULT_AGENT_TASK = "agent-default-main_task";

    private AgentConfig() {
    }

    static String profileId(int index) {
        if (index == 0) {
            return "manus-1.6-lite";
        }
        if (index == 2) {
            return "manus-1.6-max";
        }
        return "manus-1.6";
    }

    static String profileName(String profile) {
        if ("manus-1.6-lite".equals(profile)) {
            return "Lite";
        }
        if ("manus-1.6-max".equals(profile)) {
            return "Max";
        }
        return "Standard";
    }
}
