package com.atlasagent.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final int PICK_FILE_REQUEST = 301;

    private static final int BG = Color.rgb(7, 11, 20);
    private static final int SURFACE = Color.rgb(16, 23, 39);
    private static final int CARD = Color.rgb(20, 29, 48);
    private static final int BORDER = Color.rgb(44, 57, 82);
    private static final int TEXT = Color.rgb(239, 245, 255);
    private static final int MUTED = Color.rgb(151, 165, 188);
    private static final int PURPLE = Color.rgb(124, 107, 255);
    private static final int GREEN = Color.rgb(105, 227, 180);
    private static final int BLUE = Color.rgb(86, 177, 255);
    private static final int ORANGE = Color.rgb(255, 184, 95);
    private static final int RED = Color.rgb(255, 100, 120);

    private final ExecutorService executor =
            Executors.newFixedThreadPool(3);
    private final Handler handler =
            new Handler(Looper.getMainLooper());

    private FrameLayout content;
    private TextView titleView;
    private TextView subtitleView;
    private Button navHome;
    private Button navNew;
    private Button navTasks;
    private Button navSettings;

    private ManusApiClient api;

    private Uri pendingFileUri;
    private String pendingFileName = "";
    private TextView pendingFileLabel;

    private String activeTaskId = "";
    private String activeTaskUrl = "";
    private LinearLayout activeMessages;
    private TextView activeStatus;
    private final Runnable poller = new Runnable() {
        @Override
        public void run() {
            if (
                    activeTaskId.isEmpty()
                            || activeMessages == null
                            || activeStatus == null
            ) {
                return;
            }

            loadMessages(
                    activeTaskId,
                    activeMessages,
                    activeStatus,
                    false
            );
        }
    };

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
        }

        buildShell();
        loadClient();

        if (api == null) {
            showSettings();
        } else {
            showHome();
        }
    }

    @Override
    protected void onDestroy() {
        stopPolling();
        executor.shutdownNow();
        super.onDestroy();
    }

    private void buildShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(
                dp(20),
                dp(15),
                dp(20),
                dp(14)
        );
        header.setBackground(
                rounded(SURFACE, 0, BORDER, 1)
        );

        titleView = label(
                "Atlas Agent",
                24f,
                TEXT,
                Typeface.BOLD
        );

        subtitleView = label(
                "Autonomous task workspace",
                13f,
                MUTED,
                Typeface.NORMAL
        );

        header.addView(titleView);
        header.addView(subtitleView);
        root.addView(header);

        content = new FrameLayout(this);
        root.addView(
                content,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f
                )
        );

        LinearLayout navigation = new LinearLayout(this);
        navigation.setPadding(
                dp(8),
                dp(7),
                dp(8),
                dp(7)
        );
        navigation.setBackground(
                rounded(SURFACE, 0, BORDER, 1)
        );

        navHome = navButton("Home", this::showHome);
        navNew = navButton("New Task", this::showNewTask);
        navTasks = navButton("Tasks", this::showTasks);
        navSettings = navButton("Settings", this::showSettings);

        navigation.addView(navHome, navParams());
        navigation.addView(navNew, navParams());
        navigation.addView(navTasks, navParams());
        navigation.addView(navSettings, navParams());

        root.addView(navigation);
        setContentView(root);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            root.setOnApplyWindowInsetsListener(
                    new View.OnApplyWindowInsetsListener() {
                        @Override
                        public WindowInsets onApplyWindowInsets(
                                View view,
                                WindowInsets insets
                        ) {
                            Insets bars = insets.getInsets(
                                    WindowInsets.Type.systemBars()
                            );

                            root.setPadding(
                                    bars.left,
                                    bars.top,
                                    bars.right,
                                    bars.bottom
                            );

                            return insets;
                        }
                    }
            );
        }
    }

    private void loadClient() {
        try {
            String key = SecureKeyStore.load(this);
            api = key.isEmpty()
                    ? null
                    : new ManusApiClient(key);
        } catch (Exception error) {
            api = null;
        }
    }

    private void showHome() {
        stopPolling();
        setHeader(
                "Atlas Agent",
                "Delegate complete outcomes"
        );
        selectNav(navHome);

        LinearLayout page = page();

        page.addView(
                label(
                        "What should your agent accomplish?",
                        28f,
                        TEXT,
                        Typeface.BOLD
                )
        );

        TextView intro = label(
                "Create autonomous tasks, monitor live plans and tools, "
                        + "attach files, and continue working from your phone.",
                15f,
                MUTED,
                Typeface.NORMAL
        );
        intro.setLineSpacing(0f, 1.18f);
        page.addView(
                intro,
                margins(-1, -2, 0, 8, 0, 18)
        );

        page.addView(
                actionCard(
                        "✦",
                        "Start autonomous task",
                        "The agent plans, researches, uses tools, and "
                                + "delivers a finished result.",
                        PURPLE,
                        this::showNewTask
                )
        );

        page.addView(
                actionCard(
                        "●",
                        "Persistent agent chat",
                        "Continue one ongoing conversation with your "
                                + "default Manus agent.",
                        GREEN,
                        this::showPersistentChat
                ),
                margins(-1, -2, 0, 12, 0, 0)
        );

        page.addView(
                actionCard(
                        "▤",
                        "Task history",
                        "Review running, waiting, completed, and failed work.",
                        BLUE,
                        this::showTasks
                ),
                margins(-1, -2, 0, 12, 0, 0)
        );

        TextView state = label(
                api == null
                        ? "API key required. Open Settings."
                        : "Connected securely using Android Keystore.",
                12f,
                api == null ? ORANGE : GREEN,
                Typeface.BOLD
        );

        page.addView(
                state,
                margins(-1, -2, 0, 18, 0, 0)
        );

        setPage(scroll(page));
    }

    private void showNewTask() {
        stopPolling();
        setHeader(
                "New Agent Task",
                "Plan and execute multi-step work"
        );
        selectNav(navNew);

        if (!requireApi()) {
            return;
        }

        pendingFileUri = null;
        pendingFileName = "";

        LinearLayout page = page();

        page.addView(section("Task instructions"));

        EditText title = input(
                "Optional task title",
                false
        );
        page.addView(title);

        EditText prompt = input(
                "Describe the final result you need. Example: Research "
                        + "five suppliers, compare current prices, and "
                        + "prepare a recommendation report.",
                true
        );
        prompt.setMinLines(8);
        prompt.setGravity(Gravity.TOP);
        page.addView(
                prompt,
                margins(-1, -2, 0, 10, 0, 0)
        );

        page.addView(
                label(
                        "Agent profile",
                        13f,
                        MUTED,
                        Typeface.BOLD
                ),
                margins(-1, -2, 0, 14, 0, 6)
        );

        Spinner profile = profileSpinner();
        page.addView(profile);

        CheckBox interactive = new CheckBox(this);
        interactive.setText(
                "Allow follow-up questions when instructions are unclear"
        );
        interactive.setTextColor(TEXT);
        interactive.setChecked(true);
        page.addView(
                interactive,
                margins(-1, -2, 0, 12, 0, 0)
        );

        LinearLayout attachmentCard = card();
        attachmentCard.addView(
                label(
                        "Attachment",
                        16f,
                        TEXT,
                        Typeface.BOLD
                )
        );

        pendingFileLabel = label(
                "No file selected",
                12f,
                MUTED,
                Typeface.NORMAL
        );
        attachmentCard.addView(pendingFileLabel);

        Button attach = button(
                "Choose a file",
                CARD,
                TEXT
        );
        attach.setOnClickListener(
                view -> chooseFile()
        );
        attachmentCard.addView(
                attach,
                margins(-1, dp(48), 0, 10, 0, 0)
        );

        page.addView(
                attachmentCard,
                margins(-1, -2, 0, 14, 0, 0)
        );

        Button run = button(
                "Run Autonomous Agent",
                PURPLE,
                Color.WHITE
        );
        run.setOnClickListener(
                view -> {
                    String request = prompt.getText()
                            .toString()
                            .trim();

                    if (request.isEmpty()) {
                        toast("Write task instructions first.");
                        return;
                    }

                    run.setEnabled(false);

                    executeCreateTask(
                            request,
                            title.getText()
                                    .toString()
                                    .trim(),
                            AgentConfig.profileId(
                                    profile.getSelectedItemPosition()
                            ),
                            interactive.isChecked(),
                            run
                    );
                }
        );

        page.addView(
                run,
                margins(-1, dp(56), 0, 16, 0, 0)
        );

        TextView note = label(
                "Tasks use your own Manus account, enabled connectors, "
                        + "skills, plan, and credits.",
                12f,
                MUTED,
                Typeface.NORMAL
        );
        page.addView(note);

        setPage(scroll(page));
    }

    private void executeCreateTask(
            String prompt,
            String title,
            String profile,
            boolean interactive,
            Button runButton
    ) {
        runAsync(
                () -> {
                    String fileId = "";

                    if (pendingFileUri != null) {
                        showToastOnUi(
                                "Uploading " + pendingFileName + "…"
                        );

                        fileId = api.uploadFile(
                                getContentResolver(),
                                pendingFileUri
                        ).fileId;
                    }

                    showToastOnUi("Starting agent task…");

                    JSONObject response = api.createTask(
                            prompt,
                            title,
                            profile,
                            interactive,
                            fileId
                    );

                    String taskId =
                            response.getString("task_id");
                    String taskTitle =
                            response.optString(
                                    "task_title",
                                    title.isEmpty()
                                            ? "Agent task"
                                            : title
                            );
                    String taskUrl =
                            response.optString(
                                    "task_url",
                                    ""
                            );

                    runOnUiThread(
                            () -> {
                                pendingFileUri = null;
                                pendingFileName = "";
                                showTask(
                                        taskId,
                                        taskTitle,
                                        taskUrl,
                                        false
                                );
                            }
                    );
                },
                error -> {
                    runButton.setEnabled(true);
                    showError(
                            "Could not start task",
                            error
                    );
                }
        );
    }

    private void showPersistentChat() {
        showTask(
                AgentConfig.DEFAULT_AGENT_TASK,
                "My Persistent Agent",
                "",
                true
        );
    }

    private void showTasks() {
        stopPolling();
        setHeader(
                "Task History",
                "Running and completed work"
        );
        selectNav(navTasks);

        if (!requireApi()) {
            return;
        }

        LinearLayout page = page();

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);

        toolbar.addView(
                section("Recent tasks"),
                new LinearLayout.LayoutParams(
                        0,
                        -2,
                        1f
                )
        );

        Button refresh = smallButton(
                "Refresh",
                BLUE
        );
        toolbar.addView(refresh);
        page.addView(toolbar);

        ProgressBar loading = new ProgressBar(this);
        page.addView(loading);

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        page.addView(
                list,
                margins(-1, -2, 0, 12, 0, 0)
        );

        refresh.setOnClickListener(
                view -> loadTasks(list, loading)
        );

        setPage(scroll(page));
        loadTasks(list, loading);
    }

    private void loadTasks(
            LinearLayout list,
            ProgressBar loading
    ) {
        loading.setVisibility(View.VISIBLE);
        list.removeAllViews();

        runAsync(
                () -> {
                    JSONObject response = api.listTasks();
                    JSONArray tasks =
                            response.optJSONArray("data");

                    runOnUiThread(
                            () -> {
                                loading.setVisibility(View.GONE);

                                if (
                                        tasks == null
                                                || tasks.length() == 0
                                ) {
                                    list.addView(
                                            emptyState(
                                                "No tasks yet",
                                                "Start your first autonomous task."
                                            )
                                    );
                                    return;
                                }

                                for (
                                        int index = 0;
                                        index < tasks.length();
                                        index++
                                ) {
                                    JSONObject task =
                                            tasks.optJSONObject(index);

                                    if (task != null) {
                                        list.addView(
                                                taskCard(task),
                                                margins(
                                                        -1,
                                                        -2,
                                                        0,
                                                        index == 0 ? 0 : 10,
                                                        0,
                                                        0
                                                )
                                        );
                                    }
                                }
                            }
                    );
                },
                error -> {
                    loading.setVisibility(View.GONE);
                    showError("Could not load tasks", error);
                }
        );
    }

    private View taskCard(JSONObject task) {
        LinearLayout item = card();
        item.setClickable(true);

        String title = task.optString(
                "title",
                "Untitled task"
        );
        String status = task.optString(
                "status",
                "unknown"
        );
        String id = task.optString("id", "");
        String url = task.optString(
                "task_url",
                ""
        );
        String profile = task.optString(
                "agent_profile",
                "manus-1.6"
        );

        item.addView(
                label(
                        title,
                        17f,
                        TEXT,
                        Typeface.BOLD
                )
        );

        LinearLayout meta = new LinearLayout(this);
        meta.setGravity(Gravity.CENTER_VERTICAL);
        meta.addView(
                badge(
                        status.toUpperCase(Locale.US),
                        statusColor(status)
                )
        );

        meta.addView(
                label(
                        "   " + AgentConfig.profileName(profile),
                        12f,
                        MUTED,
                        Typeface.BOLD
                )
        );

        if (task.has("credit_usage")) {
            meta.addView(
                    label(
                            "  •  "
                                    + task.optInt("credit_usage")
                                    + " credits",
                            12f,
                            MUTED,
                            Typeface.NORMAL
                    )
            );
        }

        item.addView(
                meta,
                margins(-1, -2, 0, 10, 0, 0)
        );

        long updated =
                task.optLong("updated_at", 0L);

        if (updated > 0L) {
            item.addView(
                    label(
                            "Updated "
                                    + DateFormat
                                    .getDateTimeInstance(
                                            DateFormat.MEDIUM,
                                            DateFormat.SHORT
                                    )
                                    .format(
                                            new Date(
                                                    updated * 1000L
                                            )
                                    ),
                            12f,
                            MUTED,
                            Typeface.NORMAL
                    )
            );
        }

        item.setOnClickListener(
                view -> showTask(
                        id,
                        title,
                        url,
                        false
                )
        );

        return item;
    }

    private void showTask(
            String taskId,
            String taskTitle,
            String taskUrl,
            boolean chatMode
    ) {
        stopPolling();

        activeTaskId = taskId;
        activeTaskUrl = taskUrl;

        setHeader(
                taskTitle,
                chatMode
                        ? "Persistent agent conversation"
                        : "Live autonomous task"
        );
        selectNav(chatMode ? navHome : navTasks);

        if (!requireApi()) {
            return;
        }

        pendingFileUri = null;
        pendingFileName = "";

        LinearLayout page = page();

        LinearLayout statusCard = card();
        LinearLayout statusRow = new LinearLayout(this);
        statusRow.setGravity(Gravity.CENTER_VERTICAL);

        activeStatus = badge("LOADING", MUTED);
        statusRow.addView(activeStatus);

        statusRow.addView(
                label(
                        chatMode
                                ? "   Default agent"
                                : "   Task " + shortId(taskId),
                        12f,
                        MUTED,
                        Typeface.NORMAL
                )
        );

        statusCard.addView(statusRow);

        LinearLayout controls = new LinearLayout(this);

        Button refresh = smallButton(
                "Refresh",
                BLUE
        );
        refresh.setOnClickListener(
                view -> loadMessages(
                        taskId,
                        activeMessages,
                        activeStatus,
                        true
                )
        );
        controls.addView(refresh);

        if (!chatMode) {
            Button stop = smallButton(
                    "Stop",
                    RED
            );
            stop.setOnClickListener(
                    view -> stopTask(taskId)
            );
            controls.addView(
                    stop,
                    margins(-2, dp(42), 8, 0, 0, 0)
            );
        }

        if (taskUrl != null && !taskUrl.isEmpty()) {
            Button web = smallButton(
                    "Full workspace",
                    PURPLE
            );
            web.setOnClickListener(
                    view -> startActivity(
                            new Intent(
                                    Intent.ACTION_VIEW,
                                    Uri.parse(taskUrl)
                            )
                    )
            );
            controls.addView(
                    web,
                    margins(-2, dp(42), 8, 0, 0, 0)
            );
        }

        statusCard.addView(
                controls,
                margins(-1, -2, 0, 12, 0, 0)
        );
        page.addView(statusCard);

        page.addView(
                section(
                        chatMode
                                ? "Conversation"
                                : "Live activity"
                ),
                margins(-1, -2, 0, 18, 0, 8)
        );

        activeMessages = new LinearLayout(this);
        activeMessages.setOrientation(
                LinearLayout.VERTICAL
        );
        page.addView(activeMessages);

        LinearLayout composer = card();

        Spinner profile = profileSpinner();
        composer.addView(profile);

        EditText input = input(
                chatMode
                        ? "Message your agent…"
                        : "Send a follow-up or answer a question…",
                true
        );
        input.setMinLines(3);
        composer.addView(
                input,
                margins(-1, -2, 0, 10, 0, 0)
        );

        pendingFileLabel = label(
                "No attachment",
                12f,
                MUTED,
                Typeface.NORMAL
        );
        composer.addView(pendingFileLabel);

        LinearLayout composeButtons =
                new LinearLayout(this);

        Button attach = smallButton(
                "Attach",
                CARD
        );
        attach.setOnClickListener(
                view -> chooseFile()
        );
        composeButtons.addView(attach);

        Button send = smallButton(
                chatMode
                        ? "Send to Agent"
                        : "Send Follow-up",
                GREEN
        );
        send.setTextColor(BG);
        send.setOnClickListener(
                view -> sendMessage(
                        taskId,
                        input,
                        profile,
                        send
                )
        );
        composeButtons.addView(
                send,
                margins(0, dp(46), 8, 0, 0, 0)
        );

        composer.addView(
                composeButtons,
                margins(-1, -2, 0, 12, 0, 0)
        );

        page.addView(
                composer,
                margins(-1, -2, 0, 18, 0, 0)
        );

        setPage(scroll(page));

        loadMessages(
                taskId,
                activeMessages,
                activeStatus,
                true
        );
    }

    private void loadMessages(
            String taskId,
            LinearLayout container,
            TextView statusView,
            boolean showErrors
    ) {
        if (
                api == null
                        || container == null
                        || !taskId.equals(activeTaskId)
        ) {
            return;
        }

        runAsync(
                () -> {
                    JSONObject response =
                            api.listMessages(taskId);
                    JSONArray messages =
                            response.optJSONArray("messages");

                    if (messages == null) {
                        messages = new JSONArray();
                    }

                    String status =
                            EventFormatter.latestAgentStatus(messages);
                    JSONArray finalMessages = messages;

                    runOnUiThread(
                            () -> {
                                if (
                                        !taskId.equals(activeTaskId)
                                                || container
                                                != activeMessages
                                ) {
                                    return;
                                }

                                renderMessages(
                                        container,
                                        finalMessages
                                );

                                statusView.setText(
                                        status.toUpperCase(Locale.US)
                                );
                                statusView.setBackground(
                                        rounded(
                                                statusColor(status),
                                                14,
                                                0,
                                                0
                                        )
                                );

                                handler.removeCallbacks(poller);

                                if (
                                        "running".equals(status)
                                                || "waiting".equals(status)
                                ) {
                                    handler.postDelayed(
                                            poller,
                                            4000L
                                    );
                                }
                            }
                    );
                },
                error -> {
                    if (showErrors) {
                        showError(
                                "Could not load task",
                                error
                        );
                    }

                    handler.removeCallbacks(poller);
                    handler.postDelayed(poller, 8000L);
                }
        );
    }

    private void renderMessages(
            LinearLayout container,
            JSONArray messages
    ) {
        container.removeAllViews();

        if (messages.length() == 0) {
            container.addView(
                    emptyState(
                            "No activity yet",
                            "Waiting for the agent to begin."
                    )
            );
            return;
        }

        int visibleCount = 0;

        for (
                int index = 0;
                index < messages.length();
                index++
        ) {
            JSONObject event =
                    messages.optJSONObject(index);

            if (event == null) {
                continue;
            }

            EventFormatter.EventView formatted =
                    EventFormatter.format(event);

            if (
                    formatted.body == null
                            || formatted.body.trim().isEmpty()
            ) {
                continue;
            }

            container.addView(
                    eventCard(formatted),
                    margins(
                            -1,
                            -2,
                            0,
                            visibleCount == 0 ? 0 : 9,
                            0,
                            0
                    )
            );
            visibleCount++;
        }
    }

    private View eventCard(
            EventFormatter.EventView event
    ) {
        int accent = MUTED;
        int background = CARD;

        if ("assistant".equals(event.style)) {
            accent = GREEN;
            background = Color.rgb(16, 39, 38);
        } else if ("user".equals(event.style)) {
            accent = PURPLE;
            background = Color.rgb(31, 27, 58);
        } else if ("plan".equals(event.style)) {
            accent = BLUE;
            background = Color.rgb(17, 34, 53);
        } else if ("tool".equals(event.style)) {
            accent = ORANGE;
            background = Color.rgb(48, 34, 23);
        } else if ("error".equals(event.style)) {
            accent = RED;
            background = Color.rgb(53, 23, 32);
        }

        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setPadding(
                dp(14),
                dp(12),
                dp(14),
                dp(12)
        );
        item.setBackground(
                rounded(background, 16, accent, 1)
        );

        item.addView(
                label(
                        event.label,
                        11f,
                        accent,
                        Typeface.BOLD
                )
        );

        TextView body = label(
                event.body,
                14f,
                TEXT,
                Typeface.NORMAL
        );
        body.setTextIsSelectable(true);
        body.setLineSpacing(0f, 1.16f);
        item.addView(
                body,
                margins(-1, -2, 0, 7, 0, 0)
        );

        return item;
    }

    private void sendMessage(
            String taskId,
            EditText input,
            Spinner profile,
            Button sendButton
    ) {
        String message = input.getText()
                .toString()
                .trim();

        if (message.isEmpty()) {
            toast("Write a message first.");
            return;
        }

        sendButton.setEnabled(false);

        runAsync(
                () -> {
                    String fileId = "";

                    if (pendingFileUri != null) {
                        showToastOnUi(
                                "Uploading " + pendingFileName + "…"
                        );

                        fileId = api.uploadFile(
                                getContentResolver(),
                                pendingFileUri
                        ).fileId;
                    }

                    api.sendMessage(
                            taskId,
                            message,
                            AgentConfig.profileId(
                                    profile.getSelectedItemPosition()
                            ),
                            fileId
                    );

                    runOnUiThread(
                            () -> {
                                input.setText("");
                                pendingFileUri = null;
                                pendingFileName = "";

                                if (pendingFileLabel != null) {
                                    pendingFileLabel.setText(
                                            "No attachment"
                                    );
                                    pendingFileLabel.setTextColor(MUTED);
                                }

                                sendButton.setEnabled(true);
                                loadMessages(
                                        taskId,
                                        activeMessages,
                                        activeStatus,
                                        true
                                );
                            }
                    );
                },
                error -> {
                    sendButton.setEnabled(true);
                    showError(
                            "Could not send message",
                            error
                    );
                }
        );
    }

    private void stopTask(String taskId) {
        runAsync(
                () -> {
                    api.stopTask(taskId);

                    runOnUiThread(
                            () -> loadMessages(
                                    taskId,
                                    activeMessages,
                                    activeStatus,
                                    true
                            )
                    );
                },
                error -> showError(
                        "Could not stop task",
                        error
                )
        );
    }

    private void showSettings() {
        stopPolling();
        setHeader(
                "Settings",
                "Secure API connection"
        );
        selectNav(navSettings);

        LinearLayout page = page();
        page.addView(section("Connect your Manus account"));

        TextView note = label(
                "Create a Manus API key in your account settings, paste "
                        + "it below, and Atlas Agent encrypts it with "
                        + "Android Keystore. The key is never built into "
                        + "the APK.",
                14f,
                MUTED,
                Typeface.NORMAL
        );
        note.setLineSpacing(0f, 1.18f);
        page.addView(
                note,
                margins(-1, -2, 0, 8, 0, 16)
        );

        EditText keyInput = input(
                "Paste Manus API key",
                false
        );
        keyInput.setInputType(
                InputType.TYPE_CLASS_TEXT
                        | InputType.TYPE_TEXT_VARIATION_PASSWORD
        );

        try {
            String existing = SecureKeyStore.load(this);
            if (!existing.isEmpty()) {
                keyInput.setText(existing);
            }
        } catch (Exception ignored) {
        }

        page.addView(keyInput);

        CheckBox show = new CheckBox(this);
        show.setText("Show API key");
        show.setTextColor(TEXT);
        show.setOnCheckedChangeListener(
                (button, checked) -> {
                    keyInput.setInputType(
                            checked
                                    ? InputType.TYPE_CLASS_TEXT
                                    : InputType.TYPE_CLASS_TEXT
                                            | InputType.TYPE_TEXT_VARIATION_PASSWORD
                    );
                    keyInput.setSelection(
                            keyInput.getText().length()
                    );
                }
        );
        page.addView(show);

        Button save = button(
                "Save and Test Connection",
                PURPLE,
                Color.WHITE
        );
        save.setOnClickListener(
                view -> {
                    String key = keyInput.getText()
                            .toString()
                            .trim();

                    if (key.isEmpty()) {
                        toast("Paste your API key first.");
                        return;
                    }

                    save.setEnabled(false);
                    ManusApiClient candidate =
                            new ManusApiClient(key);

                    runAsync(
                            () -> {
                                candidate.verifyKey();
                                SecureKeyStore.save(this, key);
                                api = candidate;

                                runOnUiThread(
                                        () -> {
                                            save.setEnabled(true);
                                            toast(
                                                "Connected successfully."
                                            );
                                            showHome();
                                        }
                                );
                            },
                            error -> {
                                save.setEnabled(true);
                                showError(
                                        "Connection failed",
                                        error
                                );
                            }
                    );
                }
        );

        page.addView(
                save,
                margins(-1, dp(54), 0, 16, 0, 0)
        );

        Button remove = button(
                "Remove API Key",
                Color.rgb(80, 30, 42),
                Color.WHITE
        );
        remove.setOnClickListener(
                view -> {
                    SecureKeyStore.clear(this);
                    api = null;
                    keyInput.setText("");
                    toast("API key removed.");
                }
        );
        page.addView(
                remove,
                margins(-1, dp(50), 0, 10, 0, 0)
        );

        LinearLayout security = card();
        security.addView(
                label(
                        "Security and limitations",
                        16f,
                        TEXT,
                        Typeface.BOLD
                )
        );

        TextView details = label(
                "• HTTPS-only API connection\n"
                        + "• API key encrypted on this phone\n"
                        + "• Files upload only when you attach them\n"
                        + "• Tasks use your own account and credits\n"
                        + "• Sensitive confirmations may require the "
                        + "full Manus workspace\n"
                        + "• Independent client, not an official "
                        + "Manus-branded application",
                13f,
                MUTED,
                Typeface.NORMAL
        );
        details.setLineSpacing(0f, 1.22f);
        security.addView(
                details,
                margins(-1, -2, 0, 10, 0, 0)
        );

        page.addView(
                security,
                margins(-1, -2, 0, 18, 0, 0)
        );

        setPage(scroll(page));
    }

    private void chooseFile() {
        Intent picker = new Intent(
                Intent.ACTION_OPEN_DOCUMENT
        );
        picker.addCategory(Intent.CATEGORY_OPENABLE);
        picker.setType("*/*");
        startActivityForResult(
                picker,
                PICK_FILE_REQUEST
        );
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data
    ) {
        super.onActivityResult(
                requestCode,
                resultCode,
                data
        );

        if (
                requestCode != PICK_FILE_REQUEST
                        || resultCode != RESULT_OK
                        || data == null
                        || data.getData() == null
        ) {
            return;
        }

        pendingFileUri = data.getData();
        pendingFileName =
                pendingFileUri.getLastPathSegment();

        if (
                pendingFileName == null
                        || pendingFileName.isEmpty()
        ) {
            pendingFileName = "Selected file";
        }

        try {
            getContentResolver().takePersistableUriPermission(
                    pendingFileUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
            );
        } catch (Exception ignored) {
        }

        if (pendingFileLabel != null) {
            pendingFileLabel.setText(
                    "Selected: " + pendingFileName
            );
            pendingFileLabel.setTextColor(GREEN);
        }
    }

    private void stopPolling() {
        handler.removeCallbacks(poller);
        activeTaskId = "";
        activeTaskUrl = "";
        activeMessages = null;
        activeStatus = null;
    }

    private boolean requireApi() {
        if (api != null) {
            return true;
        }

        showSettings();
        toast("Connect your Manus API key first.");
        return false;
    }

    private void runAsync(
            ThrowingRunnable action,
            ErrorHandler errorHandler
    ) {
        executor.execute(
                () -> {
                    try {
                        action.run();
                    } catch (Exception error) {
                        runOnUiThread(
                                () -> errorHandler.handle(error)
                        );
                    }
                }
        );
    }

    private void showError(
            String title,
            Exception error
    ) {
        runOnUiThread(
                () -> new AlertDialog.Builder(this)
                        .setTitle(title)
                        .setMessage(
                                error.getMessage() == null
                                        ? error.getClass()
                                        .getSimpleName()
                                        : error.getMessage()
                        )
                        .setPositiveButton("OK", null)
                        .show()
        );
    }

    private void showToastOnUi(String message) {
        runOnUiThread(
                () -> toast(message)
        );
    }

    private void setHeader(
            String title,
            String subtitle
    ) {
        titleView.setText(title);
        subtitleView.setText(subtitle);
    }

    private void setPage(View page) {
        content.removeAllViews();
        content.addView(
                page,
                new FrameLayout.LayoutParams(
                        -1,
                        -1
                )
        );
    }

    private ScrollView scroll(View child) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.addView(
                child,
                new ScrollView.LayoutParams(
                        -1,
                        -2
                )
        );
        return scroll;
    }

    private LinearLayout page() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(
                dp(18),
                dp(18),
                dp(18),
                dp(30)
        );
        return page;
    }

    private LinearLayout card() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(
                dp(15),
                dp(15),
                dp(15),
                dp(15)
        );
        card.setBackground(
                rounded(CARD, 18, BORDER, 1)
        );
        return card;
    }

    private View actionCard(
            String icon,
            String title,
            String description,
            int accent,
            Runnable action
    ) {
        LinearLayout item = card();
        item.setClickable(true);

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView iconView = label(
                icon,
                28f,
                accent,
                Typeface.BOLD
        );
        iconView.setGravity(Gravity.CENTER);
        iconView.setPadding(
                dp(12),
                dp(8),
                dp(12),
                dp(8)
        );
        iconView.setBackground(
                rounded(
                        Color.argb(
                                35,
                                Color.red(accent),
                                Color.green(accent),
                                Color.blue(accent)
                        ),
                        14,
                        accent,
                        1
                )
        );
        row.addView(iconView);

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.addView(
                label(
                        title,
                        17f,
                        TEXT,
                        Typeface.BOLD
                )
        );

        TextView detail = label(
                description,
                13f,
                MUTED,
                Typeface.NORMAL
        );
        detail.setLineSpacing(0f, 1.14f);
        labels.addView(detail);

        LinearLayout.LayoutParams labelParams =
                margins(0, -2, 14, 0, 0, 0);
        labelParams.weight = 1f;
        row.addView(labels, labelParams);

        item.addView(row);
        item.setOnClickListener(
                view -> action.run()
        );
        return item;
    }

    private View emptyState(
            String title,
            String description
    ) {
        LinearLayout item = card();
        item.setGravity(Gravity.CENTER);

        TextView titleView = label(
                title,
                17f,
                TEXT,
                Typeface.BOLD
        );
        titleView.setGravity(Gravity.CENTER);
        item.addView(titleView);

        TextView detail = label(
                description,
                13f,
                MUTED,
                Typeface.NORMAL
        );
        detail.setGravity(Gravity.CENTER);
        item.addView(detail);

        return item;
    }

    private Spinner profileSpinner() {
        Spinner spinner = new Spinner(this);

        String[] profiles = {
                "Lite — quicker and lower usage",
                "Standard — balanced capability",
                "Max — strongest capability"
        };

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_dropdown_item,
                        profiles
                );

        spinner.setAdapter(adapter);
        spinner.setSelection(1);
        spinner.setBackground(
                rounded(SURFACE, 10, BORDER, 1)
        );
        spinner.setPadding(
                dp(10),
                0,
                dp(10),
                0
        );
        spinner.setMinimumHeight(dp(48));
        return spinner;
    }

    private EditText input(
            String hint,
            boolean multiline
    ) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setHintTextColor(MUTED);
        input.setTextColor(TEXT);
        input.setTextSize(14f);
        input.setPadding(
                dp(13),
                dp(11),
                dp(13),
                dp(11)
        );
        input.setBackground(
                rounded(SURFACE, 12, BORDER, 1)
        );

        input.setInputType(
                multiline
                        ? InputType.TYPE_CLASS_TEXT
                                | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                        : InputType.TYPE_CLASS_TEXT
                                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        );

        return input;
    }

    private Button navButton(
            String text,
            Runnable action
    ) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(11f);
        button.setTextColor(MUTED);
        button.setBackgroundColor(
                Color.TRANSPARENT
        );
        button.setOnClickListener(
                view -> action.run()
        );
        return button;
    }

    private Button button(
            String text,
            int background,
            int foreground
    ) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(14f);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setTextColor(foreground);
        button.setBackground(
                rounded(background, 12, 0, 0)
        );
        return button;
    }

    private Button smallButton(
            String text,
            int background
    ) {
        Button button = button(
                text,
                background,
                Color.WHITE
        );
        button.setMinHeight(0);
        button.setMinimumHeight(dp(42));
        button.setPadding(
                dp(12),
                0,
                dp(12),
                0
        );
        return button;
    }

    private TextView section(String text) {
        return label(
                text,
                20f,
                TEXT,
                Typeface.BOLD
        );
    }

    private TextView badge(
            String text,
            int background
    ) {
        TextView badge = label(
                text,
                10f,
                Color.WHITE,
                Typeface.BOLD
        );
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(
                dp(10),
                dp(6),
                dp(10),
                dp(6)
        );
        badge.setBackground(
                rounded(background, 14, 0, 0)
        );
        return badge;
    }

    private TextView label(
            String text,
            float size,
            int color,
            int style
    ) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setTypeface(
                Typeface.create("sans", style)
        );
        return view;
    }

    private GradientDrawable rounded(
            int color,
            int radius,
            int strokeColor,
            int strokeWidth
    ) {
        GradientDrawable drawable =
                new GradientDrawable();

        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));

        if (strokeWidth > 0) {
            drawable.setStroke(
                    dp(strokeWidth),
                    strokeColor
            );
        }

        return drawable;
    }

    private LinearLayout.LayoutParams navParams() {
        return new LinearLayout.LayoutParams(
                0,
                dp(54),
                1f
        );
    }

    private LinearLayout.LayoutParams margins(
            int width,
            int height,
            int left,
            int top,
            int right,
            int bottom
    ) {
        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        width,
                        height
                );

        params.setMargins(
                dp(left),
                dp(top),
                dp(right),
                dp(bottom)
        );

        return params;
    }

    private void selectNav(Button selected) {
        Button[] buttons = {
                navHome,
                navNew,
                navTasks,
                navSettings
        };

        for (Button button : buttons) {
            boolean active = button == selected;

            button.setTextColor(
                    active ? Color.WHITE : MUTED
            );

            button.setBackground(
                    active
                            ? rounded(PURPLE, 12, 0, 0)
                            : rounded(
                                    Color.TRANSPARENT,
                                    12,
                                    0,
                                    0
                            )
            );
        }
    }

    private int statusColor(String status) {
        if ("running".equals(status)) {
            return BLUE;
        }
        if ("stopped".equals(status)) {
            return GREEN;
        }
        if ("waiting".equals(status)) {
            return ORANGE;
        }
        if ("error".equals(status)) {
            return RED;
        }
        return MUTED;
    }

    private String shortId(String value) {
        if (value == null || value.length() <= 10) {
            return value == null ? "" : value;
        }
        return value.substring(0, 10) + "…";
    }

    private int dp(int value) {
        return Math.round(
                value
                        * getResources()
                        .getDisplayMetrics()
                        .density
        );
    }

    private void toast(String message) {
        Toast.makeText(
                this,
                message,
                Toast.LENGTH_SHORT
        ).show();
    }

    private interface ThrowingRunnable {
        void run() throws Exception;
    }

    private interface ErrorHandler {
        void handle(Exception error);
    }
}
