package com.atlasagent.app;

import org.json.JSONArray;
import org.json.JSONObject;

final class EventFormatter {
    private EventFormatter() {
    }

    static EventView format(JSONObject event) {
        String type = event.optString("type", "event");

        if ("user_message".equals(type)) {
            return new EventView(
                    "YOU",
                    extractText(event.opt("user_message")),
                    "user"
            );
        }

        if ("assistant_message".equals(type)) {
            return new EventView(
                    "ATLAS",
                    extractText(event.opt("assistant_message")),
                    "assistant"
            );
        }

        if ("status_update".equals(type)) {
            JSONObject status =
                    event.optJSONObject("status_update");

            String agentStatus = status == null
                    ? "unknown"
                    : status.optString(
                            "agent_status",
                            "unknown"
                    );

            String description = "";
            if (status != null) {
                JSONObject detail =
                        status.optJSONObject("status_detail");
                if (detail != null) {
                    description = detail.optString(
                            "waiting_description",
                            ""
                    );
                }
            }

            return new EventView(
                    "STATUS • " + agentStatus.toUpperCase(),
                    description.isEmpty()
                            ? "The agent is " + agentStatus + "."
                            : description,
                    "status"
            );
        }

        if ("plan_update".equals(type)) {
            return new EventView(
                    "PLAN",
                    formatPlan(
                            event.optJSONObject("plan_update")
                    ),
                    "plan"
            );
        }

        if ("new_plan_step".equals(type)) {
            JSONObject step =
                    event.optJSONObject("new_plan_step");

            return new EventView(
                    "NEW STEP",
                    step == null
                            ? "New plan step"
                            : step.optString(
                                    "title",
                                    "New plan step"
                            ),
                    "plan"
            );
        }

        if ("tool_used".equals(type)) {
            return new EventView(
                    "TOOL",
                    extractText(event.opt("tool_used")),
                    "tool"
            );
        }

        if ("explanation".equals(type)) {
            return new EventView(
                    "WORK NOTE",
                    extractText(event.opt("explanation")),
                    "tool"
            );
        }

        if ("error_message".equals(type)) {
            return new EventView(
                    "ERROR",
                    extractText(event.opt("error_message")),
                    "error"
            );
        }

        return new EventView(
                type.toUpperCase(),
                extractText(event),
                "status"
        );
    }

    static String latestAgentStatus(JSONArray messages) {
        String status = "unknown";

        for (int index = 0; index < messages.length(); index++) {
            JSONObject event =
                    messages.optJSONObject(index);

            if (
                    event == null
                            || !"status_update".equals(
                                    event.optString("type")
                            )
            ) {
                continue;
            }

            JSONObject value =
                    event.optJSONObject("status_update");

            if (value != null) {
                status = value.optString(
                        "agent_status",
                        status
                );
            }
        }

        return status;
    }

    private static String formatPlan(JSONObject plan) {
        if (plan == null) {
            return "The agent updated its plan.";
        }

        JSONArray steps = plan.optJSONArray("steps");

        if (steps == null || steps.length() == 0) {
            return extractText(plan);
        }

        StringBuilder result = new StringBuilder();

        for (int index = 0; index < steps.length(); index++) {
            JSONObject step =
                    steps.optJSONObject(index);

            if (step == null) {
                continue;
            }

            boolean finished =
                    step.optLong("end_at", 0L) > 0L;
            boolean started =
                    step.optLong("started_at", 0L) > 0L;

            String marker = finished
                    ? "✓"
                    : started ? "●" : "○";

            result.append(marker)
                    .append(" ")
                    .append(
                            step.optString(
                                    "title",
                                    "Plan step"
                            )
                    );

            if (index + 1 < steps.length()) {
                result.append("\n");
            }
        }

        return result.toString();
    }

    private static String extractText(Object value) {
        if (value == null || value == JSONObject.NULL) {
            return "";
        }

        if (value instanceof String) {
            return (String) value;
        }

        if (value instanceof JSONArray) {
            JSONArray array = (JSONArray) value;
            StringBuilder result = new StringBuilder();

            for (int index = 0; index < array.length(); index++) {
                String text = extractText(array.opt(index));

                if (!text.isEmpty()) {
                    if (result.length() > 0) {
                        result.append("\n");
                    }
                    result.append(text);
                }
            }

            return result.toString();
        }

        if (value instanceof JSONObject) {
            JSONObject object = (JSONObject) value;
            String[] preferred = {
                    "content",
                    "text",
                    "message",
                    "description",
                    "title",
                    "name",
                    "url",
                    "value",
                    "error"
            };

            StringBuilder result = new StringBuilder();

            for (String key : preferred) {
                if (!object.has(key)) {
                    continue;
                }

                String text = extractText(object.opt(key));

                if (!text.isEmpty()) {
                    if (result.length() > 0) {
                        result.append("\n");
                    }
                    result.append(text);
                }
            }

            if (result.length() > 0) {
                return result.toString();
            }

            return object.toString();
        }

        return String.valueOf(value);
    }

    static final class EventView {
        final String label;
        final String body;
        final String style;

        EventView(
                String label,
                String body,
                String style
        ) {
            this.label = label;
            this.body = body;
            this.style = style;
        }
    }
}
