# Atlas Agent for Android

Atlas Agent is an independent Android client powered by the official
Manus API v2.

## Features

- Create autonomous multi-step tasks.
- Choose Lite, Standard, or Max agent profiles.
- Enable interactive mode for follow-up questions.
- Upload and attach files using Android's secure document picker.
- View live status, plans, new steps, tool activity, work notes,
  assistant results, and errors.
- Continue tasks with follow-up messages.
- Stop a running task.
- Open the complete Manus task workspace in a browser.
- Review task history and credit usage.
- Chat with the account's persistent default agent.
- Encrypt the API key using Android Keystore with AES-GCM.

## Account requirement

The APK does not contain an API key. The user enters a valid Manus API
v2 key from their own account on first launch. Tasks use that account's
enabled capabilities, connectors, skills, plan, and credits.

## Important limitations

- This is an independent client, not an official Manus-branded app.
- It does not copy Manus proprietary infrastructure.
- Sensitive confirmations, browser takeover, and some connector
  authorization steps may require opening the full Manus workspace.
- Files are uploaded only when the user explicitly attaches them.
- No broad Android storage permission is requested.

## Build

Upload this ZIP to the existing Android Auto Build Agent repository.
After the workflow is green, download the `READY-APK` artifact.
