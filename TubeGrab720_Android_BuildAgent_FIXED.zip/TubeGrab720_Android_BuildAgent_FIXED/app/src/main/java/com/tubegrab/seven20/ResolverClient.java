package com.tubegrab.seven20;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

final class ResolverClient {
    private ResolverClient() {}

    static MediaItem resolve(String sourceUrl, String resolverBaseUrl) throws Exception {
        URI source = URI.create(sourceUrl.trim());
        if (!"https".equalsIgnoreCase(source.getScheme()) || source.getHost() == null) {
            throw new IllegalArgumentException("Enter a valid HTTPS link.");
        }

        if (isDirectMp4(source)) {
            String rawName = source.getPath();
            rawName = rawName == null ? "" : rawName.substring(rawName.lastIndexOf('/') + 1);
            String fileName = FileNames.safeFileName(
                    rawName.isBlank() ? "tubegrab-720p.mp4" : rawName
            );
            return new MediaItem(
                    source.toString(),
                    fileName,
                    source.getHost(),
                    0,
                    "",
                    source.toString(),
                    FileNames.ensureMp4(fileName),
                    -1L
            );
        }

        String base = resolverBaseUrl == null ? "" : resolverBaseUrl.trim();
        if (base.isEmpty()) {
            throw new IllegalStateException(
                    "Set an authorized resolver API in Settings before fetching platform links."
            );
        }

        while (base.endsWith("/")) {
            base = base.substring(0, base.length() - 1);
        }

        URL endpoint = new URL(base + "/v1/resolve");
        HttpURLConnection connection = (HttpURLConnection) endpoint.openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(20_000);
        connection.setReadTimeout(35_000);
        connection.setDoOutput(true);
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setRequestProperty("Accept", "application/json");

        JSONObject request = new JSONObject()
                .put("url", source.toString())
                .put("quality", 720)
                .put("format", "mp4");

        try (OutputStream output = connection.getOutputStream()) {
            output.write(request.toString().getBytes(StandardCharsets.UTF_8));
        }

        int status = connection.getResponseCode();
        InputStream bodyStream = status >= 200 && status < 300
                ? connection.getInputStream()
                : connection.getErrorStream();
        String body = read(bodyStream);

        if (status < 200 || status >= 300) {
            String message = "Resolver returned HTTP " + status + ".";
            try {
                String apiMessage = new JSONObject(body).optString("error");
                if (!apiMessage.isBlank()) message = apiMessage;
            } catch (Exception ignored) {
                // Keep the HTTP status message.
            }
            throw new IllegalStateException(message);
        }

        JSONObject json = new JSONObject(body);
        JSONArray options = json.optJSONArray("options");
        JSONObject selected = null;

        if (options != null) {
            for (int index = 0; index < options.length(); index++) {
                JSONObject option = options.optJSONObject(index);
                if (option == null) continue;

                String kind = option.optString("kind", "video").toLowerCase(Locale.US);
                String format = option.optString("format", "").toLowerCase(Locale.US);
                String label = option.optString("label", "").toLowerCase(Locale.US);
                int height = option.optInt("height", 0);
                String mediaUrl = option.optString("url", "");

                boolean is720 = height == 720 || label.contains("720p");
                boolean valid = "video".equals(kind)
                        && "mp4".equals(format)
                        && is720
                        && mediaUrl.startsWith("https://");

                if (valid) {
                    selected = option;
                    break;
                }
            }
        }

        if (selected == null) {
            throw new IllegalStateException(
                    "The resolver did not return an authorized 720p MP4 file."
            );
        }

        String title = json.optString("title", "TubeGrab video");
        String fileName = selected.optString(
                "filename",
                FileNames.safeFileName(title) + "-720p.mp4"
        );

        return new MediaItem(
                source.toString(),
                title,
                json.optString("channel", "Unknown channel"),
                json.optInt("duration_seconds", 0),
                json.optString("thumbnail_url", ""),
                selected.getString("url"),
                FileNames.ensureMp4(FileNames.safeFileName(fileName)),
                selected.optLong("content_length", -1L)
        );
    }

    private static boolean isDirectMp4(URI source) {
        String path = source.getPath();
        return path != null && path.toLowerCase(Locale.US).endsWith(".mp4");
    }

    private static String read(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder result = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(stream, StandardCharsets.UTF_8)
        )) {
            String line;
            while ((line = reader.readLine()) != null) {
                result.append(line);
            }
        }
        return result.toString();
    }
}
