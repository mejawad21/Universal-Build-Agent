package com.tubegrab.seven20;

import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

public final class PlayerActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        String uriValue = getIntent().getStringExtra("uri");
        if (uriValue == null || uriValue.isBlank()) {
            TextView error = new TextView(this);
            error.setText("Unable to open this downloaded file.");
            error.setTextColor(Color.WHITE);
            error.setGravity(Gravity.CENTER);
            root.addView(error, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
            ));
            setContentView(root);
            return;
        }

        VideoView player = new VideoView(this);
        MediaController controls = new MediaController(this);
        controls.setAnchorView(player);
        player.setMediaController(controls);
        player.setVideoURI(Uri.parse(uriValue));
        player.setOnPreparedListener(mediaPlayer -> {
            mediaPlayer.setLooping(false);
            player.start();
        });

        root.addView(player, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        setContentView(root);
    }
}
