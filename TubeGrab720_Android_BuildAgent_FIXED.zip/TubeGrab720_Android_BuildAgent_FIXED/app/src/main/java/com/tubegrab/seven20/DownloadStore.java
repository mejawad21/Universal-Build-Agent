package com.tubegrab.seven20;

import android.app.DownloadManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

final class DownloadStore {
    private static final String PREFS = "tubegrab_downloads";
    private static final String KEY_RECORDS = "records";

    private final Context context;
    private final DownloadManager manager;
    private final SharedPreferences preferences;

    DownloadStore(Context context) {
        this.context = context.getApplicationContext();
        this.manager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
        this.preferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    long enqueue(MediaItem item) {
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(item.downloadUrl))
                .setTitle(item.title)
                .setDescription("TubeGrab 720p MP4")
                .setMimeType("video/mp4")
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
                .setNotificationVisibility(
                        DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                )
                .setDestinationInExternalPublicDir(
                        Environment.DIRECTORY_DOWNLOADS,
                        "TubeGrab/" + item.fileName
                );

        long id = manager.enqueue(request);
        List<DownloadRecord> records = records();
        records.add(0, new DownloadRecord(
                id,
                item.title,
                item.fileName,
                System.currentTimeMillis()
        ));
        save(records);
        return id;
    }

    List<DownloadRecord> records() {
        List<DownloadRecord> result = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(preferences.getString(KEY_RECORDS, "[]"));
            for (int index = 0; index < array.length(); index++) {
                JSONObject item = array.optJSONObject(index);
                if (item != null) result.add(DownloadRecord.fromJson(item));
            }
        } catch (Exception ignored) {
            // Return any records decoded before the malformed item.
        }
        return result;
    }

    void removeRecord(long id) {
        List<DownloadRecord> updated = new ArrayList<>();
        for (DownloadRecord record : records()) {
            if (record.id != id) updated.add(record);
        }
        save(updated);
    }

    void clearCompletedRecords() {
        List<DownloadRecord> updated = new ArrayList<>();
        for (DownloadRecord record : records()) {
            DownloadSnapshot snapshot = snapshot(record);
            if (snapshot.status != DownloadManager.STATUS_SUCCESSFUL) {
                updated.add(record);
            }
        }
        save(updated);
    }

    void cancel(long id) {
        manager.remove(id);
    }

    Uri downloadedUri(long id) {
        return manager.getUriForDownloadedFile(id);
    }

    DownloadSnapshot snapshot(DownloadRecord record) {
        DownloadManager.Query query = new DownloadManager.Query().setFilterById(record.id);
        try (Cursor cursor = manager.query(query)) {
            if (cursor == null || !cursor.moveToFirst()) {
                return new DownloadSnapshot(
                        record,
                        DownloadManager.STATUS_FAILED,
                        0L,
                        0L,
                        DownloadManager.ERROR_UNKNOWN
                );
            }

            return new DownloadSnapshot(
                    record,
                    cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)),
                    cursor.getLong(
                            cursor.getColumnIndexOrThrow(
                                    DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR
                            )
                    ),
                    cursor.getLong(
                            cursor.getColumnIndexOrThrow(
                                    DownloadManager.COLUMN_TOTAL_SIZE_BYTES
                            )
                    ),
                    cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
            );
        } catch (Exception error) {
            return new DownloadSnapshot(
                    record,
                    DownloadManager.STATUS_FAILED,
                    0L,
                    0L,
                    DownloadManager.ERROR_UNKNOWN
            );
        }
    }

    private void save(List<DownloadRecord> records) {
        JSONArray array = new JSONArray();
        for (DownloadRecord record : records) {
            array.put(record.toJson());
        }
        preferences.edit().putString(KEY_RECORDS, array.toString()).apply();
    }

    static final class DownloadSnapshot {
        final DownloadRecord record;
        final int status;
        final long downloadedBytes;
        final long totalBytes;
        final int reason;

        DownloadSnapshot(
                DownloadRecord record,
                int status,
                long downloadedBytes,
                long totalBytes,
                int reason
        ) {
            this.record = record;
            this.status = status;
            this.downloadedBytes = downloadedBytes;
            this.totalBytes = totalBytes;
            this.reason = reason;
        }

        int percent() {
            if (totalBytes <= 0L) return 0;
            return (int) Math.max(
                    0,
                    Math.min(100, downloadedBytes * 100L / totalBytes)
            );
        }
    }
}
