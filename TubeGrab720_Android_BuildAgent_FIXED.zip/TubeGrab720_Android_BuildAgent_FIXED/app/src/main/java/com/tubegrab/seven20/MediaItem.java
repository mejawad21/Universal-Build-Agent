package com.tubegrab.seven20;

final class MediaItem {
    final String sourceUrl;
    final String title;
    final String channel;
    final int durationSeconds;
    final String thumbnailUrl;
    final String downloadUrl;
    final String fileName;
    final long contentLength;

    MediaItem(
            String sourceUrl,
            String title,
            String channel,
            int durationSeconds,
            String thumbnailUrl,
            String downloadUrl,
            String fileName,
            long contentLength
    ) {
        this.sourceUrl = sourceUrl;
        this.title = title;
        this.channel = channel;
        this.durationSeconds = durationSeconds;
        this.thumbnailUrl = thumbnailUrl;
        this.downloadUrl = downloadUrl;
        this.fileName = fileName;
        this.contentLength = contentLength;
    }
}
