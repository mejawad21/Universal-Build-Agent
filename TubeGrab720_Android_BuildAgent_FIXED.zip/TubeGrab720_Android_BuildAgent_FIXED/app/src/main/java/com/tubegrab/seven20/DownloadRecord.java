package com.tubegrab.seven20;

import org.json.JSONObject;

final class DownloadRecord {
    final long id;
    final String title;
    final String fileName;
    final long createdAt;

    DownloadRecord(long id, String title, String fileName, long createdAt) {
        this.id = id;
        this.title = title;
        this.fileName = fileName;
        this.createdAt = createdAt;
    }

    JSONObject toJson() {
        return new JSONObject()
                .put("id", id)
                .put("title", title)
                .put("fileName", fileName)
                .put("createdAt", createdAt);
    }

    static DownloadRecord fromJson(JSONObject json) {
        return new DownloadRecord(
                json.optLong("id"),
                json.optString("title", "TubeGrab video"),
                json.optString("fileName", "video.mp4"),
                json.optLong("createdAt", System.currentTimeMillis())
        );
    }
}
