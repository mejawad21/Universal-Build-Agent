package com.tubegrab.seven20;

import java.util.Locale;

final class FileNames {
    private FileNames() {}

    static String safeFileName(String value) {
        String cleaned = value == null ? "" : value
                .replaceAll("[\\\\/:*?\"<>|]", "_")
                .replaceAll("\\s+", " ")
                .trim();
        if (cleaned.isEmpty()) cleaned = "tubegrab-720p";
        return cleaned.length() > 120 ? cleaned.substring(0, 120).trim() : cleaned;
    }

    static String ensureMp4(String value) {
        String cleaned = safeFileName(value);
        if (!cleaned.toLowerCase(Locale.US).endsWith(".mp4")) {
            cleaned += ".mp4";
        }
        return cleaned;
    }
}
