package com.tubegrab.seven20;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final int REQUEST_STORAGE = 44;
    private static final int MAX_BATCH = 20;
    private static final int RED = Color.rgb(255, 45, 63);
    private static final int DARK = Color.rgb(13, 14, 17);
    private static final int SURFACE = Color.rgb(23, 25, 30);
    private static final int SURFACE_2 = Color.rgb(32, 34, 40);
    private static final int WHITE = Color.rgb(247, 247, 248);
    private static final int MUTED = Color.rgb(176, 179, 187);

    private final ExecutorService executor = Executors.newFixedThreadPool(4);
    private final Handler handler = new Handler(Looper.getMainLooper());

    private DownloadStore downloadStore;
    private SharedPreferences settings;
    private FrameLayout content;
    private EditText linkInput;
    private LinearLayout results;
    private ProgressBar fetchProgress;
    private TextView fetchStatus;
    private boolean batchMode;
    private boolean libraryVisible;

    private final Runnable libraryRefresh = new Runnable() {
        @Override
        public void run() {
            if (libraryVisible) {
                showLibrary();
                handler.postDelayed(this, 1_200L);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(DARK);
        getWindow().setNavigationBarColor(DARK);

        downloadStore = new DownloadStore(this);
        settings = getSharedPreferences("tubegrab_settings", MODE_PRIVATE);

        LinearLayout root = vertical();
        root.setBackgroundColor(DARK);

        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
        ));

        LinearLayout navigation = horizontal();
        navigation.setPadding(dp(10), dp(8), dp(10), dp(8));
        navigation.setBackgroundColor(SURFACE);

        Button home = button("HOME");
        Button library = button("LIBRARY");
        home.setOnClickListener(v -> showHome());
        library.setOnClickListener(v -> showLibrary());

        navigation.addView(home, weighted());
        navigation.addView(space(dp(8)));
        navigation.addView(library, weighted());
        root.addView(navigation);

        setContentView(root);
        requestLegacyStorageIfNeeded();
        showHome();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        executor.shutdownNow();
        super.onDestroy();
    }

    private void showHome() {
        libraryVisible = false;
        handler.removeCallbacks(libraryRefresh);
        content.removeAllViews();

        ScrollView scroll = new ScrollView(this);
        LinearLayout page = vertical();
        page.setPadding(dp(18), dp(18), dp(18), dp(28));
        scroll.addView(page);

        LinearLayout header = horizontal();
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = text("TubeGrab 720", 26, WHITE, true);
        header.addView(title, weighted());

        Button settingsButton = button("SETTINGS");
        settingsButton.setOnClickListener(v -> showResolverSettings());
        header.addView(settingsButton);
        page.addView(header);

        page.addView(text(
                "Single and multiple 720p MP4 download queue",
                14,
                MUTED,
                false
        ));
        page.addView(space(dp(18)));

        LinearLayout modeRow = horizontal();
        Button single = button("SINGLE");
        Button multiple = button("MULTIPLE");
        single.setOnClickListener(v -> setBatchMode(false, single, multiple));
        multiple.setOnClickListener(v -> setBatchMode(true, single, multiple));
        modeRow.addView(single, weighted());
        modeRow.addView(space(dp(8)));
        modeRow.addView(multiple, weighted());
        page.addView(modeRow);
        setBatchMode(batchMode, single, multiple);
        page.addView(space(dp(12)));

        LinearLayout inputCard = card();
        inputCard.setPadding(dp(14), dp(14), dp(14), dp(14));

        linkInput = new EditText(this);
        linkInput.setTextColor(WHITE);
        linkInput.setHintTextColor(MUTED);
        linkInput.setBackground(rounded(SURFACE_2, dp(16)));
        linkInput.setPadding(dp(14), dp(12), dp(14), dp(12));
        linkInput.setInputType(
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI
        );
        linkInput.setMinLines(batchMode ? 5 : 1);
        linkInput.setMaxLines(batchMode ? 10 : 3);
        updateInputHint();
        inputCard.addView(linkInput, matchWidth());

        inputCard.addView(space(dp(10)));
        LinearLayout inputActions = horizontal();
        Button paste = button("PASTE");
        Button fetch = button("FETCH 720p");
        paste.setOnClickListener(v -> pasteClipboard());
        fetch.setOnClickListener(v -> fetchLinks());
        inputActions.addView(paste, weighted());
        inputActions.addView(space(dp(8)));
        inputActions.addView(fetch, weighted());
        inputCard.addView(inputActions);
        page.addView(inputCard);

        fetchProgress = new ProgressBar(this);
        fetchProgress.setIndeterminate(true);
        fetchProgress.setVisibility(View.GONE);
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(
                dp(38),
                dp(38)
        );
        progressParams.gravity = Gravity.CENTER_HORIZONTAL;
        progressParams.topMargin = dp(14);
        page.addView(fetchProgress, progressParams);

        fetchStatus = text("", 13, MUTED, false);
        fetchStatus.setGravity(Gravity.CENTER);
        page.addView(fetchStatus, matchWidth());

        results = vertical();
        page.addView(results);

        LinearLayout notice = card();
        notice.setPadding(dp(14), dp(14), dp(14), dp(14));
        notice.addView(text(
                "Use direct HTTPS MP4 links or an authorized resolver API. " +
                        "TubeGrab does not include DRM, account, signature, or access-control bypasses.",
                12,
                MUTED,
                false
        ));
        LinearLayout.LayoutParams noticeParams = matchWidth();
        noticeParams.topMargin = dp(18);
        page.addView(notice, noticeParams);

        content.addView(scroll);
    }

    private void setBatchMode(boolean enabled, Button single, Button multiple) {
        batchMode = enabled;
        single.setAlpha(enabled ? 0.55f : 1f);
        multiple.setAlpha(enabled ? 1f : 0.55f);
        if (linkInput != null) {
            linkInput.setMinLines(enabled ? 5 : 1);
            linkInput.setMaxLines(enabled ? 10 : 3);
            updateInputHint();
        }
    }

    private void updateInputHint() {
        if (linkInput == null) return;
        linkInput.setHint(
                batchMode
                        ? "Paste up to 20 links, one per line"
                        : "Paste one video or direct MP4 link"
        );
    }

    private void pasteClipboard() {
        ClipboardManager clipboard =
                (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData data = clipboard == null ? null : clipboard.getPrimaryClip();
        if (data == null || data.getItemCount() == 0) {
            toast("Clipboard is empty.");
            return;
        }
        CharSequence value = data.getItemAt(0).coerceToText(this);
        if (value != null) {
            linkInput.setText(value.toString().trim());
            linkInput.setSelection(linkInput.length());
        }
    }

    private void fetchLinks() {
        List<String> links = parseLinks(linkInput.getText().toString());
        if (links.isEmpty()) {
            toast("Paste at least one HTTPS link.");
            return;
        }

        results.removeAllViews();
        fetchProgress.setVisibility(View.VISIBLE);
        fetchStatus.setText("Fetching 0 of " + links.size() + "…");

        final int total = links.size();
        final int[] complete = {0};

        for (String link : links) {
            executor.execute(() -> {
                try {
                    MediaItem media = ResolverClient.resolve(link, resolverBaseUrl());
                    handler.post(() -> addMediaCard(media));
                } catch (Exception error) {
                    handler.post(() -> addErrorCard(link, readable(error)));
                } finally {
                    handler.post(() -> {
                        complete[0]++;
                        fetchStatus.setText(
                                "Fetched " + complete[0] + " of " + total
                        );
                        if (complete[0] >= total) {
                            fetchProgress.setVisibility(View.GONE);
                        }
                    });
                }
            });
        }
    }

    private List<String> parseLinks(String raw) {
        List<String> result = new ArrayList<>();
        if (raw == null) return result;

        String[] values = batchMode
                ? raw.split("[\\r\\n]+")
                : new String[]{raw.trim()};

        for (String value : values) {
            String trimmed = value.trim();
            if (trimmed.startsWith("https://") && !result.contains(trimmed)) {
                result.add(trimmed);
                if (result.size() >= MAX_BATCH) break;
            }
        }
        return result;
    }

    private void addMediaCard(MediaItem media) {
        LinearLayout card = card();
        card.setPadding(dp(12), dp(12), dp(12), dp(12));

        LinearLayout row = horizontal();
        row.setGravity(Gravity.TOP);

        ImageView thumbnail = new ImageView(this);
        thumbnail.setScaleType(ImageView.ScaleType.CENTER_CROP);
        thumbnail.setBackground(rounded(SURFACE_2, dp(12)));
        row.addView(thumbnail, new LinearLayout.LayoutParams(dp(120), dp(68)));
        loadThumbnail(media.thumbnailUrl, thumbnail);

        LinearLayout details = vertical();
        details.setPadding(dp(12), 0, 0, 0);
        details.addView(text(media.title, 16, WHITE, true));
        details.addView(text(media.channel, 12, MUTED, false));

        String meta = "720p • MP4";
        if (media.durationSeconds > 0) {
            meta += " • " + duration(media.durationSeconds);
        }
        if (media.contentLength > 0) {
            meta += " • " + bytes(media.contentLength);
        }
        details.addView(text(meta, 12, RED, true));
        row.addView(details, weighted());
        card.addView(row);

        Button download = button("DOWNLOAD 720p");
        download.setOnClickListener(v -> {
            try {
                long id = downloadStore.enqueue(media);
                toast("Added to download queue.");
                download.setText("QUEUED #" + id);
                download.setEnabled(false);
            } catch (Exception error) {
                toast(readable(error));
            }
        });
        LinearLayout.LayoutParams buttonParams = matchWidth();
        buttonParams.topMargin = dp(10);
        card.addView(download, buttonParams);

        LinearLayout.LayoutParams params = matchWidth();
        params.topMargin = dp(12);
        results.addView(card, params);
    }

    private void addErrorCard(String link, String error) {
        LinearLayout card = card();
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        card.addView(text("Could not fetch", 16, RED, true));
        card.addView(text(link, 12, MUTED, false));
        card.addView(text(error, 13, WHITE, false));

        LinearLayout.LayoutParams params = matchWidth();
        params.topMargin = dp(12);
        results.addView(card, params);
    }

    private void loadThumbnail(String url, ImageView view) {
        if (url == null || !url.startsWith("https://")) return;
        executor.execute(() -> {
            try {
                Bitmap bitmap = BitmapFactory.decodeStream(new URL(url).openStream());
                if (bitmap != null) {
                    handler.post(() -> view.setImageBitmap(bitmap));
                }
            } catch (Exception ignored) {
                // Thumbnail failure must not block downloading.
            }
        });
    }

    private void showLibrary() {
        libraryVisible = true;
        handler.removeCallbacks(libraryRefresh);
        content.removeAllViews();

        ScrollView scroll = new ScrollView(this);
        LinearLayout page = vertical();
        page.setPadding(dp(18), dp(18), dp(18), dp(28));
        scroll.addView(page);

        LinearLayout header = horizontal();
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(text("Library", 26, WHITE, true), weighted());

        Button clear = button("CLEAR COMPLETED");
        clear.setOnClickListener(v -> {
            downloadStore.clearCompletedRecords();
            showLibrary();
        });
        header.addView(clear);
        page.addView(header);
        page.addView(text(
                "Active downloads and saved 720p videos",
                14,
                MUTED,
                false
        ));
        page.addView(space(dp(14)));

        List<DownloadRecord> records = downloadStore.records();
        if (records.isEmpty()) {
            LinearLayout empty = card();
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(18), dp(30), dp(18), dp(30));
            empty.addView(text(
                    "No downloads yet.",
                    17,
                    WHITE,
                    true
            ));
            page.addView(empty, matchWidth());
        } else {
            for (DownloadRecord record : records) {
                addDownloadRow(page, downloadStore.snapshot(record));
            }
        }

        content.addView(scroll);
        handler.postDelayed(libraryRefresh, 1_200L);
    }

    private void addDownloadRow(
            LinearLayout parent,
            DownloadStore.DownloadSnapshot snapshot
    ) {
        LinearLayout card = card();
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        card.addView(text(snapshot.record.title, 16, WHITE, true));
        card.addView(text(snapshot.record.fileName, 12, MUTED, false));

        ProgressBar progress = new ProgressBar(
                this,
                null,
                android.R.attr.progressBarStyleHorizontal
        );
        progress.setMax(100);
        progress.setProgress(snapshot.percent());
        LinearLayout.LayoutParams progressParams = matchWidth();
        progressParams.topMargin = dp(10);
        card.addView(progress, progressParams);

        TextView status = text(statusText(snapshot), 12, MUTED, false);
        card.addView(status);

        LinearLayout actions = horizontal();
        actions.setPadding(0, dp(8), 0, 0);

        if (snapshot.status == DownloadManager.STATUS_SUCCESSFUL) {
            Button play = button("PLAY");
            play.setOnClickListener(v -> play(snapshot.record.id));
            actions.addView(play, weighted());
        } else if (
                snapshot.status == DownloadManager.STATUS_RUNNING
                        || snapshot.status == DownloadManager.STATUS_PENDING
                        || snapshot.status == DownloadManager.STATUS_PAUSED
        ) {
            Button cancel = button("CANCEL");
            cancel.setOnClickListener(v -> {
                downloadStore.cancel(snapshot.record.id);
                downloadStore.removeRecord(snapshot.record.id);
                showLibrary();
            });
            actions.addView(cancel, weighted());
        } else {
            Button remove = button("REMOVE");
            remove.setOnClickListener(v -> {
                downloadStore.removeRecord(snapshot.record.id);
                showLibrary();
            });
            actions.addView(remove, weighted());
        }

        card.addView(actions);
        LinearLayout.LayoutParams params = matchWidth();
        params.topMargin = dp(12);
        parent.addView(card, params);
    }

    private void play(long downloadId) {
        Uri uri = downloadStore.downloadedUri(downloadId);
        if (uri == null) {
            toast("The downloaded file is no longer available.");
            return;
        }
        Intent player = new Intent(this, PlayerActivity.class);
        player.putExtra("uri", uri.toString());
        player.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(player);
    }

    private String statusText(DownloadStore.DownloadSnapshot snapshot) {
        if (snapshot.status == DownloadManager.STATUS_SUCCESSFUL) {
            return "Complete • Tap PLAY";
        }
        if (snapshot.status == DownloadManager.STATUS_RUNNING) {
            return snapshot.percent() + "% • "
                    + bytes(snapshot.downloadedBytes)
                    + " of "
                    + bytes(snapshot.totalBytes);
        }
        if (snapshot.status == DownloadManager.STATUS_PENDING) return "Waiting in queue";
        if (snapshot.status == DownloadManager.STATUS_PAUSED) return "Paused by Android";
        return "Download failed • reason " + snapshot.reason;
    }

    private void showResolverSettings() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI
        );
        input.setText(resolverBaseUrl());
        input.setHint("https://your-authorized-api.example");

        int padding = dp(20);
        FrameLayout container = new FrameLayout(this);
        container.setPadding(padding, 0, padding, 0);
        container.addView(input, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        new AlertDialog.Builder(this)
                .setTitle("Resolver API")
                .setMessage(
                        "Enter the base URL of an API you are authorized to use. " +
                                "Direct HTTPS MP4 links do not require an API."
                )
                .setView(container)
                .setPositiveButton("Save", (dialog, which) -> {
                    String value = input.getText().toString().trim();
                    if (!value.isEmpty() && !value.startsWith("https://")) {
                        toast("Resolver URL must start with https://");
                        return;
                    }
                    settings.edit().putString("resolver_url", value).apply();
                    toast("Resolver setting saved.");
                })
                .setNeutralButton("Network settings", (dialog, which) -> {
                    try {
                        startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS));
                    } catch (Exception ignored) {
                        // Device may not expose this settings activity.
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private String resolverBaseUrl() {
        return settings.getString(
                "resolver_url",
                BuildConfig.DEFAULT_RESOLVER_URL
        );
    }

    private void requestLegacyStorageIfNeeded() {
        if (Build.VERSION.SDK_INT <= 28
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    REQUEST_STORAGE
            );
        }
    }

    private LinearLayout vertical() {
        LinearLayout view = new LinearLayout(this);
        view.setOrientation(LinearLayout.VERTICAL);
        return view;
    }

    private LinearLayout horizontal() {
        LinearLayout view = new LinearLayout(this);
        view.setOrientation(LinearLayout.HORIZONTAL);
        return view;
    }

    private LinearLayout card() {
        LinearLayout card = vertical();
        card.setBackground(rounded(SURFACE, dp(22)));
        return card;
    }

    private Button button(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextColor(WHITE);
        button.setTextSize(12);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setAllCaps(false);
        button.setBackground(rounded(RED, dp(14)));
        button.setPadding(dp(12), dp(8), dp(12), dp(8));
        return button;
    }

    private TextView text(
            String value,
            int size,
            int color,
            boolean bold
    ) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(size);
        text.setTextColor(color);
        if (bold) text.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return text;
    }

    private View space(int size) {
        Space space = new Space(this);
        space.setLayoutParams(new LinearLayout.LayoutParams(size, size));
        return space;
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private LinearLayout.LayoutParams matchWidth() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        return drawable;
    }

    private int dp(int value) {
        return Math.round(
                value * getResources().getDisplayMetrics().density
        );
    }

    private String readable(Throwable error) {
        String value = error.getMessage();
        if (value == null || value.isBlank()) return "Unable to complete the request.";
        return value.length() > 180 ? value.substring(0, 177) + "…" : value;
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private static String duration(int seconds) {
        int hours = seconds / 3600;
        int minutes = (seconds % 3600) / 60;
        int secs = seconds % 60;
        return hours > 0
                ? String.format(Locale.US, "%d:%02d:%02d", hours, minutes, secs)
                : String.format(Locale.US, "%02d:%02d", minutes, secs);
    }

    private static String bytes(long value) {
        if (value < 0) return "Unknown size";
        if (value >= 1_073_741_824L) {
            return String.format(Locale.US, "%.1f GB", value / 1_073_741_824.0);
        }
        if (value >= 1_048_576L) {
            return String.format(Locale.US, "%.1f MB", value / 1_048_576.0);
        }
        if (value >= 1_024L) {
            return String.format(Locale.US, "%.0f KB", value / 1_024.0);
        }
        return value + " B";
    }
}
