plugins {
    id("com.android.application")
}

android {
    namespace = "com.tubegrab.seven20"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.tubegrab.seven20"
        minSdk = 23
        targetSdk = 35
        versionCode = 3
        versionName = "3.0.0"
    }

    buildTypes {
        debug {
            buildConfigField("String", "DEFAULT_RESOLVER_URL", "\"\"")
        }
        release {
            isMinifyEnabled = false
            buildConfigField("String", "DEFAULT_RESOLVER_URL", "\"\"")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        buildConfig = true
    }
}
