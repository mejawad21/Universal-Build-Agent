# TubeGrab 720 — Build-Agent-Compatible Android Project

This is the corrected **native Android** edition of TubeGrab 720.

It was created specifically for the user's **Universal-Build-Agent / Auto Build APK or EXE V2** workflow, which builds standard Android Gradle projects directly.

## Features

- Single-link mode
- Multiple-link mode, up to 20 links
- Clipboard Paste button
- Strict 720p MP4 selection
- Batch fetch
- Android DownloadManager background queue
- Public `Downloads/TubeGrab` storage
- Android notifications
- Active progress percentages
- Cancel control
- Completed-download history
- Built-in video player
- Dark red modern interface
- No Flutter SDK required
- No third-party runtime libraries

## Build with the user's automatic builder

Upload this ZIP to the **Universal-Build-Agent** repository exactly as before.  
The workflow will detect:

- `settings.gradle.kts`
- `app/build.gradle.kts`
- Android SDK 35
- AGP 8.10.1
- Gradle 8.11.1

It can then run:

```text
./gradlew clean assembleDebug
```

The output is:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Resolver API

Direct HTTPS `.mp4` links work without configuration.

For platform page links, open **Settings** inside the app and enter the base URL of an authorized resolver implementing:

```text
POST /v1/resolve
```

Request:

```json
{
  "url": "https://source.example/video",
  "quality": 720,
  "format": "mp4"
}
```

The response must include an HTTPS 720p MP4 option.

This project does not include DRM bypass, account bypass, protected-stream extraction, signature circumvention, or access-control bypass code.
