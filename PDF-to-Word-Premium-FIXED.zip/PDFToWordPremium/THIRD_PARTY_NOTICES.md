# Third-party notices

## PdfBox-Android

This project uses `com.tom-roush:pdfbox-android:2.0.27.0`, an Android port of
Apache PDFBox.

License: Apache License 2.0.

No proprietary Microsoft Word, Adobe Acrobat, iLovePDF or other commercial
application code or assets are included.
