# PDFBox uses resource files and reflection internally.
-keep class com.tom_roush.pdfbox.** { *; }
-keep class com.tom_roush.fontbox.** { *; }
-dontwarn org.bouncycastle.**
