package com.pdfword.premium;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;

import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.rendering.ImageType;
import com.tom_roush.pdfbox.rendering.PDFRenderer;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CancellationException;
import java.util.concurrent.atomic.AtomicBoolean;

final class PdfToWordConverter {
    interface Callback {
        void onProgress(int percent, String message);
    }

    static final class Result {
        final int convertedPages;
        final int editablePages;
        final int imagePages;

        Result(int convertedPages, int editablePages, int imagePages) {
            this.convertedPages = convertedPages;
            this.editablePages = editablePages;
            this.imagePages = imagePages;
        }
    }

    private PdfToWordConverter() {
    }

    static Result convert(
            Context context,
            Uri sourceUri,
            Uri destinationUri,
            String sourceName,
            ConversionOptions options,
            AtomicBoolean cancellation,
            Callback callback
    ) throws IOException {
        File jobDirectory = new File(
                context.getCacheDir(),
                "pdf-to-word-" + System.currentTimeMillis()
        );

        if (!jobDirectory.mkdirs() && !jobDirectory.isDirectory()) {
            throw new IOException("Could not create the temporary conversion folder.");
        }

        File sourceFile = new File(jobDirectory, "source.pdf");
        File outputFile = new File(jobDirectory, "output.docx");
        List<File> temporaryImages = new ArrayList<>();

        callback.onProgress(2, "Preparing PDF…");

        try {
            copyUriToFile(
                    context.getContentResolver(),
                    sourceUri,
                    sourceFile,
                    cancellation
            );

            ensureNotCancelled(cancellation);

            List<DocxWriter.PageContent> convertedPages = new ArrayList<>();
            int editablePageCount = 0;
            int imagePageCount = 0;

            try (PDDocument document = loadDocument(sourceFile, options.password)) {
                int totalPages = document.getNumberOfPages();
                List<Integer> selectedPages = PageRangeParser.parse(
                        options.pageRange,
                        totalPages
                );

                PDFTextStripper textStripper = new PDFTextStripper();
                textStripper.setSortByPosition(true);
                textStripper.setLineSeparator("\n");
                textStripper.setParagraphStart("");
                textStripper.setParagraphEnd("\n");
                textStripper.setPageStart("");
                textStripper.setPageEnd("");

                PDFRenderer renderer = new PDFRenderer(document);
                float imageDpi = options.highQuality ? 220f : 150f;
                int jpegQuality = options.highQuality ? 94 : 86;

                for (int position = 0; position < selectedPages.size(); position++) {
                    ensureNotCancelled(cancellation);

                    int zeroBasedPage = selectedPages.get(position);
                    int humanPage = zeroBasedPage + 1;
                    int progress = 8 + Math.round(
                            (position / (float) Math.max(1, selectedPages.size())) * 76f
                    );

                    callback.onProgress(
                            progress,
                            "Converting page " + humanPage + " of " + totalPages + "…"
                    );

                    boolean makeImage = options.mode
                            == ConversionOptions.Mode.EXACT_LAYOUT;

                    String pageText = "";
                    if (!makeImage) {
                        textStripper.setStartPage(humanPage);
                        textStripper.setEndPage(humanPage);
                        pageText = normalizeText(textStripper.getText(document));
                        makeImage = visibleCharacterCount(pageText) < 25;
                    }

                    if (makeImage) {
                        Bitmap bitmap = renderer.renderImageWithDPI(
                                zeroBasedPage,
                                imageDpi,
                                ImageType.RGB
                        );

                        File imageFile = new File(
                                jobDirectory,
                                "page-" + humanPage + ".jpg"
                        );

                        try (FileOutputStream imageOutput = new FileOutputStream(imageFile)) {
                            if (!bitmap.compress(
                                    Bitmap.CompressFormat.JPEG,
                                    jpegQuality,
                                    imageOutput
                            )) {
                                throw new IOException(
                                        "Could not encode page " + humanPage + "."
                                );
                            }
                        }

                        convertedPages.add(
                                DocxWriter.PageContent.image(
                                        humanPage,
                                        imageFile,
                                        bitmap.getWidth(),
                                        bitmap.getHeight()
                                )
                        );
                        temporaryImages.add(imageFile);
                        imagePageCount++;

                        if (!bitmap.isRecycled()) {
                            bitmap.recycle();
                        }
                    } else {
                        convertedPages.add(
                                DocxWriter.PageContent.text(
                                        humanPage,
                                        splitParagraphs(pageText)
                                )
                        );
                        editablePageCount++;
                    }
                }
            } catch (IOException error) {
                if (looksLikePasswordError(error)) {
                    throw new IOException(
                            "This PDF is password protected. Enter the correct password and try again.",
                            error
                    );
                }
                throw error;
            }

            ensureNotCancelled(cancellation);
            callback.onProgress(88, "Building the Word document…");

            String documentTitle = removePdfExtension(sourceName);
            DocxWriter.write(outputFile, documentTitle, convertedPages);

            ensureNotCancelled(cancellation);
            callback.onProgress(96, "Saving Word document…");

            copyFileToUri(
                    context.getContentResolver(),
                    outputFile,
                    destinationUri,
                    cancellation
            );

            callback.onProgress(100, "Word document created successfully.");

            return new Result(
                    convertedPages.size(),
                    editablePageCount,
                    imagePageCount
            );
        } finally {
            deleteRecursively(jobDirectory);
        }
    }

    private static PDDocument loadDocument(
            File sourceFile,
            String password
    ) throws IOException {
        if (password == null || password.isEmpty()) {
            return PDDocument.load(sourceFile);
        }
        return PDDocument.load(sourceFile, password);
    }

    private static String normalizeText(String value) {
        if (value == null) {
            return "";
        }

        return value
                .replace("\r\n", "\n")
                .replace('\r', '\n')
                .replace('\u0000', ' ')
                .trim();
    }

    private static List<String> splitParagraphs(String text) {
        List<String> paragraphs = new ArrayList<>();
        if (text == null || text.trim().isEmpty()) {
            return paragraphs;
        }

        String[] lines = text.split("\n", -1);
        StringBuilder currentParagraph = new StringBuilder();

        for (String rawLine : lines) {
            String line = rawLine.trim();

            if (line.isEmpty()) {
                flushParagraph(currentParagraph, paragraphs);
                if (!paragraphs.isEmpty()
                        && !paragraphs.get(paragraphs.size() - 1).isEmpty()) {
                    paragraphs.add("");
                }
                continue;
            }

            if (currentParagraph.length() == 0) {
                currentParagraph.append(line);
            } else if (shouldJoin(currentParagraph, line)) {
                currentParagraph.append(' ').append(line);
            } else {
                flushParagraph(currentParagraph, paragraphs);
                currentParagraph.append(line);
            }
        }

        flushParagraph(currentParagraph, paragraphs);
        return paragraphs;
    }

    private static boolean shouldJoin(
            StringBuilder currentParagraph,
            String nextLine
    ) {
        if (currentParagraph.length() == 0) {
            return false;
        }

        char last = currentParagraph.charAt(currentParagraph.length() - 1);
        boolean sentenceEnded = last == '.'
                || last == '!'
                || last == '?'
                || last == ':'
                || last == ';';

        boolean nextLooksLikeList = nextLine.startsWith("•")
                || nextLine.startsWith("- ")
                || nextLine.matches("^\\d+[.)].*");

        boolean currentLooksLikeHeading = currentParagraph.length() <= 70
                && currentParagraph.toString().equals(
                        currentParagraph.toString().toUpperCase()
                );

        return !sentenceEnded && !nextLooksLikeList && !currentLooksLikeHeading;
    }

    private static void flushParagraph(
            StringBuilder paragraph,
            List<String> output
    ) {
        if (paragraph.length() > 0) {
            output.add(paragraph.toString().trim());
            paragraph.setLength(0);
        }
    }

    private static int visibleCharacterCount(String text) {
        if (text == null) {
            return 0;
        }

        int count = 0;
        for (int index = 0; index < text.length(); index++) {
            if (!Character.isWhitespace(text.charAt(index))) {
                count++;
            }
        }
        return count;
    }

    private static boolean looksLikePasswordError(IOException error) {
        String message = error.getMessage();
        if (message == null) {
            return false;
        }

        String lower = message.toLowerCase();
        return lower.contains("password")
                || lower.contains("decrypt")
                || lower.contains("encrypted");
    }

    private static String removePdfExtension(String name) {
        if (name == null || name.trim().isEmpty()) {
            return "Converted PDF";
        }

        String clean = name.trim();
        if (clean.toLowerCase().endsWith(".pdf")) {
            clean = clean.substring(0, clean.length() - 4);
        }
        return clean;
    }

    private static void copyUriToFile(
            ContentResolver resolver,
            Uri source,
            File destination,
            AtomicBoolean cancellation
    ) throws IOException {
        try (InputStream input = resolver.openInputStream(source);
             OutputStream output = new FileOutputStream(destination)) {
            if (input == null) {
                throw new IOException("The selected PDF could not be opened.");
            }
            copy(input, output, cancellation);
        }
    }

    private static void copyFileToUri(
            ContentResolver resolver,
            File source,
            Uri destination,
            AtomicBoolean cancellation
    ) throws IOException {
        try (InputStream input = new java.io.FileInputStream(source);
             OutputStream output = resolver.openOutputStream(destination, "w")) {
            if (output == null) {
                throw new IOException("The selected save location could not be opened.");
            }
            copy(input, output, cancellation);
        }
    }

    private static void copy(
            InputStream input,
            OutputStream output,
            AtomicBoolean cancellation
    ) throws IOException {
        byte[] buffer = new byte[64 * 1024];
        int read;
        while ((read = input.read(buffer)) != -1) {
            ensureNotCancelled(cancellation);
            output.write(buffer, 0, read);
        }
    }

    private static void ensureNotCancelled(
            AtomicBoolean cancellation
    ) {
        if (cancellation != null && cancellation.get()) {
            throw new CancellationException("Conversion cancelled.");
        }
    }

    private static void deleteRecursively(File file) {
        if (file == null || !file.exists()) {
            return;
        }

        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) {
                    deleteRecursively(child);
                }
            }
        }

        //noinspection ResultOfMethodCallIgnored
        file.delete();
    }
}
