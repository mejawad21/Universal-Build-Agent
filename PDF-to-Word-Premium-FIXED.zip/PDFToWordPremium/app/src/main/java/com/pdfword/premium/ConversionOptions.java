package com.pdfword.premium;

final class ConversionOptions {
    enum Mode {
        SMART_EDITABLE,
        EXACT_LAYOUT
    }

    final Mode mode;
    final String pageRange;
    final String password;
    final boolean highQuality;

    ConversionOptions(
            Mode mode,
            String pageRange,
            String password,
            boolean highQuality
    ) {
        this.mode = mode;
        this.pageRange = pageRange == null ? "" : pageRange.trim();
        this.password = password == null ? "" : password;
        this.highQuality = highQuality;
    }
}
