package com.pdfword.premium;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.TreeSet;

final class PageRangeParser {
    private PageRangeParser() {
    }

    static List<Integer> parse(String input, int totalPages) {
        if (totalPages <= 0) {
            throw new IllegalArgumentException("The PDF contains no pages.");
        }

        String value = input == null ? "" : input.trim().toLowerCase(Locale.US);
        if (value.isEmpty() || value.equals("all")) {
            List<Integer> allPages = new ArrayList<>(totalPages);
            for (int index = 0; index < totalPages; index++) {
                allPages.add(index);
            }
            return allPages;
        }

        TreeSet<Integer> pages = new TreeSet<>();
        String[] groups = value.split(",");

        for (String rawGroup : groups) {
            String group = rawGroup.trim();
            if (group.isEmpty()) {
                continue;
            }

            if (group.contains("-")) {
                String[] bounds = group.split("-", -1);
                if (bounds.length != 2
                        || bounds[0].trim().isEmpty()
                        || bounds[1].trim().isEmpty()) {
                    throw new IllegalArgumentException(
                            "Invalid page range. Use a format such as 1-3,5."
                    );
                }

                int first = parsePage(bounds[0], totalPages);
                int last = parsePage(bounds[1], totalPages);
                int start = Math.min(first, last);
                int end = Math.max(first, last);

                for (int page = start; page <= end; page++) {
                    pages.add(page - 1);
                }
            } else {
                pages.add(parsePage(group, totalPages) - 1);
            }
        }

        if (pages.isEmpty()) {
            throw new IllegalArgumentException("No pages were selected.");
        }

        return new ArrayList<>(pages);
    }

    private static int parsePage(String value, int totalPages) {
        final int page;
        try {
            page = Integer.parseInt(value.trim());
        } catch (NumberFormatException error) {
            throw new IllegalArgumentException(
                    "Invalid page number: " + value.trim()
            );
        }

        if (page < 1 || page > totalPages) {
            throw new IllegalArgumentException(
                    "Page " + page + " is outside this PDF. It has "
                            + totalPages + " pages."
            );
        }

        return page;
    }
}
