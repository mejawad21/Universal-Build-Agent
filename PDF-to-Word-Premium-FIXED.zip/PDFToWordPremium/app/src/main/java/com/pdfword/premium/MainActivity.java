package com.pdfword.premium;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.google.android.material.textfield.TextInputEditText;
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.rendering.ImageType;
import com.tom_roush.pdfbox.rendering.PDFRenderer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public final class MainActivity extends AppCompatActivity {
    private static final String WORD_MIME =
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document";

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final AtomicBoolean cancellation = new AtomicBoolean(false);

    private ImageView pdfPreview;
    private TextView fileNameText;
    private TextView fileDetailsText;
    private TextView statusText;
    private TextInputEditText pageRangeInput;
    private TextInputEditText passwordInput;
    private RadioButton smartModeRadio;
    private RadioButton exactModeRadio;
    private MaterialSwitch highQualitySwitch;
    private MaterialButton selectPdfButton;
    private MaterialButton convertButton;
    private MaterialButton cancelButton;
    private MaterialButton openWordButton;
    private MaterialButton shareWordButton;
    private LinearProgressIndicator progressIndicator;
    private View resultActions;

    private Uri selectedPdfUri;
    private Uri pendingOutputUri;
    private Uri lastOutputUri;
    private String selectedPdfName = "document.pdf";
    private long selectedPdfSize = -1L;
    private boolean converting;

    private final ActivityResultLauncher<String[]> openPdfLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.OpenDocument(),
                    uri -> {
                        if (uri != null) {
                            try {
                                getContentResolver().takePersistableUriPermission(
                                        uri,
                                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                                );
                            } catch (SecurityException ignored) {
                                // Temporary access is enough for providers that do not persist it.
                            }
                            selectPdf(uri);
                        }
                    }
            );

    private final ActivityResultLauncher<String> saveWordLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.CreateDocument(WORD_MIME),
                    uri -> {
                        if (uri != null) {
                            pendingOutputUri = uri;
                            beginConversion();
                        }
                    }
            );

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        PDFBoxResourceLoader.init(getApplicationContext());
        setContentView(R.layout.activity_main);

        bindViews();
        bindActions();
        updateUi();

        Intent launchIntent = getIntent();
        if (launchIntent != null && launchIntent.getData() != null) {
            selectPdf(launchIntent.getData());
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getData() != null) {
            selectPdf(intent.getData());
        }
    }

    private void bindViews() {
        pdfPreview = findViewById(R.id.pdfPreview);
        fileNameText = findViewById(R.id.fileNameText);
        fileDetailsText = findViewById(R.id.fileDetailsText);
        statusText = findViewById(R.id.statusText);
        pageRangeInput = findViewById(R.id.pageRangeInput);
        passwordInput = findViewById(R.id.passwordInput);
        smartModeRadio = findViewById(R.id.smartModeRadio);
        exactModeRadio = findViewById(R.id.exactModeRadio);
        highQualitySwitch = findViewById(R.id.highQualitySwitch);
        selectPdfButton = findViewById(R.id.selectPdfButton);
        convertButton = findViewById(R.id.convertButton);
        cancelButton = findViewById(R.id.cancelButton);
        openWordButton = findViewById(R.id.openWordButton);
        shareWordButton = findViewById(R.id.shareWordButton);
        progressIndicator = findViewById(R.id.progressIndicator);
        resultActions = findViewById(R.id.resultActions);
    }

    private void bindActions() {
        selectPdfButton.setOnClickListener(view ->
                openPdfLauncher.launch(new String[]{"application/pdf"})
        );

        smartModeRadio.setOnClickListener(view -> {
            smartModeRadio.setChecked(true);
            exactModeRadio.setChecked(false);
        });

        exactModeRadio.setOnClickListener(view -> {
            exactModeRadio.setChecked(true);
            smartModeRadio.setChecked(false);
        });

        convertButton.setOnClickListener(view -> {
            if (selectedPdfUri == null || converting) {
                return;
            }

            String outputName = suggestedOutputName(selectedPdfName);
            saveWordLauncher.launch(outputName);
        });

        cancelButton.setOnClickListener(view -> {
            cancellation.set(true);
            cancelButton.setEnabled(false);
            statusText.setText("Stopping safely…");
        });

        openWordButton.setOnClickListener(view -> openWordFile());
        shareWordButton.setOnClickListener(view -> shareWordFile());
    }

    private void selectPdf(Uri uri) {
        selectedPdfUri = uri;
        lastOutputUri = null;
        pendingOutputUri = null;
        readFileMetadata(uri);
        updateUi();
        renderPreview(uri);
    }

    private void readFileMetadata(Uri uri) {
        String name = null;
        long size = -1L;

        try (Cursor cursor = getContentResolver().query(
                uri,
                new String[]{
                        OpenableColumns.DISPLAY_NAME,
                        OpenableColumns.SIZE
                },
                null,
                null,
                null
        )) {
            if (cursor != null && cursor.moveToFirst()) {
                int nameColumn = cursor.getColumnIndex(
                        OpenableColumns.DISPLAY_NAME
                );
                int sizeColumn = cursor.getColumnIndex(
                        OpenableColumns.SIZE
                );

                if (nameColumn >= 0 && !cursor.isNull(nameColumn)) {
                    name = cursor.getString(nameColumn);
                }
                if (sizeColumn >= 0 && !cursor.isNull(sizeColumn)) {
                    size = cursor.getLong(sizeColumn);
                }
            }
        } catch (Exception ignored) {
            // Metadata is optional.
        }

        selectedPdfName = name == null || name.trim().isEmpty()
                ? "document.pdf"
                : name;
        selectedPdfSize = size;
    }

    private void renderPreview(Uri uri) {
        statusText.setText("Reading PDF preview…");
        pdfPreview.setImageDrawable(null);
        pdfPreview.setBackgroundResource(R.drawable.preview_placeholder);

        executor.execute(() -> {
            File previewFile = new File(
                    getCacheDir(),
                    "preview-" + System.currentTimeMillis() + ".pdf"
            );
            Bitmap previewBitmap = null;
            int pageCount = -1;
            boolean passwordRequired = false;

            try {
                copyUri(uri, previewFile);
                try (PDDocument document = PDDocument.load(previewFile)) {
                    pageCount = document.getNumberOfPages();
                    if (pageCount > 0) {
                        PDFRenderer renderer = new PDFRenderer(document);
                        previewBitmap = renderer.renderImageWithDPI(
                                0,
                                92f,
                                ImageType.RGB
                        );
                    }
                }
            } catch (IOException error) {
                String message = error.getMessage();
                passwordRequired = message != null
                        && message.toLowerCase().contains("password");
            } finally {
                //noinspection ResultOfMethodCallIgnored
                previewFile.delete();
            }

            Bitmap finalPreviewBitmap = previewBitmap;
            int finalPageCount = pageCount;
            boolean finalPasswordRequired = passwordRequired;

            runOnUiThread(() -> {
                if (selectedPdfUri == null || !selectedPdfUri.equals(uri)) {
                    if (finalPreviewBitmap != null
                            && !finalPreviewBitmap.isRecycled()) {
                        finalPreviewBitmap.recycle();
                    }
                    return;
                }

                if (finalPreviewBitmap != null) {
                    pdfPreview.setBackground(null);
                    pdfPreview.setImageBitmap(finalPreviewBitmap);
                }

                String details = formatSize(selectedPdfSize);
                if (finalPageCount > 0) {
                    details += " • " + finalPageCount
                            + (finalPageCount == 1 ? " page" : " pages");
                } else if (finalPasswordRequired) {
                    details += " • Password required";
                }

                fileDetailsText.setText(details);
                statusText.setText(
                        finalPasswordRequired
                                ? "Enter the PDF password before converting."
                                : getString(R.string.privacy_note)
                );
            });
        });
    }

    private void beginConversion() {
        if (selectedPdfUri == null || pendingOutputUri == null || converting) {
            return;
        }

        ConversionOptions.Mode mode = exactModeRadio.isChecked()
                ? ConversionOptions.Mode.EXACT_LAYOUT
                : ConversionOptions.Mode.SMART_EDITABLE;

        ConversionOptions options = new ConversionOptions(
                mode,
                textOf(pageRangeInput),
                textOf(passwordInput),
                highQualitySwitch.isChecked()
        );

        converting = true;
        cancellation.set(false);
        lastOutputUri = null;
        progressIndicator.setProgressCompat(0, false);
        updateUi();

        Uri source = selectedPdfUri;
        Uri destination = pendingOutputUri;
        String sourceName = selectedPdfName;

        executor.execute(() -> {
            try {
                PdfToWordConverter.Result result = PdfToWordConverter.convert(
                        this,
                        source,
                        destination,
                        sourceName,
                        options,
                        cancellation,
                        (percent, message) -> runOnUiThread(() -> {
                            progressIndicator.setProgressCompat(percent, true);
                            statusText.setText(message);
                        })
                );

                runOnUiThread(() -> {
                    converting = false;
                    lastOutputUri = destination;
                    pendingOutputUri = null;
                    statusText.setText(
                            "Done: " + result.convertedPages + " pages • "
                                    + result.editablePages + " editable • "
                                    + result.imagePages + " preserved as images"
                    );
                    Toast.makeText(
                            this,
                            "Word document created",
                            Toast.LENGTH_LONG
                    ).show();
                    updateUi();
                });
            } catch (CancellationException error) {
                runOnUiThread(() -> {
                    converting = false;
                    pendingOutputUri = null;
                    statusText.setText("Conversion cancelled safely.");
                    updateUi();
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    converting = false;
                    pendingOutputUri = null;
                    String message = error.getMessage();
                    if (message == null || message.trim().isEmpty()) {
                        message = "Conversion failed.";
                    }
                    statusText.setText(message);
                    Toast.makeText(
                            this,
                            message,
                            Toast.LENGTH_LONG
                    ).show();
                    updateUi();
                });
            }
        });
    }

    private void openWordFile() {
        if (lastOutputUri == null) {
            return;
        }

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(lastOutputUri, WORD_MIME);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        try {
            startActivity(intent);
        } catch (ActivityNotFoundException error) {
            Toast.makeText(
                    this,
                    "Install Microsoft Word or another DOCX viewer.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private void shareWordFile() {
        if (lastOutputUri == null) {
            return;
        }

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType(WORD_MIME);
        intent.putExtra(Intent.EXTRA_STREAM, lastOutputUri);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(intent, "Share Word document"));
    }

    private void updateUi() {
        boolean hasPdf = selectedPdfUri != null;

        fileNameText.setText(
                hasPdf ? selectedPdfName : getString(R.string.no_pdf)
        );
        selectPdfButton.setText(
                hasPdf ? R.string.replace_pdf : R.string.select_pdf
        );

        selectPdfButton.setEnabled(!converting);
        convertButton.setEnabled(hasPdf && !converting);
        smartModeRadio.setEnabled(!converting);
        exactModeRadio.setEnabled(!converting);
        highQualitySwitch.setEnabled(!converting);
        pageRangeInput.setEnabled(!converting);
        passwordInput.setEnabled(!converting);

        progressIndicator.setVisibility(
                converting ? View.VISIBLE : View.GONE
        );
        cancelButton.setVisibility(
                converting ? View.VISIBLE : View.GONE
        );
        cancelButton.setEnabled(converting && !cancellation.get());

        resultActions.setVisibility(
                !converting && lastOutputUri != null
                        ? View.VISIBLE
                        : View.GONE
        );
    }

    private void copyUri(Uri uri, File destination) throws IOException {
        try (InputStream input = getContentResolver().openInputStream(uri);
             FileOutputStream output = new FileOutputStream(destination)) {
            if (input == null) {
                throw new IOException("The selected PDF could not be opened.");
            }

            byte[] buffer = new byte[64 * 1024];
            int read;
            while ((read = input.read(buffer)) != -1) {
                output.write(buffer, 0, read);
            }
        }
    }

    private static String textOf(TextInputEditText input) {
        return input.getText() == null ? "" : input.getText().toString();
    }

    private static String suggestedOutputName(String inputName) {
        String clean = inputName == null || inputName.trim().isEmpty()
                ? "Converted"
                : inputName.trim();

        if (clean.toLowerCase().endsWith(".pdf")) {
            clean = clean.substring(0, clean.length() - 4);
        }

        clean = clean.replaceAll("[\\\\/:*?\"<>|]", "_");
        return clean + " - Word.docx";
    }

    private static String formatSize(long bytes) {
        if (bytes < 0) {
            return "PDF selected";
        }

        DecimalFormat format = new DecimalFormat("0.##");
        if (bytes >= 1024L * 1024L) {
            return format.format(bytes / (1024d * 1024d)) + " MB";
        }
        if (bytes >= 1024L) {
            return format.format(bytes / 1024d) + " KB";
        }
        return bytes + " bytes";
    }

    @Override
    protected void onDestroy() {
        cancellation.set(true);
        executor.shutdownNow();
        super.onDestroy();
    }
}
