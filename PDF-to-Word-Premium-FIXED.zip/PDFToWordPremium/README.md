# PDF to Word Premium

A focused, offline Android application that converts PDF files to Microsoft Word
`.docx` documents.

## Premium features

- Smart Editable Word mode
  - Extracts selectable text from text-based PDFs.
  - Joins wrapped lines into readable paragraphs.
  - Detects short title-like lines and formats them as headings.
  - Automatically inserts scanned pages as page images when editable text is not found.
- Exact Layout Word mode
  - Renders every selected PDF page and places it in Word.
  - Best for scanned PDFs, forms, diagrams and complex designs.
- Page-range support such as `1-3,5,8-10`.
- Password field for protected PDFs.
- High-quality or standard image rendering.
- First-page preview.
- Progress display and safe cancellation.
- Open and share the created Word document.
- Works offline.
- No Internet permission.
- No account, ads or cloud uploads.

## Important conversion limitations

PDF and Word use different layout models. Editable mode prioritizes selectable
text and readable paragraphs, so complex columns, tables and typography may not
match the original exactly. Exact Layout mode preserves visual appearance but
the page content is inserted as an image and is therefore not editable.

This app does not perform OCR. Scanned pages are preserved as images in Smart
mode and Exact Layout mode.

## Android build stack

- Java 17
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- compileSdk 35
- minSdk 23
- PDFBox Android 2.0.27.0
- Material Components 1.12.0

## Build with GitHub Actions

The project already contains:

`.github/workflows/build-apk.yml`

Upload the extracted project contents to a GitHub repository and run the
workflow. The artifact is named `PDF-to-Word-Premium-APK`.
