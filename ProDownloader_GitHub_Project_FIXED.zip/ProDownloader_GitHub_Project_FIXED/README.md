# Pro Downloader

A polished, GitHub-ready Android download manager for **direct HTTP/HTTPS file URLs**. It supports multiple queued downloads, background execution, pause/resume through HTTP range requests, progress notifications, history, search, dark mode, Wi-Fi-only constraints, retries, opening, and sharing.

> **Scope:** This project downloads files from direct URLs that the source server permits. It does not extract streams from YouTube or other protected platforms, bypass DRM/paywalls, defeat authentication, or circumvent a website's restrictions.

## Highlights

- Premium Jetpack Compose interface
- Batch input plus multiple simultaneous WorkManager downloads
- Original source quality; no recompression
- Pause and resume when the server supports HTTP `Range`
- Download speed, ETA, size, and percentage
- Foreground progress notifications with Pause and Cancel actions
- Room download history
- Automatic retry with exponential backoff
- Wi-Fi-only mode
- Public `Downloads/ProDownloader` publishing on Android 10+
- Open and share completed files
- Light and dark themes
- GitHub Actions build workflow

## Technology

- Kotlin with AGP built-in Kotlin support
- Jetpack Compose + Material 3
- WorkManager
- Room
- OkHttp
- MVVM-style UI state and repository separation

## Requirements

- Android Studio compatible with Android Gradle Plugin 9.2.x
- JDK 17
- Android SDK 36
- Minimum device: Android 6.0 (API 23)

## Build

```bash
./gradlew assembleDebug
```

The included official Gradle wrapper downloads Gradle 9.4.1 on first use and verifies the distribution checksum declared in `gradle-wrapper.properties`.

Debug APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

### Build the APK on GitHub

1. Upload this project to a GitHub repository.
2. Open the repository's **Actions** tab.
3. Push to `main`/`master` or open a pull request to run **Android CI**.
4. Open the completed workflow and download the **ProDownloader-debug** artifact.

Release builds are minified. Add your own signing configuration before publishing.

## Use

1. Open the app.
2. Paste one direct `http://` or `https://` file URL, or paste multiple URLs on separate lines.
3. Optionally enter a file name for a single URL and enable Wi-Fi only.
4. Tap **Add to download queue**.
5. Manage the item from the Downloads screen or its notification.

### Resume behavior

The partial file is retained when a download is paused. On resume, the worker requests the remaining bytes with an HTTP `Range` header. If the server does not support range requests, the file safely restarts from zero.

## Repository layout

```text
app/src/main/kotlin/com/example/prodownloader/
├── core/       # App dependency container
├── data/       # Room database, entities, DAO, repository, settings
├── download/   # Scheduler, worker, notifications, storage
├── ui/         # Compose screens, components, ViewModel, theme
└── util/       # URL, file-name, formatting, and intent helpers
```

## Security and legal use

Only download content you own, content in the public domain, or content you are authorized to save. Plain HTTP is supported for compatibility, but HTTPS should be preferred because HTTP traffic is not encrypted. Do not use the project to circumvent access controls, DRM, subscriptions, or platform download restrictions.

## License

MIT — see [LICENSE](LICENSE).


## Repaired build package

This package includes the official Gradle wrapper JAR and uses AGP 9 built-in Kotlin source directories (`src/main/kotlin`). Run:

```bash
./gradlew clean testDebugUnitTest assembleDebug
```

The debug APK will be created at `app/build/outputs/apk/debug/app-debug.apk`.
