# DocEdge Pro Android

DocEdge Pro is a premium multipage document-scanner application.

## Camera scanning

The app uses Google ML Kit's full document-scanner flow:

- Automatic document detection.
- Automatic capture when the document is stable.
- Accurate corner and edge detection.
- Perspective correction and automatic rotation.
- Manual corner adjustment and cropping.
- Page rotation and reordering.
- Color, grayscale, and enhancement filters.
- Shadow removal.
- Stain and wrinkle cleanup.
- Finger-removal tools when supported by the scanner module.
- Camera scanning and photo-gallery import.
- Multipage JPEG and PDF output.

## Document workspace

- Internal scan history with thumbnails.
- Rename and permanently delete documents.
- Built-in multipage PDF viewer.
- Share PDFs through Android's secure FileProvider.
- Export PDFs with the Android document picker.
- Export all page images as a ZIP.
- On-device Latin-script OCR.
- View, copy, and export OCR text as TXT.
- Configurable page limit up to 100 pages.
- No broad storage permission.
- No camera permission requested by this app.

## Device requirements

The document-scanner UI and models are supplied through Google Play services.
The first scan may require a short module download. The scanner requires a
supported Android device with Google Play services and sufficient memory.

## Privacy

Scanning and editing are performed on the device. Files are stored in the
application's private storage until the user explicitly exports or shares them.

## Build

Upload this source ZIP to the existing Android Auto Build Agent repository.
After a successful green build, download the `READY-APK` artifact.

The downloaded source ZIP is not itself an APK.
