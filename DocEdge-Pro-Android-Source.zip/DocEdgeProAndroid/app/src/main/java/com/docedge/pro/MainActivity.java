package com.docedge.pro;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.google.mlkit.vision.documentscanner.GmsDocumentScanner;
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions;
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning;
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends AppCompatActivity {
    private static final int EXPORT_FILE_REQUEST = 510;

    private static final int BG = Color.rgb(7, 16, 15);
    private static final int SURFACE = Color.rgb(16, 29, 27);
    private static final int CARD = Color.rgb(20, 37, 34);
    private static final int BORDER = Color.rgb(43, 65, 60);
    private static final int TEXT = Color.rgb(239, 249, 245);
    private static final int MUTED = Color.rgb(151, 169, 165);
    private static final int ACCENT = Color.rgb(70, 225, 154);
    private static final int BLUE = Color.rgb(76, 177, 255);
    private static final int ORANGE = Color.rgb(255, 184, 95);
    private static final int RED = Color.rgb(255, 105, 120);

    private final ExecutorService executor =
            Executors.newFixedThreadPool(2);

    private final ActivityResultLauncher<IntentSenderRequest>
            scannerLauncher = registerForActivityResult(
            new ActivityResultContracts.StartIntentSenderForResult(),
            activityResult -> {
                if (
                        activityResult.getResultCode() == RESULT_OK
                                && activityResult.getData() != null
                ) {
                    GmsDocumentScanningResult result =
                            GmsDocumentScanningResult
                                    .fromActivityResultIntent(
                                            activityResult.getData()
                                    );

                    if (result != null) {
                        saveScanResult(result);
                    }
                }
            }
    );

    private LinearLayout historyContainer;
    private CheckBox galleryImport;
    private EditText pageLimit;
    private TextView summaryLabel;
    private ProgressBar busyIndicator;

    private ScanRepository repository;
    private List<ScanItem> scans = new ArrayList<>();

    private File pendingExportFile;
    private String pendingExportMime;
    private String pendingExportName;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
        }

        repository = new ScanRepository(this);
        buildInterface();
        refreshHistory();
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }

    private void buildInterface() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setBackgroundColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(
                dp(18),
                dp(18),
                dp(18),
                dp(34)
        );
        scroll.addView(
                root,
                new ScrollView.LayoutParams(
                        -1,
                        -2
                )
        );

        setContentView(scroll);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            scroll.setOnApplyWindowInsetsListener(
                    new View.OnApplyWindowInsetsListener() {
                        @Override
                        public WindowInsets onApplyWindowInsets(
                                View view,
                                WindowInsets insets
                        ) {
                            Insets bars = insets.getInsets(
                                    WindowInsets.Type.systemBars()
                            );

                            root.setPadding(
                                    dp(18) + bars.left,
                                    dp(18) + bars.top,
                                    dp(18) + bars.right,
                                    dp(34) + bars.bottom
                            );

                            return insets;
                        }
                    }
            );
        }

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(
                text(
                        "DocEdge Pro",
                        28f,
                        TEXT,
                        Typeface.BOLD
                )
        );
        titles.addView(
                text(
                        "Automatic document scanner",
                        14f,
                        MUTED,
                        Typeface.NORMAL
                )
        );

        header.addView(
                titles,
                new LinearLayout.LayoutParams(
                        0,
                        -2,
                        1f
                )
        );

        TextView privacy = badge(
                "ON-DEVICE",
                ACCENT,
                BG
        );
        header.addView(privacy);

        root.addView(header);

        LinearLayout hero = card();
        hero.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView heroTitle = text(
                "Scan paper into a clean digital document",
                23f,
                TEXT,
                Typeface.BOLD
        );
        heroTitle.setGravity(Gravity.CENTER);
        hero.addView(heroTitle);

        TextView heroText = text(
                "Automatic capture, corner detection, perspective "
                        + "correction, filters, cleanup, OCR and multipage PDF.",
                14f,
                MUTED,
                Typeface.NORMAL
        );
        heroText.setGravity(Gravity.CENTER);
        heroText.setLineSpacing(0f, 1.18f);
        hero.addView(
                heroText,
                margins(-1, -2, 0, 8, 0, 14)
        );

        Button scanButton = button(
                "Scan New Document",
                ACCENT,
                BG
        );
        scanButton.setTextSize(17f);
        scanButton.setOnClickListener(
                view -> startScanner()
        );
        hero.addView(
                scanButton,
                margins(-1, dp(58), 0, 12, 0, 0)
        );

        root.addView(
                hero,
                margins(-1, -2, 0, 20, 0, 0)
        );

        LinearLayout featureGrid = new LinearLayout(this);
        featureGrid.setOrientation(LinearLayout.HORIZONTAL);

        featureGrid.addView(
                miniFeature(
                        "AUTO",
                        "Finds and fits corners",
                        ACCENT
                ),
                weighted()
        );
        featureGrid.addView(
                miniFeature(
                        "CLEAN",
                        "Shadows, stains, fingers",
                        BLUE
                ),
                weightedMargin()
        );
        featureGrid.addView(
                miniFeature(
                        "OCR",
                        "Extract editable text",
                        ORANGE
                ),
                weightedMargin()
        );

        root.addView(featureGrid);

        LinearLayout settings = card();
        settings.addView(
                text(
                        "Scan options",
                        18f,
                        TEXT,
                        Typeface.BOLD
                )
        );

        galleryImport = new CheckBox(this);
        galleryImport.setText(
                "Allow importing document photos from gallery"
        );
        galleryImport.setTextColor(TEXT);
        galleryImport.setChecked(true);
        settings.addView(galleryImport);

        LinearLayout limitRow = new LinearLayout(this);
        limitRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView limitTitle = text(
                "Maximum pages",
                14f,
                TEXT,
                Typeface.BOLD
        );
        limitRow.addView(
                limitTitle,
                new LinearLayout.LayoutParams(
                        0,
                        -2,
                        1f
                )
        );

        pageLimit = new EditText(this);
        pageLimit.setInputType(
                InputType.TYPE_CLASS_NUMBER
        );
        pageLimit.setText("50");
        pageLimit.setTextColor(TEXT);
        pageLimit.setGravity(Gravity.CENTER);
        pageLimit.setBackground(
                rounded(SURFACE, 10, BORDER, 1)
        );
        limitRow.addView(
                pageLimit,
                new LinearLayout.LayoutParams(
                        dp(88),
                        dp(46)
                )
        );

        settings.addView(
                limitRow,
                margins(-1, -2, 0, 8, 0, 0)
        );

        TextView modeNote = text(
                "Pro editing mode includes manual corner adjustment, "
                        + "crop, rotate, reorder, grayscale and enhancement "
                        + "filters, shadow removal, stain cleanup and "
                        + "finger removal.",
                12f,
                MUTED,
                Typeface.NORMAL
        );
        modeNote.setLineSpacing(0f, 1.16f);
        settings.addView(modeNote);

        root.addView(
                settings,
                margins(-1, -2, 0, 14, 0, 0)
        );

        LinearLayout historyHeading = new LinearLayout(this);
        historyHeading.setGravity(Gravity.CENTER_VERTICAL);

        historyHeading.addView(
                text(
                        "My Scans",
                        21f,
                        TEXT,
                        Typeface.BOLD
                ),
                new LinearLayout.LayoutParams(
                        0,
                        -2,
                        1f
                )
        );

        summaryLabel = text(
                "0 documents",
                12f,
                MUTED,
                Typeface.BOLD
        );
        historyHeading.addView(summaryLabel);

        root.addView(
                historyHeading,
                margins(-1, -2, 0, 20, 0, 10)
        );

        busyIndicator = new ProgressBar(this);
        busyIndicator.setVisibility(View.GONE);
        root.addView(busyIndicator);

        historyContainer = new LinearLayout(this);
        historyContainer.setOrientation(
                LinearLayout.VERTICAL
        );
        root.addView(historyContainer);

        TextView support = text(
                "The first scan may briefly download the document-scanner "
                        + "module through Google Play services. Scanning and "
                        + "editing are processed on the device.",
                11f,
                MUTED,
                Typeface.NORMAL
        );
        support.setLineSpacing(0f, 1.16f);
        root.addView(
                support,
                margins(-1, -2, 0, 18, 0, 0)
        );
    }

    private void startScanner() {
        int limit = 50;

        try {
            limit = Integer.parseInt(
                    pageLimit.getText()
                            .toString()
                            .trim()
            );
        } catch (Exception ignored) {
        }

        limit = Math.max(1, Math.min(100, limit));

        GmsDocumentScannerOptions options =
                new GmsDocumentScannerOptions.Builder()
                        .setGalleryImportAllowed(
                                galleryImport.isChecked()
                        )
                        .setPageLimit(limit)
                        .setResultFormats(
                                GmsDocumentScannerOptions
                                        .RESULT_FORMAT_JPEG,
                                GmsDocumentScannerOptions
                                        .RESULT_FORMAT_PDF
                        )
                        .setScannerMode(
                                GmsDocumentScannerOptions
                                        .SCANNER_MODE_FULL
                        )
                        .build();

        GmsDocumentScanner scanner =
                GmsDocumentScanning.getClient(options);

        busyIndicator.setVisibility(View.VISIBLE);

        scanner.getStartScanIntent(this)
                .addOnSuccessListener(
                        intentSender -> {
                            busyIndicator.setVisibility(View.GONE);

                            scannerLauncher.launch(
                                    new IntentSenderRequest.Builder(
                                            intentSender
                                    ).build()
                            );
                        }
                )
                .addOnFailureListener(
                        error -> {
                            busyIndicator.setVisibility(View.GONE);
                            showError(
                                    "Scanner unavailable",
                                    error.getMessage()
                            );
                        }
                );
    }

    private void saveScanResult(
            GmsDocumentScanningResult result
    ) {
        if (result.getPdf() == null) {
            showError(
                    "Scan failed",
                    "The scanner did not return a PDF."
            );
            return;
        }

        busyIndicator.setVisibility(View.VISIBLE);

        executor.execute(
                () -> {
                    try {
                        String id = String.valueOf(
                                System.currentTimeMillis()
                        );

                        File folder =
                                repository.createScanFolder(id);

                        File pdf = new File(
                                folder,
                                "document.pdf"
                        );

                        FileTools.copyUriToFile(
                                getContentResolver(),
                                result.getPdf().getUri(),
                                pdf
                        );

                        List<String> imagePaths =
                                new ArrayList<>();

                        List<GmsDocumentScanningResult.Page> pages =
                                result.getPages();

                        for (
                                int index = 0;
                                index < pages.size();
                                index++
                        ) {
                            File image = new File(
                                    folder,
                                    String.format(
                                            Locale.US,
                                            "page-%03d.jpg",
                                            index + 1
                                    )
                            );

                            FileTools.copyUriToFile(
                                    getContentResolver(),
                                    pages.get(index).getImageUri(),
                                    image
                            );

                            imagePaths.add(
                                    image.getAbsolutePath()
                            );
                        }

                        int pageCount =
                                result.getPdf().getPageCount();

                        ScanItem item = new ScanItem(
                                id,
                                "Scan "
                                        + DateFormat
                                        .getDateTimeInstance(
                                                DateFormat.MEDIUM,
                                                DateFormat.SHORT
                                        )
                                        .format(new Date()),
                                System.currentTimeMillis(),
                                pageCount,
                                pdf.getAbsolutePath(),
                                imagePaths,
                                ""
                        );

                        repository.add(item);

                        runOnUiThread(
                                () -> {
                                    busyIndicator.setVisibility(
                                            View.GONE
                                    );
                                    toast(
                                            "Saved "
                                                    + pageCount
                                                    + " page(s)."
                                    );
                                    refreshHistory();
                                    openScan(item);
                                }
                        );
                    } catch (Exception error) {
                        runOnUiThread(
                                () -> {
                                    busyIndicator.setVisibility(
                                            View.GONE
                                    );
                                    showError(
                                            "Could not save scan",
                                            error.getMessage()
                                    );
                                }
                        );
                    }
                }
        );
    }

    private void refreshHistory() {
        scans = repository.loadAll();
        historyContainer.removeAllViews();

        summaryLabel.setText(
                scans.size()
                        + (scans.size() == 1
                        ? " document"
                        : " documents")
        );

        if (scans.isEmpty()) {
            LinearLayout empty = card();
            empty.setGravity(Gravity.CENTER);

            TextView title = text(
                    "No scanned documents yet",
                    17f,
                    TEXT,
                    Typeface.BOLD
            );
            title.setGravity(Gravity.CENTER);
            empty.addView(title);

            TextView detail = text(
                    "Press Scan New Document to create your first PDF.",
                    13f,
                    MUTED,
                    Typeface.NORMAL
            );
            detail.setGravity(Gravity.CENTER);
            empty.addView(detail);

            historyContainer.addView(empty);
            return;
        }

        for (int index = 0; index < scans.size(); index++) {
            historyContainer.addView(
                    scanCard(scans.get(index)),
                    margins(
                            -1,
                            -2,
                            0,
                            index == 0 ? 0 : 11,
                            0,
                            0
                    )
            );
        }
    }

    private View scanCard(ScanItem item) {
        LinearLayout card = card();

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);

        ImageView thumbnail = new ImageView(this);
        thumbnail.setScaleType(
                ImageView.ScaleType.CENTER_CROP
        );
        thumbnail.setBackgroundColor(
                Color.rgb(31, 46, 42)
        );

        if (!item.imagePaths.isEmpty()) {
            Bitmap preview = decodeThumbnail(
                    item.imagePaths.get(0)
            );
            if (preview != null) {
                thumbnail.setImageBitmap(preview);
            }
        }

        top.addView(
                thumbnail,
                new LinearLayout.LayoutParams(
                        dp(76),
                        dp(96)
                )
        );

        LinearLayout details = new LinearLayout(this);
        details.setOrientation(LinearLayout.VERTICAL);

        details.addView(
                text(
                        item.title,
                        17f,
                        TEXT,
                        Typeface.BOLD
                )
        );

        details.addView(
                text(
                        item.pageCount
                                + (item.pageCount == 1
                                ? " page"
                                : " pages")
                                + "  •  "
                                + FileTools.humanFileSize(
                                        new File(
                                                item.pdfPath
                                        ).length()
                                ),
                        12f,
                        MUTED,
                        Typeface.NORMAL
                )
        );

        details.addView(
                text(
                        DateFormat.getDateTimeInstance(
                                DateFormat.MEDIUM,
                                DateFormat.SHORT
                        ).format(
                                new Date(item.createdAt)
                        ),
                        12f,
                        MUTED,
                        Typeface.NORMAL
                )
        );

        if (!item.ocrTextPath.isEmpty()) {
            details.addView(
                    text(
                            "OCR text ready",
                            11f,
                            ACCENT,
                            Typeface.BOLD
                    ),
                    margins(-1, -2, 0, 5, 0, 0)
            );
        }

        LinearLayout.LayoutParams detailParams =
                margins(0, -2, 14, 0, 0, 0);
        detailParams.weight = 1f;
        top.addView(details, detailParams);

        TextView pageBadge = badge(
                String.valueOf(item.pageCount),
                BLUE,
                Color.WHITE
        );
        top.addView(pageBadge);

        card.addView(top);

        LinearLayout firstActions = new LinearLayout(this);

        Button open = smallButton(
                "Open PDF",
                ACCENT,
                BG
        );
        open.setOnClickListener(
                view -> openScan(item)
        );
        firstActions.addView(
                open,
                weightedButton()
        );

        Button share = smallButton(
                "Share",
                BLUE,
                Color.WHITE
        );
        share.setOnClickListener(
                view -> sharePdf(item)
        );
        firstActions.addView(
                share,
                weightedButtonMargin()
        );

        Button export = smallButton(
                "Export",
                CARD,
                TEXT
        );
        export.setOnClickListener(
                view -> exportPdf(item)
        );
        firstActions.addView(
                export,
                weightedButtonMargin()
        );

        card.addView(
                firstActions,
                margins(-1, -2, 0, 13, 0, 0)
        );

        LinearLayout secondActions = new LinearLayout(this);

        Button ocr = smallButton(
                item.ocrTextPath.isEmpty()
                        ? "Extract Text"
                        : "View Text",
                ORANGE,
                BG
        );
        ocr.setOnClickListener(
                view -> {
                    if (item.ocrTextPath.isEmpty()) {
                        extractText(item);
                    } else {
                        viewText(item);
                    }
                }
        );
        secondActions.addView(
                ocr,
                weightedButton()
        );

        Button images = smallButton(
                "Export Images",
                CARD,
                TEXT
        );
        images.setOnClickListener(
                view -> exportImages(item)
        );
        secondActions.addView(
                images,
                weightedButtonMargin()
        );

        Button more = smallButton(
                "More",
                CARD,
                TEXT
        );
        more.setOnClickListener(
                view -> showMore(item)
        );
        secondActions.addView(
                more,
                weightedButtonMargin()
        );

        card.addView(
                secondActions,
                margins(-1, -2, 0, 8, 0, 0)
        );

        return card;
    }

    private void openScan(ScanItem item) {
        Intent viewer = new Intent(
                this,
                PdfViewerActivity.class
        );
        viewer.putExtra(
                PdfViewerActivity.EXTRA_PDF_PATH,
                item.pdfPath
        );
        viewer.putExtra(
                PdfViewerActivity.EXTRA_TITLE,
                item.title
        );
        startActivity(viewer);
    }

    private void sharePdf(ScanItem item) {
        File file = new File(item.pdfPath);

        Uri uri = FileProvider.getUriForFile(
                this,
                getPackageName() + ".files",
                file
        );

        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("application/pdf");
        share.putExtra(Intent.EXTRA_STREAM, uri);
        share.putExtra(Intent.EXTRA_SUBJECT, item.title);
        share.addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION
        );

        startActivity(
                Intent.createChooser(
                        share,
                        "Share scanned PDF"
                )
        );
    }

    private void exportPdf(ScanItem item) {
        beginExport(
                new File(item.pdfPath),
                "application/pdf",
                safeName(item.title) + ".pdf"
        );
    }

    private void exportImages(ScanItem item) {
        ProgressDialog progress = ProgressDialog.show(
                this,
                "Preparing images",
                "Creating image ZIP…",
                true,
                false
        );

        executor.execute(
                () -> {
                    try {
                        File folder = new File(
                                getFilesDir(),
                                "scans/" + item.id
                        );

                        File zip = new File(
                                folder,
                                "page-images.zip"
                        );

                        FileTools.zipImages(
                                item.imagePaths,
                                zip
                        );

                        runOnUiThread(
                                () -> {
                                    progress.dismiss();
                                    beginExport(
                                            zip,
                                            "application/zip",
                                            safeName(item.title)
                                                    + "-images.zip"
                                    );
                                }
                        );
                    } catch (Exception error) {
                        runOnUiThread(
                                () -> {
                                    progress.dismiss();
                                    showError(
                                            "Could not export images",
                                            error.getMessage()
                                    );
                                }
                        );
                    }
                }
        );
    }

    private void beginExport(
            File file,
            String mime,
            String name
    ) {
        pendingExportFile = file;
        pendingExportMime = mime;
        pendingExportName = name;

        Intent save = new Intent(
                Intent.ACTION_CREATE_DOCUMENT
        );
        save.addCategory(Intent.CATEGORY_OPENABLE);
        save.setType(mime);
        save.putExtra(
                Intent.EXTRA_TITLE,
                name
        );

        startActivityForResult(
                save,
                EXPORT_FILE_REQUEST
        );
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data
    ) {
        super.onActivityResult(
                requestCode,
                resultCode,
                data
        );

        if (
                requestCode != EXPORT_FILE_REQUEST
                        || resultCode != RESULT_OK
                        || data == null
                        || data.getData() == null
                        || pendingExportFile == null
        ) {
            return;
        }

        Uri destination = data.getData();
        File source = pendingExportFile;

        ProgressDialog progress = ProgressDialog.show(
                this,
                "Exporting",
                "Saving " + pendingExportName + "…",
                true,
                false
        );

        executor.execute(
                () -> {
                    try {
                        FileTools.copyFileToUri(
                                getContentResolver(),
                                source,
                                destination
                        );

                        runOnUiThread(
                                () -> {
                                    progress.dismiss();
                                    toast("Export completed.");
                                }
                        );
                    } catch (Exception error) {
                        runOnUiThread(
                                () -> {
                                    progress.dismiss();
                                    showError(
                                            "Export failed",
                                            error.getMessage()
                                    );
                                }
                        );
                    }
                }
        );
    }

    private void extractText(ScanItem item) {
        ProgressDialog progress = new ProgressDialog(this);
        progress.setTitle("OCR Text Recognition");
        progress.setMessage("Preparing pages…");
        progress.setCancelable(false);
        progress.show();

        OcrEngine.recognize(
                this,
                item,
                new OcrEngine.Callback() {
                    @Override
                    public void onProgress(
                            int current,
                            int total
                    ) {
                        runOnUiThread(
                                () -> progress.setMessage(
                                        "Reading page "
                                                + current
                                                + " of "
                                                + total
                                                + "…"
                                )
                        );
                    }

                    @Override
                    public void onSuccess(
                            File textFile,
                            String text
                    ) {
                        runOnUiThread(
                                () -> {
                                    progress.dismiss();
                                    item.ocrTextPath =
                                            textFile.getAbsolutePath();

                                    executor.execute(
                                            () -> {
                                                try {
                                                    repository.update(
                                                            item
                                                    );
                                                } catch (
                                                        Exception ignored
                                                ) {
                                                }
                                            }
                                    );

                                    refreshHistory();
                                    showTextDialog(
                                            item,
                                            text
                                    );
                                }
                        );
                    }

                    @Override
                    public void onFailure(Exception error) {
                        runOnUiThread(
                                () -> {
                                    progress.dismiss();
                                    showError(
                                            "Text recognition failed",
                                            error.getMessage()
                                    );
                                }
                        );
                    }
                }
        );
    }

    private void viewText(ScanItem item) {
        executor.execute(
                () -> {
                    try {
                        StringBuilder content = new StringBuilder();

                        try (
                                BufferedReader reader = new BufferedReader(
                                        new InputStreamReader(
                                                new FileInputStream(
                                                        item.ocrTextPath
                                                ),
                                                StandardCharsets.UTF_8
                                        )
                                )
                        ) {
                            String line;

                            while ((line = reader.readLine()) != null) {
                                content.append(line).append("\n");
                            }
                        }

                        String text = content.toString().trim();

                        runOnUiThread(
                                () -> showTextDialog(
                                        item,
                                        text
                                )
                        );
                    } catch (Exception error) {
                        runOnUiThread(
                                () -> showError(
                                        "Could not open text",
                                        error.getMessage()
                                )
                        );
                    }
                }
        );
    }

    private void showTextDialog(
            ScanItem item,
            String recognizedText
    ) {
        EditText textView = new EditText(this);
        textView.setText(recognizedText);
        textView.setTextIsSelectable(true);
        textView.setTextColor(TEXT);
        textView.setBackgroundColor(SURFACE);
        textView.setPadding(
                dp(14),
                dp(14),
                dp(14),
                dp(14)
        );
        textView.setMinLines(15);
        textView.setGravity(Gravity.TOP);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Recognized Text")
                .setView(textView)
                .setPositiveButton(
                        "Copy",
                        (value, which) -> {
                            ClipboardManager clipboard =
                                    (ClipboardManager)
                                            getSystemService(
                                                    Context.CLIPBOARD_SERVICE
                                            );

                            clipboard.setPrimaryClip(
                                    ClipData.newPlainText(
                                            item.title,
                                            textView.getText()
                                                    .toString()
                                    )
                            );
                            toast("Text copied.");
                        }
                )
                .setNeutralButton(
                        "Export TXT",
                        (value, which) -> beginExport(
                                new File(item.ocrTextPath),
                                "text/plain",
                                safeName(item.title) + ".txt"
                        )
                )
                .setNegativeButton("Close", null)
                .create();

        dialog.show();
    }

    private void showMore(ScanItem item) {
        String[] options = {
                "Rename document",
                "Delete document"
        };

        new AlertDialog.Builder(this)
                .setTitle(item.title)
                .setItems(
                        options,
                        (dialog, index) -> {
                            if (index == 0) {
                                rename(item);
                            } else {
                                confirmDelete(item);
                            }
                        }
                )
                .show();
    }

    private void rename(ScanItem item) {
        EditText input = new EditText(this);
        input.setText(item.title);
        input.setSelection(
                input.getText().length()
        );

        new AlertDialog.Builder(this)
                .setTitle("Rename Document")
                .setView(input)
                .setPositiveButton(
                        "Save",
                        (dialog, which) -> {
                            String title = input.getText()
                                    .toString()
                                    .trim();

                            if (title.isEmpty()) {
                                return;
                            }

                            item.title = title;

                            executor.execute(
                                    () -> {
                                        try {
                                            repository.update(item);
                                            runOnUiThread(
                                                    this::refreshHistory
                                            );
                                        } catch (Exception error) {
                                            runOnUiThread(
                                                    () -> showError(
                                                            "Rename failed",
                                                            error.getMessage()
                                                    )
                                            );
                                        }
                                    }
                            );
                        }
                )
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void confirmDelete(ScanItem item) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Document?")
                .setMessage(
                        "This permanently removes the PDF, page images "
                                + "and recognized text from the app."
                )
                .setPositiveButton(
                        "Delete",
                        (dialog, which) -> executor.execute(
                                () -> {
                                    try {
                                        repository.delete(item);
                                        runOnUiThread(
                                                () -> {
                                                    toast(
                                                            "Document deleted."
                                                    );
                                                    refreshHistory();
                                                }
                                        );
                                    } catch (Exception error) {
                                        runOnUiThread(
                                                () -> showError(
                                                        "Delete failed",
                                                        error.getMessage()
                                                )
                                        );
                                    }
                                }
                        )
                )
                .setNegativeButton("Cancel", null)
                .show();
    }

    private Bitmap decodeThumbnail(String path) {
        BitmapFactory.Options bounds =
                new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, bounds);

        int sample = 1;

        while (
                bounds.outWidth / sample > 300
                        || bounds.outHeight / sample > 400
        ) {
            sample *= 2;
        }

        BitmapFactory.Options options =
                new BitmapFactory.Options();
        options.inSampleSize = sample;
        return BitmapFactory.decodeFile(
                path,
                options
        );
    }

    private LinearLayout miniFeature(
            String label,
            String description,
            int accent
    ) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(
                dp(8),
                dp(12),
                dp(8),
                dp(12)
        );
        box.setBackground(
                rounded(CARD, 16, BORDER, 1)
        );

        TextView title = text(
                label,
                13f,
                accent,
                Typeface.BOLD
        );
        title.setGravity(Gravity.CENTER);
        box.addView(title);

        TextView detail = text(
                description,
                10f,
                MUTED,
                Typeface.NORMAL
        );
        detail.setGravity(Gravity.CENTER);
        box.addView(detail);

        return box;
    }

    private LinearLayout card() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(
                dp(15),
                dp(15),
                dp(15),
                dp(15)
        );
        card.setBackground(
                rounded(CARD, 20, BORDER, 1)
        );
        return card;
    }

    private Button button(
            String label,
            int background,
            int foreground
    ) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTypeface(
                Typeface.DEFAULT_BOLD
        );
        button.setTextColor(foreground);
        button.setBackground(
                rounded(background, 13, 0, 0)
        );
        return button;
    }

    private Button smallButton(
            String label,
            int background,
            int foreground
    ) {
        Button button = button(
                label,
                background,
                foreground
        );
        button.setTextSize(11f);
        button.setMinHeight(0);
        button.setMinimumHeight(dp(43));
        button.setPadding(
                dp(8),
                0,
                dp(8),
                0
        );
        return button;
    }

    private TextView text(
            String value,
            float size,
            int color,
            int style
    ) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setTypeface(
                Typeface.create("sans", style)
        );
        return view;
    }

    private TextView badge(
            String value,
            int background,
            int foreground
    ) {
        TextView badge = text(
                value,
                10f,
                foreground,
                Typeface.BOLD
        );
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(
                dp(10),
                dp(6),
                dp(10),
                dp(6)
        );
        badge.setBackground(
                rounded(background, 14, 0, 0)
        );
        return badge;
    }

    private GradientDrawable rounded(
            int color,
            int radius,
            int strokeColor,
            int strokeWidth
    ) {
        GradientDrawable drawable =
                new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));

        if (strokeWidth > 0) {
            drawable.setStroke(
                    dp(strokeWidth),
                    strokeColor
            );
        }

        return drawable;
    }

    private LinearLayout.LayoutParams margins(
            int width,
            int height,
            int left,
            int top,
            int right,
            int bottom
    ) {
        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        width,
                        height
                );

        params.setMargins(
                dp(left),
                dp(top),
                dp(right),
                dp(bottom)
        );

        return params;
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(
                0,
                -2,
                1f
        );
    }

    private LinearLayout.LayoutParams weightedMargin() {
        LinearLayout.LayoutParams params =
                weighted();
        params.setMargins(dp(7), 0, 0, 0);
        return params;
    }

    private LinearLayout.LayoutParams weightedButton() {
        return new LinearLayout.LayoutParams(
                0,
                dp(43),
                1f
        );
    }

    private LinearLayout.LayoutParams weightedButtonMargin() {
        LinearLayout.LayoutParams params =
                weightedButton();
        params.setMargins(dp(7), 0, 0, 0);
        return params;
    }

    private String safeName(String value) {
        String clean = value.replaceAll(
                "[\\\\/:*?\"<>|]",
                "-"
        ).trim();

        return clean.isEmpty()
                ? "Scanned Document"
                : clean;
    }

    private void showError(
            String title,
            String message
    ) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(
                        message == null || message.isEmpty()
                                ? "An unexpected error occurred."
                                : message
                )
                .setPositiveButton("OK", null)
                .show();
    }

    private void toast(String message) {
        Toast.makeText(
                this,
                message,
                Toast.LENGTH_SHORT
        ).show();
    }

    private int dp(int value) {
        return Math.round(
                value
                        * getResources()
                        .getDisplayMetrics()
                        .density
        );
    }
}
