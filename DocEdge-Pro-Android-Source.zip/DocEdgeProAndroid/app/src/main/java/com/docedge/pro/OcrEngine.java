package com.docedge.pro;

import android.content.Context;
import android.net.Uri;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.List;

final class OcrEngine {
    interface Callback {
        void onProgress(int current, int total);
        void onSuccess(File textFile, String text);
        void onFailure(Exception error);
    }

    private OcrEngine() {
    }

    static void recognize(
            Context context,
            ScanItem item,
            Callback callback
    ) {
        if (item.imagePaths.isEmpty()) {
            callback.onFailure(
                    new IllegalStateException(
                            "No page images are available for OCR."
                    )
            );
            return;
        }

        TextRecognizer recognizer =
                TextRecognition.getClient(
                        TextRecognizerOptions.DEFAULT_OPTIONS
                );

        processPage(
                context,
                item,
                recognizer,
                0,
                new StringBuilder(),
                callback
        );
    }

    private static void processPage(
            Context context,
            ScanItem item,
            TextRecognizer recognizer,
            int index,
            StringBuilder output,
            Callback callback
    ) {
        List<String> paths = item.imagePaths;

        if (index >= paths.size()) {
            recognizer.close();

            try {
                File scanFolder = new File(
                        context.getFilesDir(),
                        "scans/" + item.id
                );

                File textFile = new File(
                        scanFolder,
                        "recognized-text.txt"
                );

                try (
                        BufferedWriter writer =
                                new BufferedWriter(
                                        new OutputStreamWriter(
                                                new FileOutputStream(
                                                        textFile
                                                ),
                                                StandardCharsets.UTF_8
                                        )
                                )
                ) {
                    writer.write(
                            output.toString().trim()
                    );
                }

                callback.onSuccess(
                        textFile,
                        output.toString().trim()
                );
            } catch (Exception error) {
                callback.onFailure(error);
            }

            return;
        }

        callback.onProgress(
                index + 1,
                paths.size()
        );

        try {
            InputImage image =
                    InputImage.fromFilePath(
                            context,
                            Uri.fromFile(
                                    new File(
                                            paths.get(index)
                                    )
                            )
                    );

            recognizer.process(image)
                    .addOnSuccessListener(
                            text -> {
                                appendPageText(
                                        output,
                                        index,
                                        text
                                );

                                processPage(
                                        context,
                                        item,
                                        recognizer,
                                        index + 1,
                                        output,
                                        callback
                                );
                            }
                    )
                    .addOnFailureListener(
                            error -> {
                                recognizer.close();
                                callback.onFailure(error);
                            }
                    );
        } catch (Exception error) {
            recognizer.close();
            callback.onFailure(error);
        }
    }

    private static void appendPageText(
            StringBuilder output,
            int pageIndex,
            Text text
    ) {
        if (output.length() > 0) {
            output.append("\n\n");
        }

        output.append("===== PAGE ")
                .append(pageIndex + 1)
                .append(" =====\n");

        String pageText = text.getText();

        if (
                pageText == null
                        || pageText.trim().isEmpty()
        ) {
            output.append("[No text detected]");
        } else {
            output.append(pageText.trim());
        }
    }
}
