package com.docedge.pro;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

final class ScanRepository {
    private static final String INDEX_FILE = "scan_index.json";

    private final File storageRoot;
    private final File indexFile;

    ScanRepository(Context context) {
        storageRoot = new File(context.getFilesDir(), "scans");

        if (!storageRoot.exists()) {
            storageRoot.mkdirs();
        }

        indexFile = new File(storageRoot, INDEX_FILE);
    }

    synchronized List<ScanItem> loadAll() {
        List<ScanItem> items = new ArrayList<>();

        if (!indexFile.exists()) {
            return items;
        }

        try {
            StringBuilder json = new StringBuilder();

            try (
                    BufferedReader reader = new BufferedReader(
                            new InputStreamReader(
                                    new FileInputStream(indexFile),
                                    StandardCharsets.UTF_8
                            )
                    )
            ) {
                String line;

                while ((line = reader.readLine()) != null) {
                    json.append(line);
                }
            }

            JSONArray array = new JSONArray(
                    json.toString()
            );

            for (int index = 0; index < array.length(); index++) {
                JSONObject object =
                        array.optJSONObject(index);

                if (object == null) {
                    continue;
                }

                ScanItem item = ScanItem.fromJson(object);

                if (
                        !item.id.isEmpty()
                                && new File(
                                        item.pdfPath
                                ).exists()
                ) {
                    items.add(item);
                }
            }
        } catch (Exception ignored) {
        }

        Collections.sort(
                items,
                new Comparator<ScanItem>() {
                    @Override
                    public int compare(
                            ScanItem left,
                            ScanItem right
                    ) {
                        return Long.compare(
                                right.createdAt,
                                left.createdAt
                        );
                    }
                }
        );

        return items;
    }

    synchronized void saveAll(
            List<ScanItem> items
    ) throws Exception {
        JSONArray array = new JSONArray();

        for (ScanItem item : items) {
            array.put(item.toJson());
        }

        try (
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(
                                new FileOutputStream(indexFile),
                                StandardCharsets.UTF_8
                        )
                )
        ) {
            writer.write(array.toString(2));
        }
    }

    synchronized void add(ScanItem item) throws Exception {
        List<ScanItem> items = loadAll();
        items.add(0, item);
        saveAll(items);
    }

    synchronized void update(
            ScanItem updated
    ) throws Exception {
        List<ScanItem> items = loadAll();

        for (int index = 0; index < items.size(); index++) {
            if (items.get(index).id.equals(updated.id)) {
                items.set(index, updated);
                saveAll(items);
                return;
            }
        }

        items.add(0, updated);
        saveAll(items);
    }

    synchronized void delete(
            ScanItem target
    ) throws Exception {
        List<ScanItem> items = loadAll();
        List<ScanItem> kept = new ArrayList<>();

        for (ScanItem item : items) {
            if (!item.id.equals(target.id)) {
                kept.add(item);
            }
        }

        deleteRecursively(
                new File(storageRoot, target.id)
        );
        saveAll(kept);
    }

    File createScanFolder(String id) {
        File folder = new File(storageRoot, id);

        if (!folder.exists()) {
            folder.mkdirs();
        }

        return folder;
    }

    private void deleteRecursively(File file) {
        if (file == null || !file.exists()) {
            return;
        }

        File[] children = file.listFiles();

        if (children != null) {
            for (File child : children) {
                deleteRecursively(child);
            }
        }

        file.delete();
    }
}
