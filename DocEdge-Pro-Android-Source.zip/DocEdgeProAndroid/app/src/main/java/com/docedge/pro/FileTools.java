package com.docedge.pro;

import android.content.ContentResolver;
import android.net.Uri;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

final class FileTools {
    private FileTools() {
    }

    static void copyUriToFile(
            ContentResolver resolver,
            Uri source,
            File destination
    ) throws Exception {
        InputStream opened = resolver.openInputStream(source);

        if (opened == null) {
            throw new IllegalStateException(
                    "The scanned file could not be opened."
            );
        }

        try (
                InputStream input = new BufferedInputStream(opened);
                OutputStream output = new BufferedOutputStream(
                        new FileOutputStream(destination)
                )
        ) {
            copy(input, output);
        }
    }

    static void copyFileToUri(
            ContentResolver resolver,
            File source,
            Uri destination
    ) throws Exception {
        OutputStream opened = resolver.openOutputStream(
                destination,
                "w"
        );

        if (opened == null) {
            throw new IllegalStateException(
                    "The selected destination could not be opened."
            );
        }

        try (
                InputStream input = new BufferedInputStream(
                        new FileInputStream(source)
                );
                OutputStream output = new BufferedOutputStream(opened)
        ) {
            copy(input, output);
        }
    }

    static void zipImages(
            List<String> imagePaths,
            File destination
    ) throws Exception {
        try (
                ZipOutputStream zip = new ZipOutputStream(
                        new BufferedOutputStream(
                                new FileOutputStream(destination)
                        )
                )
        ) {
            byte[] buffer = new byte[64 * 1024];

            for (int index = 0; index < imagePaths.size(); index++) {
                File source = new File(imagePaths.get(index));

                if (!source.exists()) {
                    continue;
                }

                ZipEntry entry = new ZipEntry(
                        String.format(
                                java.util.Locale.US,
                                "page-%03d.jpg",
                                index + 1
                        )
                );

                zip.putNextEntry(entry);

                try (
                        InputStream input = new BufferedInputStream(
                                new FileInputStream(source)
                        )
                ) {
                    int count;

                    while ((count = input.read(buffer)) >= 0) {
                        zip.write(buffer, 0, count);
                    }
                }

                zip.closeEntry();
            }
        }
    }

    static String humanFileSize(long bytes) {
        if (bytes < 1024L) {
            return bytes + " B";
        }

        double kilobytes = bytes / 1024.0;

        if (kilobytes < 1024.0) {
            return String.format(
                    java.util.Locale.US,
                    "%.1f KB",
                    kilobytes
            );
        }

        double megabytes = kilobytes / 1024.0;

        return String.format(
                java.util.Locale.US,
                "%.1f MB",
                megabytes
        );
    }

    private static void copy(
            InputStream input,
            OutputStream output
    ) throws Exception {
        byte[] buffer = new byte[64 * 1024];
        int count;

        while ((count = input.read(buffer)) >= 0) {
            output.write(buffer, 0, count);
        }
    }
}
