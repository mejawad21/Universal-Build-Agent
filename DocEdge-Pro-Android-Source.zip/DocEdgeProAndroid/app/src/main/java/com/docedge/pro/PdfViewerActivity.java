package com.docedge.pro;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfRenderer;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

public final class PdfViewerActivity extends AppCompatActivity {
    public static final String EXTRA_PDF_PATH = "pdf_path";
    public static final String EXTRA_TITLE = "title";

    private static final int BG = Color.rgb(7, 16, 15);
    private static final int SURFACE = Color.rgb(17, 31, 29);
    private static final int TEXT = Color.rgb(239, 249, 245);
    private static final int MUTED = Color.rgb(151, 169, 165);
    private static final int ACCENT = Color.rgb(70, 225, 154);

    private ParcelFileDescriptor descriptor;
    private PdfRenderer renderer;
    private PdfRenderer.Page currentPage;
    private Bitmap currentBitmap;

    private ImageView imageView;
    private TextView pageLabel;
    private int pageIndex;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(12), dp(12), dp(12), dp(18));

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);

        Button close = button("Close");
        close.setOnClickListener(view -> finish());
        toolbar.addView(close);

        TextView title = text(
                getIntent().getStringExtra(EXTRA_TITLE),
                17f,
                TEXT,
                Typeface.BOLD
        );
        toolbar.addView(
                title,
                new LinearLayout.LayoutParams(
                        0,
                        -2,
                        1f
                )
        );

        root.addView(toolbar);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        imageView = new ImageView(this);
        imageView.setAdjustViewBounds(true);
        imageView.setScaleType(
                ImageView.ScaleType.FIT_CENTER
        );
        imageView.setBackgroundColor(
                Color.rgb(28, 35, 34)
        );

        scroll.addView(
                imageView,
                new ScrollView.LayoutParams(
                        -1,
                        -2
                )
        );

        root.addView(
                scroll,
                new LinearLayout.LayoutParams(
                        -1,
                        0,
                        1f
                )
        );

        LinearLayout navigation = new LinearLayout(this);
        navigation.setGravity(Gravity.CENTER);

        Button previous = button("Previous");
        previous.setOnClickListener(
                view -> showPage(pageIndex - 1)
        );

        pageLabel = text(
                "0 / 0",
                14f,
                TEXT,
                Typeface.BOLD
        );
        pageLabel.setGravity(Gravity.CENTER);

        Button next = button("Next");
        next.setOnClickListener(
                view -> showPage(pageIndex + 1)
        );

        navigation.addView(previous);
        navigation.addView(
                pageLabel,
                new LinearLayout.LayoutParams(
                        0,
                        dp(48),
                        1f
                )
        );
        navigation.addView(next);

        root.addView(navigation);

        setContentView(root);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            root.setOnApplyWindowInsetsListener(
                    new View.OnApplyWindowInsetsListener() {
                        @Override
                        public WindowInsets onApplyWindowInsets(
                                View view,
                                WindowInsets insets
                        ) {
                            android.graphics.Insets bars =
                                    insets.getInsets(
                                            WindowInsets.Type.systemBars()
                                    );

                            root.setPadding(
                                    dp(12) + bars.left,
                                    dp(12) + bars.top,
                                    dp(12) + bars.right,
                                    dp(18) + bars.bottom
                            );

                            return insets;
                        }
                    }
            );
        }

        openPdf();
    }

    private void openPdf() {
        String value = getIntent().getStringExtra(
                EXTRA_PDF_PATH
        );

        if (value == null || value.isEmpty()) {
            finish();
            return;
        }

        try {
            descriptor = ParcelFileDescriptor.open(
                    new File(value),
                    ParcelFileDescriptor.MODE_READ_ONLY
            );

            renderer = new PdfRenderer(descriptor);
            showPage(0);
        } catch (Exception error) {
            Toast.makeText(
                    this,
                    error.getMessage(),
                    Toast.LENGTH_LONG
            ).show();
            finish();
        }
    }

    private void showPage(int requestedPage) {
        if (renderer == null || renderer.getPageCount() == 0) {
            return;
        }

        pageIndex = Math.max(
                0,
                Math.min(
                        requestedPage,
                        renderer.getPageCount() - 1
                )
        );

        closePage();

        currentPage = renderer.openPage(pageIndex);

        int width = Math.max(
                1,
                getResources()
                        .getDisplayMetrics()
                        .widthPixels - dp(24)
        );

        float scale = width
                / (float) currentPage.getWidth();

        int height = Math.max(
                1,
                Math.round(
                        currentPage.getHeight() * scale
                )
        );

        currentBitmap = Bitmap.createBitmap(
                width,
                height,
                Bitmap.Config.ARGB_8888
        );
        currentBitmap.eraseColor(Color.WHITE);

        currentPage.render(
                currentBitmap,
                null,
                null,
                PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY
        );

        imageView.setImageBitmap(currentBitmap);

        pageLabel.setText(
                (pageIndex + 1)
                        + " / "
                        + renderer.getPageCount()
        );
    }

    private void closePage() {
        imageView.setImageDrawable(null);

        if (currentPage != null) {
            currentPage.close();
            currentPage = null;
        }

        if (currentBitmap != null) {
            currentBitmap.recycle();
            currentBitmap = null;
        }
    }

    @Override
    protected void onDestroy() {
        closePage();

        try {
            if (renderer != null) {
                renderer.close();
            }
            if (descriptor != null) {
                descriptor.close();
            }
        } catch (Exception ignored) {
        }

        super.onDestroy();
    }

    private Button button(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextColor(TEXT);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setBackground(
                rounded(SURFACE, 11)
        );
        return button;
    }

    private TextView text(
            String value,
            float size,
            int color,
            int style
    ) {
        TextView view = new TextView(this);
        view.setText(value == null ? "Document" : value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setTypeface(
                Typeface.create("sans", style)
        );
        view.setPadding(dp(12), 0, dp(12), 0);
        return view;
    }

    private GradientDrawable rounded(
            int color,
            int radius
    ) {
        GradientDrawable drawable =
                new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }

    private int dp(int value) {
        return Math.round(
                value
                        * getResources()
                        .getDisplayMetrics()
                        .density
        );
    }
}
