package com.docedge.pro;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

final class ScanItem {
    final String id;
    String title;
    final long createdAt;
    final int pageCount;
    final String pdfPath;
    final List<String> imagePaths;
    String ocrTextPath;

    ScanItem(
            String id,
            String title,
            long createdAt,
            int pageCount,
            String pdfPath,
            List<String> imagePaths,
            String ocrTextPath
    ) {
        this.id = id;
        this.title = title;
        this.createdAt = createdAt;
        this.pageCount = pageCount;
        this.pdfPath = pdfPath;
        this.imagePaths = imagePaths;
        this.ocrTextPath = ocrTextPath == null
                ? ""
                : ocrTextPath;
    }

    JSONObject toJson() throws JSONException {
        JSONObject object = new JSONObject();
        object.put("id", id);
        object.put("title", title);
        object.put("createdAt", createdAt);
        object.put("pageCount", pageCount);
        object.put("pdfPath", pdfPath);
        object.put("ocrTextPath", ocrTextPath);

        JSONArray images = new JSONArray();
        for (String path : imagePaths) {
            images.put(path);
        }
        object.put("imagePaths", images);
        return object;
    }

    static ScanItem fromJson(JSONObject object) {
        JSONArray images = object.optJSONArray("imagePaths");
        List<String> paths = new ArrayList<>();

        if (images != null) {
            for (int index = 0; index < images.length(); index++) {
                String path = images.optString(index, "");
                if (!path.isEmpty()) {
                    paths.add(path);
                }
            }
        }

        return new ScanItem(
                object.optString("id", ""),
                object.optString("title", "Untitled Scan"),
                object.optLong("createdAt", 0L),
                object.optInt("pageCount", paths.size()),
                object.optString("pdfPath", ""),
                paths,
                object.optString("ocrTextPath", "")
        );
    }
}
