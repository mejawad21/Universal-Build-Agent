# PDF Master Studio — Portable Windows Application

PDF Master Studio is a premium-style Windows desktop application for:

- Batch PDF to editable Word conversion.
- Batch Word to PDF conversion.
- Opening and reading PDFs.
- Searching text inside PDFs.
- Drawing a signature with the mouse, touchpad, or touchscreen.
- Importing a PNG/JPG signature.
- Dragging and resizing signatures directly on PDF pages.
- Applying signatures to selected pages or every page.
- Saving a separate signed PDF while preserving the original document.
- Running as a portable one-file EXE with no installer.

## Conversion engines

### Highest Fidelity — Microsoft Word

When Microsoft Word is already installed on the Windows computer, the
application can use Word's own PDF import and DOCX/PDF export engines. This is
the recommended option for the best editable layout.

Microsoft Word is not bundled and is not installed by this portable app.

### Portable Editable Engine

The bundled `pdf2docx` fallback converts PDF text, pictures, tables, and page
structure to an editable DOCX without requiring Microsoft Office.

### Word to PDF without Microsoft Word

Place LibreOffice Portable beside the EXE in this folder structure:

```text
LibreOfficePortable/
└── App/
    └── libreoffice/
        └── program/
            └── soffice.exe
```

The application also detects a normal LibreOffice installation.

## Important formatting truth

A PDF uses fixed page coordinates. Word uses flowing paragraphs, tables, and
sections. Therefore, no application can guarantee that every PDF becomes both
fully editable and pixel-identical in Word, especially for complex forms,
unusual fonts, multi-column designs, or scanned documents.

PDF Master Studio provides:

1. A Microsoft Word high-fidelity engine when Word is available.
2. A fully portable editable fallback when it is not.

It does not pretend that page screenshots are editable Word content.

## Building the portable EXE

The included GitHub Actions workflow builds:

```text
PDF Master Studio Portable.exe
```

The EXE is a one-file portable application. It does not use an installer.

You can also run `build_portable.bat` on Windows with Python 3.11 installed.

## Privacy

- No document upload code.
- Files are processed locally.
- No account or subscription system.
- Original documents are not overwritten by default.

## Digital-signature note

The app adds a visible electronic signature image to a PDF. It does not create
a certificate-based cryptographic digital signature.
