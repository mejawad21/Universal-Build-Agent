from __future__ import annotations

import sys

from PySide6.QtWidgets import QApplication

from pdfmaster.ui import MainWindow
from pdfmaster.theme import APPLICATION_STYLE


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("PDF Master Studio")
    app.setOrganizationName("Portable Document Tools")
    app.setStyleSheet(APPLICATION_STYLE)

    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
