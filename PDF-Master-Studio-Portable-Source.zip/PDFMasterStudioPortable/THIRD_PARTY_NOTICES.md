# Third-Party Components

This source project is designed to use:

- Qt for Python / PySide6
- PyMuPDF
- pdf2docx
- Pillow
- pywin32
- PyInstaller

Each component remains subject to its own license. Review the licenses before
commercial redistribution. Microsoft Word and LibreOffice are not bundled in
this source package.
