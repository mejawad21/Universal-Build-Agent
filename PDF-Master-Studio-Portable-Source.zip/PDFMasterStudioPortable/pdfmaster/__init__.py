"""PDF Master Studio portable desktop application."""

__version__ = "2.0.0"
