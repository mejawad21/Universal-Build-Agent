APPLICATION_STYLE = """
QWidget {
    background-color: #0b111b;
    color: #ecf3fb;
    font-family: "Segoe UI";
    font-size: 10pt;
}
QMainWindow, QDialog {
    background-color: #0b111b;
}
QFrame#Sidebar {
    background-color: #101827;
    border-right: 1px solid #263248;
}
QFrame#Card {
    background-color: #121c2b;
    border: 1px solid #27364d;
    border-radius: 14px;
}
QLabel#Title {
    font-size: 24pt;
    font-weight: 700;
}
QLabel#Heading {
    font-size: 14pt;
    font-weight: 700;
}
QLabel#Muted {
    color: #95a5ba;
}
QLabel#Accent {
    color: #62e6a7;
    font-weight: 700;
}
QPushButton {
    min-height: 36px;
    padding: 0 15px;
    border-radius: 9px;
    border: 1px solid #33445e;
    background-color: #172337;
    color: #eef5fd;
    font-weight: 600;
}
QPushButton:hover {
    background-color: #20304a;
}
QPushButton:pressed {
    background-color: #111a28;
}
QPushButton#Primary {
    background-color: #5d55f6;
    border-color: #716afa;
    color: white;
}
QPushButton#Primary:hover {
    background-color: #716afa;
}
QPushButton#Success {
    background-color: #25b77a;
    border-color: #3fd291;
    color: #07130e;
}
QPushButton#Danger {
    background-color: #6d2835;
    border-color: #a33a4e;
}
QPushButton:disabled {
    color: #647186;
    background-color: #151d2a;
    border-color: #222d40;
}
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox {
    min-height: 36px;
    padding: 0 10px;
    border-radius: 8px;
    border: 1px solid #33445e;
    background-color: #0e1725;
    selection-background-color: #5d55f6;
}
QComboBox QAbstractItemView {
    background-color: #111b2a;
    border: 1px solid #33445e;
    selection-background-color: #5d55f6;
}
QListWidget, QTreeWidget, QTextEdit, QPlainTextEdit {
    background-color: #0d1623;
    border: 1px solid #2b3a51;
    border-radius: 10px;
    alternate-background-color: #111c2b;
    selection-background-color: #4f49d8;
}
QHeaderView::section {
    background-color: #162236;
    color: #d9e5f3;
    padding: 8px;
    border: 0;
    border-right: 1px solid #28374e;
}
QTabWidget::pane {
    border: 1px solid #26364d;
    border-radius: 12px;
    background-color: #0f1826;
    top: -1px;
}
QTabBar::tab {
    background-color: #121c2b;
    color: #9eacc0;
    padding: 11px 20px;
    margin-right: 4px;
    border-top-left-radius: 9px;
    border-top-right-radius: 9px;
}
QTabBar::tab:selected {
    background-color: #5d55f6;
    color: white;
}
QProgressBar {
    min-height: 14px;
    border: 1px solid #2b3a50;
    border-radius: 7px;
    background-color: #0d1521;
    text-align: center;
}
QProgressBar::chunk {
    border-radius: 6px;
    background-color: #62e6a7;
}
QSlider::groove:horizontal {
    height: 6px;
    background-color: #27344a;
    border-radius: 3px;
}
QSlider::handle:horizontal {
    width: 18px;
    margin: -6px 0;
    border-radius: 9px;
    background-color: #62e6a7;
}
QScrollBar:vertical {
    width: 12px;
    background: #0b111b;
}
QScrollBar::handle:vertical {
    min-height: 28px;
    border-radius: 6px;
    background: #33445e;
}
QScrollBar:horizontal {
    height: 12px;
    background: #0b111b;
}
QScrollBar::handle:horizontal {
    min-width: 28px;
    border-radius: 6px;
    background: #33445e;
}
QToolTip {
    background-color: #202c40;
    color: white;
    border: 1px solid #4a5a74;
}
"""
