from __future__ import annotations

import io
from dataclasses import dataclass
from pathlib import Path

import fitz
from PIL import Image, ImageChops


@dataclass(frozen=True)
class SignaturePlacement:
    page_index: int
    x_fraction: float
    y_fraction: float
    width_fraction: float
    height_fraction: float
    image_png: bytes


def clean_signature_image(
    source: str | Path | bytes,
    white_threshold: int = 242,
) -> bytes:
    if isinstance(source, bytes):
        image = Image.open(io.BytesIO(source))
    else:
        image = Image.open(source)

    image = image.convert("RGBA")
    pixels = image.load()

    for y in range(image.height):
        for x in range(image.width):
            red, green, blue, alpha = pixels[x, y]
            if (
                red >= white_threshold
                and green >= white_threshold
                and blue >= white_threshold
            ):
                pixels[x, y] = (255, 255, 255, 0)
            else:
                darkness = 255 - min(red, green, blue)
                new_alpha = min(alpha, max(35, darkness * 2))
                pixels[x, y] = (red, green, blue, new_alpha)

    alpha_channel = image.getchannel("A")
    bounding_box = alpha_channel.getbbox()

    if bounding_box:
        image = image.crop(bounding_box)

    if image.width < 2 or image.height < 2:
        raise ValueError("The signature image is empty.")

    output = io.BytesIO()
    image.save(output, format="PNG")
    return output.getvalue()


def apply_signatures(
    source_pdf: Path,
    output_pdf: Path,
    placements: list[SignaturePlacement],
    password: str = "",
) -> None:
    if not placements:
        raise ValueError("Add at least one signature before saving.")

    document = fitz.open(source_pdf)

    try:
        if document.needs_pass:
            if not password or not document.authenticate(password):
                raise ValueError(
                    "The PDF password is missing or incorrect."
                )

        for placement in placements:
            if not 0 <= placement.page_index < document.page_count:
                raise ValueError(
                    f"Invalid signature page: {placement.page_index + 1}"
                )

            page = document.load_page(placement.page_index)
            page_rect = page.rect

            x0 = page_rect.x0 + (
                page_rect.width * placement.x_fraction
            )
            y0 = page_rect.y0 + (
                page_rect.height * placement.y_fraction
            )
            width = page_rect.width * placement.width_fraction
            height = page_rect.height * placement.height_fraction

            target = fitz.Rect(
                x0,
                y0,
                x0 + width,
                y0 + height,
            )

            page.insert_image(
                target,
                stream=placement.image_png,
                overlay=True,
                keep_proportion=True,
            )

        output_pdf.parent.mkdir(parents=True, exist_ok=True)

        document.save(
            output_pdf,
            garbage=4,
            deflate=True,
            clean=True,
        )
    finally:
        document.close()


def render_page_png(
    document: fitz.Document,
    page_index: int,
    scale: float = 1.6,
) -> tuple[bytes, float, float]:
    page = document.load_page(page_index)
    pixmap = page.get_pixmap(
        matrix=fitz.Matrix(scale, scale),
        alpha=False,
        annots=True,
    )

    return (
        pixmap.tobytes("png"),
        page.rect.width,
        page.rect.height,
    )
