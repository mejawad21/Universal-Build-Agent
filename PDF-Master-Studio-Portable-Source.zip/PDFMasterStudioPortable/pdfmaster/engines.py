from __future__ import annotations

import os
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable

ProgressCallback = Callable[[int, str], None]
CancelCallback = Callable[[], bool]


class ConversionCancelled(RuntimeError):
    pass


@dataclass(frozen=True)
class ConversionResult:
    source: Path
    output: Path
    engine: str
    warning: str = ""


def _check_cancel(cancelled: CancelCallback | None) -> None:
    if cancelled and cancelled():
        raise ConversionCancelled("The conversion was cancelled.")


def microsoft_word_available() -> bool:
    if os.name != "nt":
        return False
    try:
        import win32com.client  # type: ignore  # noqa: F401
        return True
    except Exception:
        return False


def find_libreoffice(application_dir: Path | None = None) -> Path | None:
    candidates: list[Path] = []

    if application_dir:
        candidates.extend(
            [
                application_dir / "LibreOfficePortable/App/libreoffice/program/soffice.exe",
                application_dir / "LibreOffice/program/soffice.exe",
                application_dir / "runtime/LibreOffice/program/soffice.exe",
            ]
        )

    for environment_name in ("PROGRAMFILES", "PROGRAMFILES(X86)"):
        base = os.environ.get(environment_name)
        if base:
            candidates.append(
                Path(base) / "LibreOffice/program/soffice.exe"
            )

    executable = shutil.which("soffice") or shutil.which("libreoffice")
    if executable:
        candidates.append(Path(executable))

    for candidate in candidates:
        if candidate.is_file():
            return candidate

    return None


def _pdf_to_docx_word(source: Path, output: Path) -> ConversionResult:
    import pythoncom  # type: ignore
    import win32com.client  # type: ignore

    pythoncom.CoInitialize()
    word = None
    document = None

    try:
        word = win32com.client.DispatchEx("Word.Application")
        word.Visible = False
        word.DisplayAlerts = 0

        document = word.Documents.Open(
            str(source.resolve()),
            ConfirmConversions=False,
            ReadOnly=True,
            AddToRecentFiles=False,
        )

        # wdFormatDocumentDefault = 16 (.docx)
        document.SaveAs2(
            str(output.resolve()),
            FileFormat=16,
            AddToRecentFiles=False,
        )

        return ConversionResult(
            source=source,
            output=output,
            engine="Microsoft Word high-fidelity engine",
        )
    finally:
        if document is not None:
            document.Close(False)
        if word is not None:
            word.Quit()
        pythoncom.CoUninitialize()


def _pdf_to_docx_fallback(
    source: Path,
    output: Path,
) -> ConversionResult:
    try:
        from pdf2docx import Converter  # type: ignore
    except Exception as error:
        raise RuntimeError(
            "The portable PDF-to-Word engine is unavailable. "
            "Rebuild the application with pdf2docx included."
        ) from error

    converter = Converter(str(source))
    try:
        converter.convert(str(output))
    finally:
        converter.close()

    return ConversionResult(
        source=source,
        output=output,
        engine="Portable editable-layout engine",
        warning=(
            "Complex forms, unusual fonts, and advanced page designs may "
            "require adjustment in Word."
        ),
    )


def pdf_to_docx(
    source: Path,
    output: Path,
    engine: str,
) -> ConversionResult:
    output.parent.mkdir(parents=True, exist_ok=True)

    if engine == "word":
        if not microsoft_word_available():
            raise RuntimeError(
                "Microsoft Word is not available on this computer. "
                "Choose the Portable fallback engine."
            )
        return _pdf_to_docx_word(source, output)

    return _pdf_to_docx_fallback(source, output)


def _word_to_pdf_word(source: Path, output: Path) -> ConversionResult:
    import pythoncom  # type: ignore
    import win32com.client  # type: ignore

    pythoncom.CoInitialize()
    word = None
    document = None

    try:
        word = win32com.client.DispatchEx("Word.Application")
        word.Visible = False
        word.DisplayAlerts = 0

        document = word.Documents.Open(
            str(source.resolve()),
            ConfirmConversions=False,
            ReadOnly=True,
            AddToRecentFiles=False,
        )

        # wdExportFormatPDF = 17
        document.ExportAsFixedFormat(
            str(output.resolve()),
            17,
        )

        return ConversionResult(
            source=source,
            output=output,
            engine="Microsoft Word PDF export",
        )
    finally:
        if document is not None:
            document.Close(False)
        if word is not None:
            word.Quit()
        pythoncom.CoUninitialize()


def _word_to_pdf_libreoffice(
    source: Path,
    output: Path,
    application_dir: Path | None,
) -> ConversionResult:
    soffice = find_libreoffice(application_dir)
    if not soffice:
        raise RuntimeError(
            "Microsoft Word and LibreOffice were not found. "
            "Place LibreOffice Portable beside the EXE or use a computer "
            "that already has Microsoft Word."
        )

    output.parent.mkdir(parents=True, exist_ok=True)

    command = [
        str(soffice),
        "--headless",
        "--convert-to",
        "pdf",
        "--outdir",
        str(output.parent),
        str(source),
    ]

    completed = subprocess.run(
        command,
        capture_output=True,
        text=True,
        timeout=300,
        creationflags=(
            subprocess.CREATE_NO_WINDOW
            if os.name == "nt"
            else 0
        ),
    )

    generated = output.parent / f"{source.stem}.pdf"

    if completed.returncode != 0 or not generated.exists():
        raise RuntimeError(
            "LibreOffice could not convert the document. "
            + (completed.stderr.strip() or completed.stdout.strip())
        )

    if generated.resolve() != output.resolve():
        if output.exists():
            output.unlink()
        generated.replace(output)

    return ConversionResult(
        source=source,
        output=output,
        engine="LibreOffice portable engine",
    )


def word_to_pdf(
    source: Path,
    output: Path,
    engine: str,
    application_dir: Path | None,
) -> ConversionResult:
    output.parent.mkdir(parents=True, exist_ok=True)

    if engine == "word":
        if not microsoft_word_available():
            raise RuntimeError(
                "Microsoft Word is not available. "
                "Choose LibreOffice Portable."
            )
        return _word_to_pdf_word(source, output)

    return _word_to_pdf_libreoffice(
        source,
        output,
        application_dir,
    )


def batch_convert(
    sources: Iterable[Path],
    output_directory: Path,
    direction: str,
    engine: str,
    application_dir: Path | None = None,
    progress: ProgressCallback | None = None,
    cancelled: CancelCallback | None = None,
) -> list[ConversionResult]:
    items = list(sources)

    if not items:
        raise ValueError("No files were selected.")

    output_directory.mkdir(parents=True, exist_ok=True)
    results: list[ConversionResult] = []

    for index, source in enumerate(items):
        _check_cancel(cancelled)

        if progress:
            progress(
                int(index / len(items) * 100),
                f"Converting {source.name}…",
            )

        if direction == "pdf_to_word":
            output = output_directory / f"{source.stem}.docx"
            result = pdf_to_docx(source, output, engine)
        else:
            output = output_directory / f"{source.stem}.pdf"
            result = word_to_pdf(
                source,
                output,
                engine,
                application_dir,
            )

        results.append(result)

        if progress:
            progress(
                int((index + 1) / len(items) * 100),
                f"Finished {source.name}",
            )

    return results
