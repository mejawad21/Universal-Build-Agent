from __future__ import annotations

import traceback
from pathlib import Path

from PySide6.QtCore import QThread, Signal

from .engines import batch_convert


class ConversionWorker(QThread):
    progress = Signal(int, str)
    item_finished = Signal(str, str, str)
    failed = Signal(str)
    completed = Signal(int)

    def __init__(
        self,
        sources: list[Path],
        output_directory: Path,
        direction: str,
        engine: str,
        application_directory: Path,
    ) -> None:
        super().__init__()
        self.sources = sources
        self.output_directory = output_directory
        self.direction = direction
        self.engine = engine
        self.application_directory = application_directory
        self._cancel_requested = False

    def request_cancel(self) -> None:
        self._cancel_requested = True

    def run(self) -> None:
        try:
            results = batch_convert(
                sources=self.sources,
                output_directory=self.output_directory,
                direction=self.direction,
                engine=self.engine,
                application_dir=self.application_directory,
                progress=lambda value, message: self.progress.emit(
                    value,
                    message,
                ),
                cancelled=lambda: self._cancel_requested,
            )

            for result in results:
                self.item_finished.emit(
                    str(result.source),
                    str(result.output),
                    result.warning,
                )

            self.completed.emit(len(results))
        except Exception as error:
            details = "".join(
                traceback.format_exception_only(
                    type(error),
                    error,
                )
            ).strip()
            self.failed.emit(details)
