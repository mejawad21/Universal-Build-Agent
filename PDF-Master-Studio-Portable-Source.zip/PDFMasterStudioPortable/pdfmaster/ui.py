from __future__ import annotations

import io
import os
import sys
from dataclasses import dataclass
from pathlib import Path

import fitz
from PIL import Image

from PySide6.QtCore import (
    QBuffer,
    QIODevice,
    QPoint,
    QPointF,
    QRectF,
    QUrl,
    Qt,
    Signal,
)
from PySide6.QtGui import (
    QColor,
    QDesktopServices,
    QIcon,
    QImage,
    QMouseEvent,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
    QShortcut,
    QKeySequence,
)
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFrame,
    QGraphicsItem,
    QGraphicsPixmapItem,
    QGraphicsRectItem,
    QGraphicsScene,
    QGraphicsView,
    QGridLayout,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QSlider,
    QSpinBox,
    QSplitter,
    QStackedWidget,
    QTabWidget,
    QTextEdit,
    QToolButton,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .engines import (
    find_libreoffice,
    microsoft_word_available,
)
from .signing import (
    SignaturePlacement,
    apply_signatures,
    clean_signature_image,
    render_page_png,
)
from .workers import ConversionWorker


def application_directory() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[1]


def card() -> QFrame:
    frame = QFrame()
    frame.setObjectName("Card")
    return frame


class SignaturePad(QWidget):
    signature_changed = Signal()

    def __init__(self) -> None:
        super().__init__()
        self.setMinimumSize(620, 260)
        self.setCursor(Qt.CursorShape.CrossCursor)
        self._paths: list[QPainterPath] = []
        self._current_path: QPainterPath | None = None

    def clear(self) -> None:
        self._paths.clear()
        self._current_path = None
        self.update()
        self.signature_changed.emit()

    def has_signature(self) -> bool:
        return bool(self._paths)

    def mousePressEvent(self, event: QMouseEvent) -> None:
        if event.button() != Qt.MouseButton.LeftButton:
            return

        self._current_path = QPainterPath(event.position())
        self._paths.append(self._current_path)
        self.update()

    def mouseMoveEvent(self, event: QMouseEvent) -> None:
        if (
            self._current_path is None
            or not event.buttons() & Qt.MouseButton.LeftButton
        ):
            return

        self._current_path.lineTo(event.position())
        self.update()

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self._current_path = None
            self.signature_changed.emit()

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        painter.fillRect(self.rect(), QColor("#ffffff"))

        grid_pen = QPen(QColor("#e8ecf1"), 1)
        painter.setPen(grid_pen)

        for x in range(0, self.width(), 24):
            painter.drawLine(x, 0, x, self.height())

        for y in range(0, self.height(), 24):
            painter.drawLine(0, y, self.width(), y)

        baseline_pen = QPen(QColor("#bdc8d4"), 1)
        painter.setPen(baseline_pen)
        painter.drawLine(
            25,
            self.height() - 58,
            self.width() - 25,
            self.height() - 58,
        )

        signature_pen = QPen(
            QColor("#101820"),
            4.0,
            Qt.PenStyle.SolidLine,
            Qt.PenCapStyle.RoundCap,
            Qt.PenJoinStyle.RoundJoin,
        )
        painter.setPen(signature_pen)

        for path in self._paths:
            painter.drawPath(path)

    def export_png(self) -> bytes:
        if not self.has_signature():
            raise ValueError("Draw a signature first.")

        image = QImage(
            self.size(),
            QImage.Format.Format_ARGB32,
        )
        image.fill(Qt.GlobalColor.transparent)

        painter = QPainter(image)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setPen(
            QPen(
                QColor("#101820"),
                5.0,
                Qt.PenStyle.SolidLine,
                Qt.PenCapStyle.RoundCap,
                Qt.PenJoinStyle.RoundJoin,
            )
        )

        for path in self._paths:
            painter.drawPath(path)

        painter.end()

        byte_array = QBuffer()
        byte_array.open(QIODevice.OpenModeFlag.WriteOnly)

        if not image.save(byte_array, "PNG"):
            raise ValueError("The drawn signature could not be exported.")

        byte_array.close()
        return bytes(byte_array.data())


class SignatureDialog(QDialog):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Draw Signature")
        self.resize(720, 410)
        self.signature_png: bytes | None = None

        layout = QVBoxLayout(self)

        title = QLabel("Draw your signature")
        title.setObjectName("Heading")
        layout.addWidget(title)

        note = QLabel(
            "Use the mouse, touchpad, or a touchscreen. "
            "The white background will be removed automatically."
        )
        note.setObjectName("Muted")
        note.setWordWrap(True)
        layout.addWidget(note)

        self.pad = SignaturePad()
        layout.addWidget(self.pad, 1)

        controls = QHBoxLayout()

        clear_button = QPushButton("Clear")
        clear_button.clicked.connect(self.pad.clear)
        controls.addWidget(clear_button)

        controls.addStretch(1)

        cancel_button = QPushButton("Cancel")
        cancel_button.clicked.connect(self.reject)
        controls.addWidget(cancel_button)

        use_button = QPushButton("Use Signature")
        use_button.setObjectName("Primary")
        use_button.clicked.connect(self.accept_signature)
        controls.addWidget(use_button)

        layout.addLayout(controls)

    def accept_signature(self) -> None:
        try:
            self.signature_png = clean_signature_image(
                self.pad.export_png()
            )
        except Exception as error:
            QMessageBox.warning(
                self,
                "Signature",
                str(error),
            )
            return

        self.accept()


class SignaturePixmapItem(QGraphicsPixmapItem):
    def __init__(self, pixmap: QPixmap, image_png: bytes) -> None:
        super().__init__(pixmap)
        self.image_png = image_png
        self.setFlags(
            QGraphicsItem.GraphicsItemFlag.ItemIsMovable
            | QGraphicsItem.GraphicsItemFlag.ItemIsSelectable
            | QGraphicsItem.GraphicsItemFlag.ItemSendsGeometryChanges
        )
        self.setTransformationMode(
            Qt.TransformationMode.SmoothTransformation
        )


@dataclass
class StoredPlacement:
    x_fraction: float
    y_fraction: float
    width_fraction: float
    height_fraction: float
    image_png: bytes


class PdfPageView(QGraphicsView):
    selection_changed = Signal(bool)

    def __init__(self) -> None:
        super().__init__()
        self.setRenderHints(
            QPainter.RenderHint.Antialiasing
            | QPainter.RenderHint.SmoothPixmapTransform
        )
        self.setDragMode(
            QGraphicsView.DragMode.ScrollHandDrag
        )
        self.setBackgroundBrush(QColor("#08101a"))

        self.scene = QGraphicsScene(self)
        self.setScene(self.scene)

        self.page_item: QGraphicsPixmapItem | None = None
        self.signature_items: list[SignaturePixmapItem] = []
        self.highlight_items: list[QGraphicsRectItem] = []

        self.page_pixel_width = 0.0
        self.page_pixel_height = 0.0
        self.page_point_width = 0.0
        self.page_point_height = 0.0
        self.render_scale = 1.6

        self.scene.selectionChanged.connect(
            self._emit_selection_state
        )

    def _emit_selection_state(self) -> None:
        self.selection_changed.emit(
            isinstance(self.selected_signature(), SignaturePixmapItem)
        )

    def load_page(
        self,
        png_bytes: bytes,
        point_width: float,
        point_height: float,
        stored: list[StoredPlacement],
    ) -> None:
        self.scene.clear()
        self.signature_items.clear()
        self.highlight_items.clear()

        image = QImage.fromData(png_bytes)
        pixmap = QPixmap.fromImage(image)

        self.page_item = self.scene.addPixmap(pixmap)
        self.page_item.setZValue(0)

        self.page_pixel_width = float(pixmap.width())
        self.page_pixel_height = float(pixmap.height())
        self.page_point_width = point_width
        self.page_point_height = point_height

        self.scene.setSceneRect(
            0,
            0,
            pixmap.width(),
            pixmap.height(),
        )

        for placement in stored:
            self.add_signature_from_storage(placement)

        self.fit_width()

    def fit_width(self) -> None:
        if not self.page_item:
            return

        available_width = max(1, self.viewport().width() - 28)
        factor = available_width / max(
            1.0,
            self.page_item.boundingRect().width(),
        )

        self.resetTransform()
        self.scale(factor, factor)

    def zoom_in(self) -> None:
        self.scale(1.18, 1.18)

    def zoom_out(self) -> None:
        self.scale(1 / 1.18, 1 / 1.18)

    def add_signature(
        self,
        image_png: bytes,
        width_fraction: float = 0.24,
    ) -> SignaturePixmapItem:
        pixmap = QPixmap()
        pixmap.loadFromData(image_png)

        if pixmap.isNull():
            raise ValueError("The signature image could not be loaded.")

        desired_width = max(
            80.0,
            self.page_pixel_width * width_fraction,
        )

        scaled = pixmap.scaledToWidth(
            int(desired_width),
            Qt.TransformationMode.SmoothTransformation,
        )

        item = SignaturePixmapItem(scaled, image_png)
        item.setZValue(10)

        x = (
            self.page_pixel_width - scaled.width()
        ) / 2.0
        y = (
            self.page_pixel_height - scaled.height()
        ) * 0.78

        item.setPos(
            max(0.0, x),
            max(0.0, y),
        )

        self.scene.addItem(item)
        self.signature_items.append(item)
        item.setSelected(True)
        return item

    def add_signature_from_storage(
        self,
        placement: StoredPlacement,
    ) -> None:
        pixmap = QPixmap()
        pixmap.loadFromData(placement.image_png)

        target_width = max(
            20,
            int(self.page_pixel_width * placement.width_fraction),
        )

        target_height = max(
            10,
            int(self.page_pixel_height * placement.height_fraction),
        )

        scaled = pixmap.scaled(
            target_width,
            target_height,
            Qt.AspectRatioMode.IgnoreAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )

        item = SignaturePixmapItem(
            scaled,
            placement.image_png,
        )
        item.setZValue(10)
        item.setPos(
            self.page_pixel_width * placement.x_fraction,
            self.page_pixel_height * placement.y_fraction,
        )

        self.scene.addItem(item)
        self.signature_items.append(item)

    def selected_signature(self) -> SignaturePixmapItem | None:
        for item in self.scene.selectedItems():
            if isinstance(item, SignaturePixmapItem):
                return item
        return None

    def resize_selected(self, percentage: int) -> None:
        item = self.selected_signature()

        if not item:
            return

        original = QPixmap()
        original.loadFromData(item.image_png)

        desired_width = max(
            30,
            int(self.page_pixel_width * percentage / 100.0),
        )

        scaled = original.scaledToWidth(
            desired_width,
            Qt.TransformationMode.SmoothTransformation,
        )

        old_center = item.sceneBoundingRect().center()
        item.setPixmap(scaled)
        new_rect = item.sceneBoundingRect()

        item.setPos(
            item.pos().x() + old_center.x() - new_rect.center().x(),
            item.pos().y() + old_center.y() - new_rect.center().y(),
        )

    def delete_selected(self) -> None:
        item = self.selected_signature()

        if not item:
            return

        self.scene.removeItem(item)
        if item in self.signature_items:
            self.signature_items.remove(item)

    def serialize_signatures(self) -> list[StoredPlacement]:
        placements: list[StoredPlacement] = []

        if self.page_pixel_width <= 0 or self.page_pixel_height <= 0:
            return placements

        for item in self.signature_items:
            bounds = item.sceneBoundingRect()

            x = min(
                max(0.0, bounds.x()),
                self.page_pixel_width,
            )
            y = min(
                max(0.0, bounds.y()),
                self.page_pixel_height,
            )
            width = min(
                bounds.width(),
                self.page_pixel_width - x,
            )
            height = min(
                bounds.height(),
                self.page_pixel_height - y,
            )

            placements.append(
                StoredPlacement(
                    x_fraction=x / self.page_pixel_width,
                    y_fraction=y / self.page_pixel_height,
                    width_fraction=width / self.page_pixel_width,
                    height_fraction=height / self.page_pixel_height,
                    image_png=item.image_png,
                )
            )

        return placements

    def show_search_rectangles(
        self,
        rectangles: list[fitz.Rect],
    ) -> None:
        for item in self.highlight_items:
            self.scene.removeItem(item)

        self.highlight_items.clear()

        if (
            self.page_point_width <= 0
            or self.page_point_height <= 0
        ):
            return

        x_factor = self.page_pixel_width / self.page_point_width
        y_factor = self.page_pixel_height / self.page_point_height

        for rectangle in rectangles:
            item = QGraphicsRectItem(
                QRectF(
                    rectangle.x0 * x_factor,
                    rectangle.y0 * y_factor,
                    rectangle.width * x_factor,
                    rectangle.height * y_factor,
                )
            )

            item.setPen(QPen(QColor("#f4c542"), 2))
            item.setBrush(QColor(244, 197, 66, 75))
            item.setZValue(5)
            self.scene.addItem(item)
            self.highlight_items.append(item)


class ConverterTab(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self.worker: ConversionWorker | None = None
        self.sources: list[Path] = []

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(18, 18, 18, 18)
        main_layout.setSpacing(14)

        heading = QLabel("Batch Document Converter")
        heading.setObjectName("Title")
        main_layout.addWidget(heading)

        subtitle = QLabel(
            "Convert many PDFs to editable Word files, or many Word files "
            "to PDF, without uploading documents to the Internet."
        )
        subtitle.setObjectName("Muted")
        subtitle.setWordWrap(True)
        main_layout.addWidget(subtitle)

        options_card = card()
        options_layout = QGridLayout(options_card)
        options_layout.setContentsMargins(16, 16, 16, 16)
        options_layout.setHorizontalSpacing(12)
        options_layout.setVerticalSpacing(10)

        options_layout.addWidget(QLabel("Conversion"), 0, 0)
        self.direction_combo = QComboBox()
        self.direction_combo.addItem(
            "PDF → Editable Word (DOCX)",
            "pdf_to_word",
        )
        self.direction_combo.addItem(
            "Word (DOC/DOCX) → PDF",
            "word_to_pdf",
        )
        self.direction_combo.currentIndexChanged.connect(
            self.direction_changed
        )
        options_layout.addWidget(self.direction_combo, 1, 0)

        options_layout.addWidget(QLabel("Conversion engine"), 0, 1)
        self.engine_combo = QComboBox()
        options_layout.addWidget(self.engine_combo, 1, 1)

        options_layout.addWidget(QLabel("Output folder"), 2, 0)
        self.output_edit = QLineEdit(
            str(Path.home() / "Documents/PDF Master Output")
        )
        options_layout.addWidget(self.output_edit, 3, 0, 1, 2)

        browse_output = QPushButton("Choose Folder")
        browse_output.clicked.connect(self.choose_output)
        options_layout.addWidget(browse_output, 3, 2)

        main_layout.addWidget(options_card)

        fidelity_note = QLabel(
            "Highest Fidelity uses Microsoft Word when it is already "
            "installed. The portable fallback keeps text, images, tables, "
            "and page structure editable, but no converter can promise "
            "pixel-identical layout for every PDF because PDF uses fixed "
            "page coordinates while Word uses flowing document layout."
        )
        fidelity_note.setObjectName("Muted")
        fidelity_note.setWordWrap(True)
        main_layout.addWidget(fidelity_note)

        list_card = card()
        list_layout = QVBoxLayout(list_card)
        list_layout.setContentsMargins(14, 14, 14, 14)

        controls = QHBoxLayout()

        self.add_button = QPushButton("Add PDF Files")
        self.add_button.setObjectName("Primary")
        self.add_button.clicked.connect(self.add_files)
        controls.addWidget(self.add_button)

        remove_button = QPushButton("Remove Selected")
        remove_button.clicked.connect(self.remove_selected)
        controls.addWidget(remove_button)

        clear_button = QPushButton("Clear List")
        clear_button.clicked.connect(self.clear_files)
        controls.addWidget(clear_button)

        controls.addStretch(1)
        list_layout.addLayout(controls)

        self.file_tree = QTreeWidget()
        self.file_tree.setHeaderLabels(
            ["File", "Type", "Status", "Output"]
        )
        self.file_tree.setAlternatingRowColors(True)
        self.file_tree.setSelectionMode(
            QAbstractItemView.SelectionMode.ExtendedSelection
        )
        self.file_tree.setColumnWidth(0, 360)
        self.file_tree.setColumnWidth(1, 90)
        self.file_tree.setColumnWidth(2, 150)
        list_layout.addWidget(self.file_tree, 1)

        main_layout.addWidget(list_card, 1)

        action_row = QHBoxLayout()

        self.open_folder_checkbox = QCheckBox(
            "Open output folder after conversion"
        )
        self.open_folder_checkbox.setChecked(True)
        action_row.addWidget(self.open_folder_checkbox)

        action_row.addStretch(1)

        self.cancel_button = QPushButton("Cancel")
        self.cancel_button.setObjectName("Danger")
        self.cancel_button.setEnabled(False)
        self.cancel_button.clicked.connect(self.cancel_conversion)
        action_row.addWidget(self.cancel_button)

        self.start_button = QPushButton("Start Batch Conversion")
        self.start_button.setObjectName("Success")
        self.start_button.clicked.connect(self.start_conversion)
        action_row.addWidget(self.start_button)

        main_layout.addLayout(action_row)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        main_layout.addWidget(self.progress)

        self.status_label = QLabel("Ready")
        self.status_label.setObjectName("Muted")
        main_layout.addWidget(self.status_label)

        self.direction_changed()

    def direction_changed(self) -> None:
        direction = self.direction_combo.currentData()
        self.engine_combo.clear()

        if direction == "pdf_to_word":
            self.add_button.setText("Add PDF Files")

            self.engine_combo.addItem(
                (
                    "Highest Fidelity — Microsoft Word"
                    + (
                        ""
                        if microsoft_word_available()
                        else " (not detected)"
                    )
                ),
                "word",
            )

            self.engine_combo.addItem(
                "Portable Editable Engine — no Office required",
                "portable",
            )

            if not microsoft_word_available():
                self.engine_combo.setCurrentIndex(1)
        else:
            self.add_button.setText("Add Word Files")

            self.engine_combo.addItem(
                (
                    "Microsoft Word PDF Export"
                    + (
                        ""
                        if microsoft_word_available()
                        else " (not detected)"
                    )
                ),
                "word",
            )

            libreoffice = find_libreoffice(
                application_directory()
            )

            self.engine_combo.addItem(
                (
                    "LibreOffice Portable"
                    + (
                        ""
                        if libreoffice
                        else " (place beside EXE)"
                    )
                ),
                "libreoffice",
            )

            if not microsoft_word_available():
                self.engine_combo.setCurrentIndex(1)

        self.clear_files()

    def choose_output(self) -> None:
        directory = QFileDialog.getExistingDirectory(
            self,
            "Choose Output Folder",
            self.output_edit.text(),
        )

        if directory:
            self.output_edit.setText(directory)

    def add_files(self) -> None:
        direction = self.direction_combo.currentData()

        if direction == "pdf_to_word":
            paths, _ = QFileDialog.getOpenFileNames(
                self,
                "Select PDF Files",
                str(Path.home()),
                "PDF Documents (*.pdf)",
            )
        else:
            paths, _ = QFileDialog.getOpenFileNames(
                self,
                "Select Word Files",
                str(Path.home()),
                "Word Documents (*.docx *.doc)",
            )

        existing = {path.resolve() for path in self.sources}

        for value in paths:
            path = Path(value)

            if path.resolve() in existing:
                continue

            self.sources.append(path)
            existing.add(path.resolve())

            item = QTreeWidgetItem(
                [
                    path.name,
                    path.suffix.upper().lstrip("."),
                    "Waiting",
                    "",
                ]
            )
            item.setData(0, Qt.ItemDataRole.UserRole, str(path))
            self.file_tree.addTopLevelItem(item)

    def remove_selected(self) -> None:
        selected = self.file_tree.selectedItems()

        for item in selected:
            value = Path(
                item.data(0, Qt.ItemDataRole.UserRole)
            )

            self.sources = [
                path
                for path in self.sources
                if path.resolve() != value.resolve()
            ]

            index = self.file_tree.indexOfTopLevelItem(item)
            self.file_tree.takeTopLevelItem(index)

    def clear_files(self) -> None:
        self.sources.clear()
        self.file_tree.clear()
        self.progress.setValue(0)
        self.status_label.setText("Ready")

    def start_conversion(self) -> None:
        if not self.sources:
            QMessageBox.information(
                self,
                "Batch Conversion",
                "Add at least one file.",
            )
            return

        output_directory = Path(
            self.output_edit.text().strip()
        )

        if not str(output_directory):
            QMessageBox.warning(
                self,
                "Output Folder",
                "Choose an output folder.",
            )
            return

        for index in range(
            self.file_tree.topLevelItemCount()
        ):
            item = self.file_tree.topLevelItem(index)
            item.setText(2, "Queued")
            item.setText(3, "")

        self.worker = ConversionWorker(
            sources=list(self.sources),
            output_directory=output_directory,
            direction=self.direction_combo.currentData(),
            engine=self.engine_combo.currentData(),
            application_directory=application_directory(),
        )

        self.worker.progress.connect(self.update_progress)
        self.worker.item_finished.connect(
            self.item_finished
        )
        self.worker.failed.connect(self.conversion_failed)
        self.worker.completed.connect(
            self.conversion_completed
        )

        self.start_button.setEnabled(False)
        self.cancel_button.setEnabled(True)
        self.add_button.setEnabled(False)
        self.worker.start()

    def update_progress(
        self,
        value: int,
        message: str,
    ) -> None:
        self.progress.setValue(value)
        self.status_label.setText(message)

        for index in range(
            self.file_tree.topLevelItemCount()
        ):
            item = self.file_tree.topLevelItem(index)

            if (
                item.text(2) == "Queued"
                and item.text(0) in message
            ):
                item.setText(2, "Converting")

    def item_finished(
        self,
        source: str,
        output: str,
        warning: str,
    ) -> None:
        source_path = Path(source)

        for index in range(
            self.file_tree.topLevelItemCount()
        ):
            item = self.file_tree.topLevelItem(index)

            if item.text(0) == source_path.name:
                item.setText(
                    2,
                    "Completed" if not warning else "Completed • review",
                )
                item.setText(3, output)
                item.setToolTip(2, warning)
                break

    def conversion_failed(self, message: str) -> None:
        self.start_button.setEnabled(True)
        self.cancel_button.setEnabled(False)
        self.add_button.setEnabled(True)
        self.status_label.setText("Conversion failed")

        QMessageBox.critical(
            self,
            "Conversion Failed",
            message,
        )

    def conversion_completed(self, count: int) -> None:
        self.start_button.setEnabled(True)
        self.cancel_button.setEnabled(False)
        self.add_button.setEnabled(True)
        self.progress.setValue(100)
        self.status_label.setText(
            f"Completed {count} file(s)."
        )

        QMessageBox.information(
            self,
            "Conversion Complete",
            f"Successfully converted {count} file(s).",
        )

        if self.open_folder_checkbox.isChecked():
            output = Path(self.output_edit.text())
            QDesktopServices.openUrl(
                QUrl.fromLocalFile(str(output))
            )

    def cancel_conversion(self) -> None:
        if self.worker:
            self.worker.request_cancel()
            self.status_label.setText(
                "Cancelling after the current file…"
            )


class ReaderSignerTab(QWidget):
    def __init__(self) -> None:
        super().__init__()

        self.document: fitz.Document | None = None
        self.document_path: Path | None = None
        self.password = ""
        self.current_page = 0
        self.current_signature_png: bytes | None = None
        self.page_placements: dict[
            int,
            list[StoredPlacement],
        ] = {}
        self.search_results: list[
            tuple[int, list[fitz.Rect]]
        ] = []
        self.search_result_index = -1

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        toolbar = QHBoxLayout()

        open_button = QPushButton("Open PDF")
        open_button.setObjectName("Primary")
        open_button.clicked.connect(self.open_pdf)
        toolbar.addWidget(open_button)

        self.previous_button = QPushButton("◀")
        self.previous_button.setToolTip("Previous page")
        self.previous_button.clicked.connect(
            lambda: self.go_to_page(self.current_page - 1)
        )
        toolbar.addWidget(self.previous_button)

        self.next_button = QPushButton("▶")
        self.next_button.setToolTip("Next page")
        self.next_button.clicked.connect(
            lambda: self.go_to_page(self.current_page + 1)
        )
        toolbar.addWidget(self.next_button)

        self.page_spin = QSpinBox()
        self.page_spin.setMinimum(1)
        self.page_spin.setMaximum(1)
        self.page_spin.valueChanged.connect(
            lambda value: self.go_to_page(value - 1)
        )
        toolbar.addWidget(self.page_spin)

        self.page_count_label = QLabel("/ 0")
        toolbar.addWidget(self.page_count_label)

        toolbar.addSpacing(10)

        zoom_out_button = QPushButton("−")
        zoom_out_button.clicked.connect(
            self.zoom_out
        )
        toolbar.addWidget(zoom_out_button)

        fit_button = QPushButton("Fit Width")
        fit_button.clicked.connect(
            self.fit_width
        )
        toolbar.addWidget(fit_button)

        zoom_in_button = QPushButton("+")
        zoom_in_button.clicked.connect(
            self.zoom_in
        )
        toolbar.addWidget(zoom_in_button)

        toolbar.addStretch(1)

        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText(
            "Search PDF text…"
        )
        self.search_edit.returnPressed.connect(
            self.search_document
        )
        toolbar.addWidget(self.search_edit, 1)

        search_button = QPushButton("Search")
        search_button.clicked.connect(
            self.search_document
        )
        toolbar.addWidget(search_button)

        next_result_button = QPushButton("Next Result")
        next_result_button.clicked.connect(
            self.next_search_result
        )
        toolbar.addWidget(next_result_button)

        layout.addLayout(toolbar)

        splitter = QSplitter(
            Qt.Orientation.Horizontal
        )

        thumbnail_card = card()
        thumbnail_layout = QVBoxLayout(thumbnail_card)
        thumbnail_layout.setContentsMargins(8, 8, 8, 8)

        thumbnail_title = QLabel("Pages")
        thumbnail_title.setObjectName("Heading")
        thumbnail_layout.addWidget(thumbnail_title)

        self.thumbnail_list = QListWidget()
        self.thumbnail_list.setMaximumWidth(190)
        self.thumbnail_list.currentRowChanged.connect(
            self.go_to_page
        )
        thumbnail_layout.addWidget(
            self.thumbnail_list,
            1,
        )

        splitter.addWidget(thumbnail_card)

        self.page_view = PdfPageView()
        self.page_view.selection_changed.connect(
            self.signature_selection_changed
        )
        splitter.addWidget(self.page_view)

        signature_card = card()
        signature_card.setMinimumWidth(265)
        signature_card.setMaximumWidth(320)
        signature_layout = QVBoxLayout(signature_card)
        signature_layout.setContentsMargins(
            14,
            14,
            14,
            14,
        )

        signature_heading = QLabel(
            "Signature Studio"
        )
        signature_heading.setObjectName("Heading")
        signature_layout.addWidget(signature_heading)

        signature_note = QLabel(
            "Draw a new signature or import a transparent PNG/JPG, "
            "then place and move it directly on the PDF page."
        )
        signature_note.setObjectName("Muted")
        signature_note.setWordWrap(True)
        signature_layout.addWidget(signature_note)

        draw_button = QPushButton("Draw Signature")
        draw_button.setObjectName("Primary")
        draw_button.clicked.connect(
            self.draw_signature
        )
        signature_layout.addWidget(draw_button)

        import_button = QPushButton(
            "Import Signature Image"
        )
        import_button.clicked.connect(
            self.import_signature
        )
        signature_layout.addWidget(import_button)

        self.signature_status = QLabel(
            "No signature loaded"
        )
        self.signature_status.setObjectName("Muted")
        self.signature_status.setWordWrap(True)
        signature_layout.addWidget(self.signature_status)

        self.add_signature_button = QPushButton(
            "Place Signature on Page"
        )
        self.add_signature_button.setObjectName(
            "Success"
        )
        self.add_signature_button.clicked.connect(
            self.add_signature_to_page
        )
        signature_layout.addWidget(
            self.add_signature_button
        )

        signature_layout.addWidget(
            QLabel("Selected signature size")
        )

        self.size_slider = QSlider(
            Qt.Orientation.Horizontal
        )
        self.size_slider.setRange(8, 55)
        self.size_slider.setValue(24)
        self.size_slider.valueChanged.connect(
            self.resize_selected_signature
        )
        signature_layout.addWidget(
            self.size_slider
        )

        self.delete_signature_button = QPushButton(
            "Delete Selected Signature"
        )
        self.delete_signature_button.setObjectName(
            "Danger"
        )
        self.delete_signature_button.setEnabled(
            False
        )
        self.delete_signature_button.clicked.connect(
            self.page_view.delete_selected
        )
        signature_layout.addWidget(
            self.delete_signature_button
        )

        self.apply_all_checkbox = QCheckBox(
            "Repeat this page's signatures on all pages"
        )
        signature_layout.addWidget(
            self.apply_all_checkbox
        )

        signature_layout.addStretch(1)

        self.save_button = QPushButton(
            "Save Signed PDF Copy"
        )
        self.save_button.setObjectName("Primary")
        self.save_button.clicked.connect(
            self.save_signed_pdf
        )
        signature_layout.addWidget(self.save_button)

        splitter.addWidget(signature_card)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        splitter.setStretchFactor(2, 0)

        layout.addWidget(splitter, 1)

        self.reader_status = QLabel(
            "Open a PDF to start reading or signing."
        )
        self.reader_status.setObjectName("Muted")
        layout.addWidget(self.reader_status)

        QShortcut(
            QKeySequence.StandardKey.Open,
            self,
            activated=self.open_pdf,
        )

    def close_document(self) -> None:
        if self.document is not None:
            self.document.close()

        self.document = None
        self.document_path = None
        self.password = ""
        self.page_placements.clear()
        self.thumbnail_list.clear()

    def open_pdf(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Open PDF",
            str(Path.home()),
            "PDF Documents (*.pdf)",
        )

        if not path:
            return

        self.close_document()

        try:
            document = fitz.open(path)

            if document.needs_pass:
                password, accepted = QInputDialog.getText(
                    self,
                    "Protected PDF",
                    "Enter the PDF password:",
                    QLineEdit.EchoMode.Password,
                )

                if (
                    not accepted
                    or not document.authenticate(password)
                ):
                    document.close()
                    raise ValueError(
                        "The PDF password is missing or incorrect."
                    )

                self.password = password

            self.document = document
            self.document_path = Path(path)
            self.current_page = 0
            self.page_spin.blockSignals(True)
            self.page_spin.setMaximum(
                max(1, document.page_count)
            )
            self.page_spin.setValue(1)
            self.page_spin.blockSignals(False)
            self.page_count_label.setText(
                f"/ {document.page_count}"
            )

            self.build_thumbnails()
            self.load_current_page()

            self.reader_status.setText(
                f"Opened {self.document_path.name} • "
                f"{document.page_count} page(s)"
            )
        except Exception as error:
            QMessageBox.critical(
                self,
                "Open PDF",
                str(error),
            )

    def build_thumbnails(self) -> None:
        if not self.document:
            return

        self.thumbnail_list.blockSignals(True)
        self.thumbnail_list.clear()

        for page_index in range(
            self.document.page_count
        ):
            page = self.document.load_page(page_index)
            pixmap = page.get_pixmap(
                matrix=fitz.Matrix(0.20, 0.20),
                alpha=False,
            )

            image = QImage.fromData(
                pixmap.tobytes("png")
            )

            icon_pixmap = QPixmap.fromImage(image)

            item = QListWidgetItem(
                f"Page {page_index + 1}"
            )
            item.setIcon(
                QIcon(
                    icon_pixmap.scaled(
                        105,
                        145,
                        Qt.AspectRatioMode.KeepAspectRatio,
                        Qt.TransformationMode.SmoothTransformation,
                    )
                )
            )
            item.setTextAlignment(
                Qt.AlignmentFlag.AlignHCenter
            )

            self.thumbnail_list.addItem(item)

        self.thumbnail_list.setCurrentRow(0)
        self.thumbnail_list.blockSignals(False)

    def capture_current_placements(self) -> None:
        if not self.document:
            return

        self.page_placements[
            self.current_page
        ] = self.page_view.serialize_signatures()

    def go_to_page(self, page_index: int) -> None:
        if not self.document:
            return

        page_index = max(
            0,
            min(
                page_index,
                self.document.page_count - 1,
            ),
        )

        if page_index == self.current_page:
            return

        self.capture_current_placements()
        self.current_page = page_index

        self.page_spin.blockSignals(True)
        self.page_spin.setValue(page_index + 1)
        self.page_spin.blockSignals(False)

        self.thumbnail_list.blockSignals(True)
        self.thumbnail_list.setCurrentRow(page_index)
        self.thumbnail_list.blockSignals(False)

        self.load_current_page()

    def load_current_page(self) -> None:
        if not self.document:
            return

        png, point_width, point_height = (
            render_page_png(
                self.document,
                self.current_page,
            )
        )

        stored = self.page_placements.get(
            self.current_page,
            [],
        )

        self.page_view.load_page(
            png,
            point_width,
            point_height,
            stored,
        )

        self.show_current_search_highlights()

    def zoom_in(self) -> None:
        self.page_view.zoom_in()

    def zoom_out(self) -> None:
        self.page_view.zoom_out()

    def fit_width(self) -> None:
        self.page_view.fit_width()

    def draw_signature(self) -> None:
        dialog = SignatureDialog(self)

        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.current_signature_png = dialog.signature_png
            self.signature_status.setText(
                "Drawn signature loaded. "
                "Press Place Signature on Page."
            )

    def import_signature(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Import Signature",
            str(Path.home()),
            "Images (*.png *.jpg *.jpeg *.bmp)",
        )

        if not path:
            return

        try:
            self.current_signature_png = clean_signature_image(
                path
            )
            self.signature_status.setText(
                f"Loaded: {Path(path).name}"
            )
        except Exception as error:
            QMessageBox.warning(
                self,
                "Import Signature",
                str(error),
            )

    def add_signature_to_page(self) -> None:
        if not self.document:
            QMessageBox.information(
                self,
                "Signature",
                "Open a PDF first.",
            )
            return

        if not self.current_signature_png:
            QMessageBox.information(
                self,
                "Signature",
                "Draw or import a signature first.",
            )
            return

        try:
            self.page_view.add_signature(
                self.current_signature_png,
                self.size_slider.value() / 100.0,
            )
        except Exception as error:
            QMessageBox.warning(
                self,
                "Signature",
                str(error),
            )

    def resize_selected_signature(
        self,
        value: int,
    ) -> None:
        self.page_view.resize_selected(value)

    def signature_selection_changed(
        self,
        selected: bool,
    ) -> None:
        self.delete_signature_button.setEnabled(
            selected
        )

    def search_document(self) -> None:
        if not self.document:
            return

        query = self.search_edit.text().strip()

        if not query:
            self.search_results.clear()
            self.search_result_index = -1
            self.load_current_page()
            return

        self.capture_current_placements()
        results: list[tuple[int, list[fitz.Rect]]] = []

        QApplication.setOverrideCursor(
            Qt.CursorShape.WaitCursor
        )

        try:
            for page_index in range(
                self.document.page_count
            ):
                rectangles = self.document.load_page(
                    page_index
                ).search_for(query)

                if rectangles:
                    results.append(
                        (page_index, rectangles)
                    )
        finally:
            QApplication.restoreOverrideCursor()

        self.search_results = results
        self.search_result_index = 0 if results else -1

        if not results:
            self.reader_status.setText(
                f'No results for "{query}".'
            )
            self.load_current_page()
            return

        first_page = results[0][0]

        if first_page == self.current_page:
            self.load_current_page()
        else:
            self.go_to_page(first_page)

        self.reader_status.setText(
            f'Found "{query}" on {len(results)} page(s).'
        )

    def next_search_result(self) -> None:
        if not self.search_results:
            self.search_document()
            return

        self.search_result_index = (
            self.search_result_index + 1
        ) % len(self.search_results)

        page_index = self.search_results[
            self.search_result_index
        ][0]

        if page_index == self.current_page:
            self.show_current_search_highlights()
        else:
            self.go_to_page(page_index)

    def show_current_search_highlights(self) -> None:
        rectangles: list[fitz.Rect] = []

        for page_index, page_rectangles in self.search_results:
            if page_index == self.current_page:
                rectangles.extend(page_rectangles)

        self.page_view.show_search_rectangles(
            rectangles
        )

    def save_signed_pdf(self) -> None:
        if not self.document or not self.document_path:
            QMessageBox.information(
                self,
                "Save Signed PDF",
                "Open a PDF first.",
            )
            return

        self.capture_current_placements()

        placements: list[SignaturePlacement] = []

        if self.apply_all_checkbox.isChecked():
            current = self.page_placements.get(
                self.current_page,
                [],
            )

            for page_index in range(
                self.document.page_count
            ):
                for item in current:
                    placements.append(
                        SignaturePlacement(
                            page_index=page_index,
                            x_fraction=item.x_fraction,
                            y_fraction=item.y_fraction,
                            width_fraction=item.width_fraction,
                            height_fraction=item.height_fraction,
                            image_png=item.image_png,
                        )
                    )
        else:
            for page_index, page_items in (
                self.page_placements.items()
            ):
                for item in page_items:
                    placements.append(
                        SignaturePlacement(
                            page_index=page_index,
                            x_fraction=item.x_fraction,
                            y_fraction=item.y_fraction,
                            width_fraction=item.width_fraction,
                            height_fraction=item.height_fraction,
                            image_png=item.image_png,
                        )
                    )

        if not placements:
            QMessageBox.information(
                self,
                "Save Signed PDF",
                "Place at least one signature on a page.",
            )
            return

        default_path = (
            self.document_path.parent
            / f"{self.document_path.stem}-signed.pdf"
        )

        output, _ = QFileDialog.getSaveFileName(
            self,
            "Save Signed PDF Copy",
            str(default_path),
            "PDF Documents (*.pdf)",
        )

        if not output:
            return

        try:
            QApplication.setOverrideCursor(
                Qt.CursorShape.WaitCursor
            )

            apply_signatures(
                self.document_path,
                Path(output),
                placements,
                self.password,
            )
        except Exception as error:
            QMessageBox.critical(
                self,
                "Save Signed PDF",
                str(error),
            )
            return
        finally:
            QApplication.restoreOverrideCursor()

        QMessageBox.information(
            self,
            "Signed PDF Saved",
            f"Saved successfully:\n{output}",
        )


class WelcomeTab(QWidget):
    open_converter = Signal()
    open_reader = Signal()

    def __init__(self) -> None:
        super().__init__()

        layout = QVBoxLayout(self)
        layout.setContentsMargins(26, 26, 26, 26)
        layout.setSpacing(16)

        title = QLabel("PDF Master Studio")
        title.setObjectName("Title")
        layout.addWidget(title)

        subtitle = QLabel(
            "A private, portable Windows workspace for converting, "
            "reading, searching, and signing PDF documents."
        )
        subtitle.setObjectName("Muted")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        action_grid = QGridLayout()
        action_grid.setSpacing(14)

        convert_card = card()
        convert_layout = QVBoxLayout(convert_card)

        convert_title = QLabel(
            "Batch PDF ↔ Word"
        )
        convert_title.setObjectName("Heading")
        convert_layout.addWidget(convert_title)

        convert_text = QLabel(
            "Convert multiple PDFs to editable DOCX files, "
            "or export multiple Word documents to PDF."
        )
        convert_text.setObjectName("Muted")
        convert_text.setWordWrap(True)
        convert_layout.addWidget(convert_text)

        convert_layout.addStretch(1)

        convert_button = QPushButton(
            "Open Batch Converter"
        )
        convert_button.setObjectName("Primary")
        convert_button.clicked.connect(
            self.open_converter.emit
        )
        convert_layout.addWidget(convert_button)

        action_grid.addWidget(
            convert_card,
            0,
            0,
        )

        sign_card = card()
        sign_layout = QVBoxLayout(sign_card)

        sign_title = QLabel(
            "PDF Reader & Signature Studio"
        )
        sign_title.setObjectName("Heading")
        sign_layout.addWidget(sign_title)

        sign_text = QLabel(
            "Open PDFs like a desktop reader, search text, "
            "draw or import a signature, position it on any page, "
            "and save a signed copy."
        )
        sign_text.setObjectName("Muted")
        sign_text.setWordWrap(True)
        sign_layout.addWidget(sign_text)

        sign_layout.addStretch(1)

        sign_button = QPushButton(
            "Open PDF Studio"
        )
        sign_button.setObjectName("Success")
        sign_button.clicked.connect(
            self.open_reader.emit
        )
        sign_layout.addWidget(sign_button)

        action_grid.addWidget(
            sign_card,
            0,
            1,
        )

        layout.addLayout(action_grid)

        quality_card = card()
        quality_layout = QVBoxLayout(quality_card)

        quality_title = QLabel(
            "Conversion quality"
        )
        quality_title.setObjectName("Heading")
        quality_layout.addWidget(quality_title)

        quality_text = QLabel(
            "For the best editable layout, choose the Microsoft Word "
            "high-fidelity engine on a Windows computer where Word is "
            "already installed. The portable fallback works without Office. "
            "A PDF and a Word document use different layout models, so an "
            "editable result cannot be guaranteed to remain pixel-identical "
            "for every complex form, font, table, or design."
        )
        quality_text.setObjectName("Muted")
        quality_text.setWordWrap(True)
        quality_layout.addWidget(quality_text)

        layout.addWidget(quality_card)
        layout.addStretch(1)


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()

        self.setWindowTitle(
            "PDF Master Studio — Portable"
        )
        self.resize(1380, 850)
        self.setMinimumSize(1080, 680)

        central = QWidget()
        self.setCentralWidget(central)

        layout = QHBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(225)

        sidebar_layout = QVBoxLayout(sidebar)
        sidebar_layout.setContentsMargins(
            18,
            22,
            18,
            22,
        )

        brand = QLabel("PDF\nMASTER")
        brand.setObjectName("Title")
        sidebar_layout.addWidget(brand)

        version = QLabel(
            "STUDIO • PORTABLE"
        )
        version.setObjectName("Accent")
        sidebar_layout.addWidget(version)

        sidebar_layout.addSpacing(24)

        self.home_button = self.navigation_button(
            "⌂  Home",
            0,
        )
        self.convert_button = self.navigation_button(
            "⇄  Batch Converter",
            1,
        )
        self.reader_button = self.navigation_button(
            "✎  PDF Reader & Sign",
            2,
        )

        sidebar_layout.addWidget(self.home_button)
        sidebar_layout.addWidget(
            self.convert_button
        )
        sidebar_layout.addWidget(
            self.reader_button
        )

        sidebar_layout.addStretch(1)

        privacy = QLabel(
            "LOCAL PROCESSING\nNo cloud upload\nNo installer"
        )
        privacy.setObjectName("Muted")
        privacy.setWordWrap(True)
        sidebar_layout.addWidget(privacy)

        layout.addWidget(sidebar)

        self.stack = QStackedWidget()

        self.welcome_tab = WelcomeTab()
        self.converter_tab = ConverterTab()
        self.reader_tab = ReaderSignerTab()

        self.stack.addWidget(self.welcome_tab)
        self.stack.addWidget(self.converter_tab)
        self.stack.addWidget(self.reader_tab)

        self.welcome_tab.open_converter.connect(
            lambda: self.switch_page(1)
        )
        self.welcome_tab.open_reader.connect(
            lambda: self.switch_page(2)
        )

        layout.addWidget(self.stack, 1)
        self.switch_page(0)

    def navigation_button(
        self,
        text: str,
        page: int,
    ) -> QPushButton:
        button = QPushButton(text)
        button.setCheckable(True)
        button.setMinimumHeight(46)
        button.clicked.connect(
            lambda: self.switch_page(page)
        )
        return button

    def switch_page(self, page: int) -> None:
        self.stack.setCurrentIndex(page)

        buttons = [
            self.home_button,
            self.convert_button,
            self.reader_button,
        ]

        for index, button in enumerate(buttons):
            button.setChecked(index == page)
            button.setObjectName(
                "Primary" if index == page else ""
            )
            button.style().unpolish(button)
            button.style().polish(button)

    def closeEvent(self, event) -> None:
        self.reader_tab.close_document()
        event.accept()
