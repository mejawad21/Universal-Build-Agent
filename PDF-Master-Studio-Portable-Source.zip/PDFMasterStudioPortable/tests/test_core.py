from __future__ import annotations

import io
import tempfile
from pathlib import Path

import fitz
from PIL import Image, ImageDraw

from pdfmaster.signing import (
    SignaturePlacement,
    apply_signatures,
    clean_signature_image,
)


def create_signature() -> bytes:
    image = Image.new(
        "RGB",
        (420, 130),
        "white",
    )

    drawing = ImageDraw.Draw(image)
    drawing.line(
        [(20, 90), (95, 30), (160, 100), (245, 25), (390, 85)],
        fill="black",
        width=7,
        joint="curve",
    )

    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    return buffer.getvalue()


def main() -> None:
    with tempfile.TemporaryDirectory(
        prefix="pdf-master-test-"
    ) as directory:
        root = Path(directory)
        source = root / "source.pdf"
        output = root / "signed.pdf"

        document = fitz.open()
        page = document.new_page(
            width=595,
            height=842,
        )
        page.insert_text(
            (72, 90),
            "PDF Master Studio validation document",
            fontsize=16,
        )
        document.save(source)
        document.close()

        signature = clean_signature_image(
            create_signature()
        )

        apply_signatures(
            source,
            output,
            [
                SignaturePlacement(
                    page_index=0,
                    x_fraction=0.55,
                    y_fraction=0.72,
                    width_fraction=0.30,
                    height_fraction=0.08,
                    image_png=signature,
                )
            ],
        )

        assert output.exists()
        assert output.stat().st_size > source.stat().st_size

        signed = fitz.open(output)
        assert signed.page_count == 1
        assert (
            "PDF Master Studio validation document"
            in signed[0].get_text()
        )
        assert len(signed[0].get_images(full=True)) >= 1
        signed.close()

    print("CORE SIGNING AND DOCUMENT-PRESERVATION TESTS PASSED")


if __name__ == "__main__":
    main()
