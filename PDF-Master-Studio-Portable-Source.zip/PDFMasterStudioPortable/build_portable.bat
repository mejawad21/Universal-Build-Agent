@echo off
setlocal
cd /d "%~dp0"

echo ==========================================
echo  PDF Master Studio - Portable EXE Builder
echo ==========================================

where py >nul 2>nul
if errorlevel 1 (
    echo Python was not found.
    echo Install Python 3.11 and run this file again.
    pause
    exit /b 1
)

py -3.11 -m venv .build-venv
if errorlevel 1 goto :failed

call .build-venv\Scripts\activate.bat
python -m pip install --upgrade pip
if errorlevel 1 goto :failed

pip install -r requirements.txt
if errorlevel 1 goto :failed

pyinstaller --noconfirm --clean PDFMasterStudio.spec
if errorlevel 1 goto :failed

echo.
echo BUILD COMPLETE
echo The portable application is in:
echo dist\PDF Master Studio Portable.exe
echo.
pause
exit /b 0

:failed
echo.
echo BUILD FAILED
echo Read the error above.
pause
exit /b 1
