# ChargePulse Pro

Premium offline Android charging-current meter.

## Features
- Live battery current in mA.
- Estimated battery-side charging power in watts.
- Voltage, battery level, temperature, charging source and health.
- Android-reported average current when available.
- 60-second live graph.
- Session average, peak and timer.
- Copy measurement snapshot.
- Optional keep-screen-awake mode.
- No Internet or storage permissions.

## Important
Android exposes charging current only when the phone manufacturer provides the
hardware value. On unsupported devices, the app clearly reports that the current
sensor is unavailable. Estimated watts are battery current multiplied by battery
voltage, so this can differ from the charger's advertised input rating.
