package com.chargepulse.pro;

import java.util.Locale;

final class ChargingMath {
    private ChargingMath() {
    }

    static float normalizeCurrentMa(long currentMicroAmps, boolean charging) {
        if (currentMicroAmps == Long.MIN_VALUE) {
            return Float.NaN;
        }
        float magnitude = Math.abs(currentMicroAmps / 1000f);
        return charging ? magnitude : -magnitude;
    }

    static float estimatePowerWatts(float currentMa, float voltageVolts) {
        if (Float.isNaN(currentMa) || Float.isNaN(voltageVolts) || voltageVolts <= 0f) {
            return Float.NaN;
        }
        return Math.abs(currentMa) * voltageVolts / 1000f;
    }

    static String speedLabel(float watts, boolean charging) {
        if (!charging) return "Not charging";
        if (Float.isNaN(watts)) return "Current unavailable";
        if (watts >= 15f) return "Very fast";
        if (watts >= 8f) return "Fast";
        if (watts >= 3f) return "Normal";
        return "Slow / trickle";
    }

    static String formatCurrent(float currentMa) {
        if (Float.isNaN(currentMa)) return "—";
        return String.format(Locale.US, "%,.0f", Math.abs(currentMa));
    }

    static String formatDuration(long elapsedMillis) {
        long totalSeconds = Math.max(0L, elapsedMillis / 1000L);
        long hours = totalSeconds / 3600L;
        long minutes = (totalSeconds % 3600L) / 60L;
        long seconds = totalSeconds % 60L;
        if (hours > 0L) {
            return String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds);
        }
        return String.format(Locale.US, "%02d:%02d", minutes, seconds);
    }
}
