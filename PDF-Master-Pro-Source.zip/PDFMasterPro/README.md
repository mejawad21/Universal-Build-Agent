# PDF Master Pro

A focused Android app for two tasks:

1. Open a PDF, draw or import a signature, drag and resize it on any page, and
   save a signed PDF while preserving the original PDF page content.
2. Convert a PDF to a genuine editable DOCX document. Embedded text is extracted
   directly. Scanned pages are processed with bundled offline OCR and written as
   editable Word text instead of page screenshots.

## Privacy

- No Internet permission.
- No broad storage permission.
- Uses Android's system document picker.
- Conversion and signing are performed on the phone.

## Conversion behavior

- Normal text PDF: direct text extraction.
- Scanned/image PDF: bundled ML Kit Latin-script OCR.
- Force OCR mode: OCR every selected page.
- Page ranges and password-protected PDFs are supported.
- Output is editable OOXML/DOCX text with page breaks and basic heading/list
  reconstruction.

Text-based PDFs can retain Unicode text provided the PDF contains usable text
mapping. Offline OCR is optimized for Latin script. Complex tables, unusual
fonts, handwriting, and highly designed layouts may require manual cleanup in
Word.

## Signature behavior

The app adds a visual electronic signature image as a new PDF content layer.
It is not a certificate-based cryptographic digital signature.

## Build

Upload this project ZIP to the existing Auto Build Agent. Download the
`READY-APK` artifact only after the Android job finishes with a green check.
