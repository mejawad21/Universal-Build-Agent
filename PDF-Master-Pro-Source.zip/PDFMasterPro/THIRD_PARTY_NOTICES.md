# Third-party notices

- PdfBox-Android 2.0.27.0 — Apache License 2.0
- Google ML Kit Text Recognition 16.0.1 — Google ML Kit terms and bundled model
- AndroidX and Material Components — Apache License 2.0

The generated DOCX format is Office Open XML.
