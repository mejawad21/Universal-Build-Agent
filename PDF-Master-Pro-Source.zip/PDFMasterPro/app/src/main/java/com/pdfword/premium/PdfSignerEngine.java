package com.pdfword.premium;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.util.SparseArray;

import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.pdmodel.PDPage;
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream;
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle;
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory;
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject;
import com.tom_roush.pdfbox.util.Matrix;

import java.io.File;
import java.io.OutputStream;

final class PdfSignerEngine {
    private PdfSignerEngine() {
    }

    static void saveSignedPdf(
            Context context,
            File sourceFile,
            Uri destination,
            Bitmap signatureBitmap,
            SparseArray<SignaturePlacement> placements
    ) throws Exception {
        if (signatureBitmap == null || signatureBitmap.isRecycled()) {
            throw new IllegalStateException("Draw or import a signature first.");
        }
        if (placements == null || placements.size() == 0) {
            throw new IllegalStateException("Place the signature on at least one page.");
        }

        try (PDDocument document = PDDocument.load(sourceFile)) {
            PDImageXObject image = LosslessFactory.createFromImage(
                    document,
                    signatureBitmap
            );

            for (int index = 0; index < placements.size(); index++) {
                int pageIndex = placements.keyAt(index);
                if (pageIndex < 0 || pageIndex >= document.getNumberOfPages()) {
                    continue;
                }
                SignaturePlacement placement = placements.valueAt(index);
                if (placement == null) {
                    continue;
                }
                addSignature(
                        document,
                        document.getPage(pageIndex),
                        image,
                        placement
                );
            }

            ContentResolver resolver = context.getContentResolver();
            try (OutputStream output = resolver.openOutputStream(destination, "w")) {
                if (output == null) {
                    throw new IllegalStateException("Could not create the signed PDF.");
                }
                document.save(output);
            }
        }
    }

    private static void addSignature(
            PDDocument document,
            PDPage page,
            PDImageXObject image,
            SignaturePlacement placement
    ) throws Exception {
        PDRectangle box = page.getCropBox();
        float pageWidth = box.getWidth();
        float pageHeight = box.getHeight();
        int rotation = ((page.getRotation() % 360) + 360) % 360;

        float displayWidth = rotation == 90 || rotation == 270
                ? pageHeight
                : pageWidth;
        float displayHeight = rotation == 90 || rotation == 270
                ? pageWidth
                : pageHeight;

        float x = placement.left * displayWidth;
        float y = (1f - placement.top - placement.height) * displayHeight;
        float width = placement.width * displayWidth;
        float height = placement.height * displayHeight;

        Matrix transform = displayToPdfTransform(
                rotation,
                pageWidth,
                pageHeight,
                box.getLowerLeftX(),
                box.getLowerLeftY()
        );

        try (PDPageContentStream stream = new PDPageContentStream(
                document,
                page,
                PDPageContentStream.AppendMode.APPEND,
                true,
                true
        )) {
            stream.transform(transform);
            stream.drawImage(image, x, y, width, height);
        }
    }

    private static Matrix displayToPdfTransform(
            int rotation,
            float width,
            float height,
            float offsetX,
            float offsetY
    ) {
        switch (rotation) {
            case 90:
                return new Matrix(
                        0f,
                        1f,
                        -1f,
                        0f,
                        width + offsetX,
                        offsetY
                );
            case 180:
                return new Matrix(
                        -1f,
                        0f,
                        0f,
                        -1f,
                        width + offsetX,
                        height + offsetY
                );
            case 270:
                return new Matrix(
                        0f,
                        -1f,
                        1f,
                        0f,
                        offsetX,
                        height + offsetY
                );
            default:
                return new Matrix(
                        1f,
                        0f,
                        0f,
                        1f,
                        offsetX,
                        offsetY
                );
        }
    }
}
