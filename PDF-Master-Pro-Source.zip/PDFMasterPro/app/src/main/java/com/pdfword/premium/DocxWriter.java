package com.pdfword.premium;

import android.graphics.Bitmap;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

final class DocxWriter {
    static final class PageContent {
        enum Type {
            TEXT,
            IMAGE
        }

        final Type type;
        final int sourcePageNumber;
        final List<String> paragraphs;
        final File imageFile;
        final int imageWidth;
        final int imageHeight;

        private PageContent(
                Type type,
                int sourcePageNumber,
                List<String> paragraphs,
                File imageFile,
                int imageWidth,
                int imageHeight
        ) {
            this.type = type;
            this.sourcePageNumber = sourcePageNumber;
            this.paragraphs = paragraphs;
            this.imageFile = imageFile;
            this.imageWidth = imageWidth;
            this.imageHeight = imageHeight;
        }

        static PageContent text(int sourcePageNumber, List<String> paragraphs) {
            return new PageContent(
                    Type.TEXT,
                    sourcePageNumber,
                    paragraphs,
                    null,
                    0,
                    0
            );
        }

        static PageContent image(
                int sourcePageNumber,
                File imageFile,
                int imageWidth,
                int imageHeight
        ) {
            return new PageContent(
                    Type.IMAGE,
                    sourcePageNumber,
                    new ArrayList<>(),
                    imageFile,
                    imageWidth,
                    imageHeight
            );
        }
    }

    private static final long EMU_PER_INCH = 914400L;
    private static final long MAX_IMAGE_WIDTH_EMU = Math.round(7.25 * EMU_PER_INCH);
    private static final long MAX_IMAGE_HEIGHT_EMU = Math.round(10.0 * EMU_PER_INCH);

    private DocxWriter() {
    }

    static void write(
            File destination,
            String documentTitle,
            List<PageContent> pages
    ) throws IOException {
        StringBuilder documentBody = new StringBuilder();
        StringBuilder relationships = new StringBuilder();
        relationships.append(
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
        );
        relationships.append(
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
        );
        relationships.append(
                "<Relationship Id=\"rIdStyles\" "
                        + "Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" "
                        + "Target=\"styles.xml\"/>"
        );
        relationships.append(
                "<Relationship Id=\"rIdSettings\" "
                        + "Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings\" "
                        + "Target=\"settings.xml\"/>"
        );
        relationships.append(
                "<Relationship Id=\"rIdFonts\" "
                        + "Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/fontTable\" "
                        + "Target=\"fontTable.xml\"/>"
        );

        List<PageContent> imagePages = new ArrayList<>();
        int imageRelationshipIndex = 1;
        int drawingId = 1;

        for (int index = 0; index < pages.size(); index++) {
            PageContent page = pages.get(index);

            if (page.type == PageContent.Type.TEXT) {
                appendTextPage(documentBody, page);
            } else {
                String relationshipId = "rIdImage" + imageRelationshipIndex;
                String imageName = "image" + imageRelationshipIndex + ".jpg";

                relationships.append(
                        "<Relationship Id=\"" + relationshipId + "\" "
                                + "Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" "
                                + "Target=\"media/" + imageName + "\"/>"
                );

                appendImagePage(
                        documentBody,
                        page,
                        relationshipId,
                        drawingId
                );
                imagePages.add(page);
                imageRelationshipIndex++;
                drawingId++;
            }

            if (index + 1 < pages.size()) {
                documentBody.append(
                        "<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>"
                );
            }
        }

        documentBody.append(
                "<w:sectPr>"
                        + "<w:pgSz w:w=\"11906\" w:h=\"16838\"/>"
                        + "<w:pgMar w:top=\"720\" w:right=\"720\" "
                        + "w:bottom=\"720\" w:left=\"720\" "
                        + "w:header=\"360\" w:footer=\"360\" w:gutter=\"0\"/>"
                        + "</w:sectPr>"
        );
        relationships.append("</Relationships>");

        try (ZipOutputStream zip = new ZipOutputStream(
                new FileOutputStream(destination)
        )) {
            putText(zip, "[Content_Types].xml", contentTypesXml());
            putText(zip, "_rels/.rels", rootRelationshipsXml());
            putText(
                    zip,
                    "docProps/core.xml",
                    corePropertiesXml(documentTitle)
            );
            putText(zip, "docProps/app.xml", appPropertiesXml());
            putText(
                    zip,
                    "word/document.xml",
                    documentXml(documentBody.toString())
            );
            putText(
                    zip,
                    "word/_rels/document.xml.rels",
                    relationships.toString()
            );
            putText(zip, "word/styles.xml", stylesXml());
            putText(zip, "word/settings.xml", settingsXml());
            putText(zip, "word/fontTable.xml", fontTableXml());

            for (int index = 0; index < imagePages.size(); index++) {
                PageContent imagePage = imagePages.get(index);
                putFile(
                        zip,
                        "word/media/image" + (index + 1) + ".jpg",
                        imagePage.imageFile
                );
            }
        }
    }

    private static void appendTextPage(
            StringBuilder output,
            PageContent page
    ) {
        if (page.paragraphs.isEmpty()) {
            output.append(
                    "<w:p><w:r><w:t>[No editable text detected on page "
                            + page.sourcePageNumber
                            + "]</w:t></w:r></w:p>"
            );
            return;
        }

        int index = 0;
        while (index < page.paragraphs.size()) {
            String rawParagraph = page.paragraphs.get(index);
            String paragraph = rawParagraph == null ? "" : rawParagraph.trim();

            if (paragraph.contains("\t")) {
                List<String> rows = new ArrayList<>();
                while (index < page.paragraphs.size()) {
                    String candidate = page.paragraphs.get(index);
                    candidate = candidate == null ? "" : candidate.trim();
                    if (!candidate.contains("\t")) {
                        break;
                    }
                    rows.add(candidate);
                    index++;
                }
                appendEditableTable(output, rows);
                continue;
            }

            if (paragraph.isEmpty()) {
                output.append("<w:p/>");
                index++;
                continue;
            }

            boolean heading = looksLikeHeading(paragraph);
            output.append("<w:p>");

            if (heading) {
                output.append(
                        "<w:pPr><w:pStyle w:val=\"Heading1\"/>"
                                + "<w:keepNext/></w:pPr>"
                );
            } else {
                output.append(
                        "<w:pPr><w:spacing w:after=\"90\" "
                                + "w:line=\"276\" w:lineRule=\"auto\"/></w:pPr>"
                );
            }

            output.append("<w:r><w:t xml:space=\"preserve\">");
            output.append(escapeXml(paragraph));
            output.append("</w:t></w:r></w:p>");
            index++;
        }
    }

    private static void appendEditableTable(
            StringBuilder output,
            List<String> rows
    ) {
        if (rows.isEmpty()) {
            return;
        }

        int columns = 1;
        for (String row : rows) {
            columns = Math.max(columns, row.split("\\t+", -1).length);
        }

        output.append(
                "<w:tbl>"
                        + "<w:tblPr>"
                        + "<w:tblW w:w=\"0\" w:type=\"auto\"/>"
                        + "<w:tblBorders>"
                        + "<w:top w:val=\"single\" w:sz=\"4\" w:color=\"B8C2CC\"/>"
                        + "<w:left w:val=\"single\" w:sz=\"4\" w:color=\"B8C2CC\"/>"
                        + "<w:bottom w:val=\"single\" w:sz=\"4\" w:color=\"B8C2CC\"/>"
                        + "<w:right w:val=\"single\" w:sz=\"4\" w:color=\"B8C2CC\"/>"
                        + "<w:insideH w:val=\"single\" w:sz=\"3\" w:color=\"D5DCE3\"/>"
                        + "<w:insideV w:val=\"single\" w:sz=\"3\" w:color=\"D5DCE3\"/>"
                        + "</w:tblBorders>"
                        + "</w:tblPr>"
        );

        output.append("<w:tblGrid>");
        for (int column = 0; column < columns; column++) {
            output.append("<w:gridCol w:w=\"2400\"/>");
        }
        output.append("</w:tblGrid>");

        for (int rowIndex = 0; rowIndex < rows.size(); rowIndex++) {
            String[] cells = rows.get(rowIndex).split("\\t+", -1);
            output.append("<w:tr>");
            for (int column = 0; column < columns; column++) {
                String cell = column < cells.length ? cells[column].trim() : "";
                output.append("<w:tc><w:tcPr><w:tcW w:w=\"2400\" w:type=\"dxa\"/>");
                if (rowIndex == 0) {
                    output.append("<w:shd w:fill=\"EDE9FE\"/>");
                }
                output.append("</w:tcPr><w:p><w:r>");
                if (rowIndex == 0) {
                    output.append("<w:rPr><w:b/></w:rPr>");
                }
                output.append("<w:t xml:space=\"preserve\">");
                output.append(escapeXml(cell));
                output.append("</w:t></w:r></w:p></w:tc>");
            }
            output.append("</w:tr>");
        }

        output.append("</w:tbl><w:p/>");
    }

    private static boolean looksLikeHeading(String value) {
        if (value.length() < 3 || value.length() > 90) {
            return false;
        }

        int letters = 0;
        int upper = 0;
        for (int index = 0; index < value.length(); index++) {
            char character = value.charAt(index);
            if (Character.isLetter(character)) {
                letters++;
                if (Character.isUpperCase(character)) {
                    upper++;
                }
            }
        }

        boolean mostlyUppercase = letters >= 3 && upper >= Math.ceil(letters * 0.78);
        boolean titleLike = value.length() <= 55
                && !value.endsWith(".")
                && !value.endsWith(",")
                && !value.endsWith(";");

        return mostlyUppercase || titleLike;
    }

    private static void appendImagePage(
            StringBuilder output,
            PageContent page,
            String relationshipId,
            int drawingId
    ) {
        long[] dimensions = fitImage(
                page.imageWidth,
                page.imageHeight
        );
        long width = dimensions[0];
        long height = dimensions[1];

        output.append("<w:p>");
        output.append("<w:pPr><w:jc w:val=\"center\"/></w:pPr>");
        output.append("<w:r><w:drawing>");
        output.append(
                "<wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\">"
        );
        output.append(
                "<wp:extent cx=\"" + width + "\" cy=\"" + height + "\"/>"
        );
        output.append(
                "<wp:effectExtent l=\"0\" t=\"0\" r=\"0\" b=\"0\"/>"
        );
        output.append(
                "<wp:docPr id=\"" + drawingId + "\" "
                        + "name=\"PDF page " + page.sourcePageNumber + "\"/>"
        );
        output.append(
                "<wp:cNvGraphicFramePr>"
                        + "<a:graphicFrameLocks noChangeAspect=\"1\"/>"
                        + "</wp:cNvGraphicFramePr>"
        );
        output.append("<a:graphic>");
        output.append(
                "<a:graphicData "
                        + "uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">"
        );
        output.append("<pic:pic>");
        output.append(
                "<pic:nvPicPr>"
                        + "<pic:cNvPr id=\"" + drawingId + "\" "
                        + "name=\"PDF page " + page.sourcePageNumber + "\"/>"
                        + "<pic:cNvPicPr/>"
                        + "</pic:nvPicPr>"
        );
        output.append(
                "<pic:blipFill>"
                        + "<a:blip r:embed=\"" + relationshipId + "\"/>"
                        + "<a:stretch><a:fillRect/></a:stretch>"
                        + "</pic:blipFill>"
        );
        output.append(
                "<pic:spPr>"
                        + "<a:xfrm>"
                        + "<a:off x=\"0\" y=\"0\"/>"
                        + "<a:ext cx=\"" + width + "\" cy=\"" + height + "\"/>"
                        + "</a:xfrm>"
                        + "<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom>"
                        + "</pic:spPr>"
        );
        output.append("</pic:pic>");
        output.append("</a:graphicData>");
        output.append("</a:graphic>");
        output.append("</wp:inline>");
        output.append("</w:drawing></w:r></w:p>");
    }

    private static long[] fitImage(int pixelWidth, int pixelHeight) {
        double safeWidth = Math.max(1, pixelWidth);
        double safeHeight = Math.max(1, pixelHeight);
        double scale = Math.min(
                MAX_IMAGE_WIDTH_EMU / safeWidth,
                MAX_IMAGE_HEIGHT_EMU / safeHeight
        );

        long width = Math.max(1L, Math.round(safeWidth * scale));
        long height = Math.max(1L, Math.round(safeHeight * scale));
        return new long[]{width, height};
    }

    private static String documentXml(String body) {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<w:document "
                + "xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" "
                + "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" "
                + "xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" "
                + "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" "
                + "xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">"
                + "<w:body>" + body + "</w:body></w:document>";
    }

    private static String contentTypesXml() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                + "<Default Extension=\"jpg\" ContentType=\"image/jpeg\"/>"
                + "<Override PartName=\"/word/document.xml\" "
                + "ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>"
                + "<Override PartName=\"/word/styles.xml\" "
                + "ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml\"/>"
                + "<Override PartName=\"/word/settings.xml\" "
                + "ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml\"/>"
                + "<Override PartName=\"/word/fontTable.xml\" "
                + "ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.fontTable+xml\"/>"
                + "<Override PartName=\"/docProps/core.xml\" "
                + "ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/>"
                + "<Override PartName=\"/docProps/app.xml\" "
                + "ContentType=\"application/vnd.openxmlformats-officedocument.extended-properties+xml\"/>"
                + "</Types>";
    }

    private static String rootRelationshipsXml() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                + "<Relationship Id=\"rId1\" "
                + "Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" "
                + "Target=\"word/document.xml\"/>"
                + "<Relationship Id=\"rId2\" "
                + "Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" "
                + "Target=\"docProps/core.xml\"/>"
                + "<Relationship Id=\"rId3\" "
                + "Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties\" "
                + "Target=\"docProps/app.xml\"/>"
                + "</Relationships>";
    }

    private static String corePropertiesXml(String title) {
        SimpleDateFormat timestampFormat = new SimpleDateFormat(
                "yyyy-MM-dd'T'HH:mm:ss'Z'",
                Locale.US
        );
        timestampFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        String timestamp = timestampFormat.format(new Date());
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<cp:coreProperties "
                + "xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" "
                + "xmlns:dc=\"http://purl.org/dc/elements/1.1/\" "
                + "xmlns:dcterms=\"http://purl.org/dc/terms/\" "
                + "xmlns:dcmitype=\"http://purl.org/dc/dcmitype/\" "
                + "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
                + "<dc:title>" + escapeXml(title) + "</dc:title>"
                + "<dc:creator>PDF to Word Premium</dc:creator>"
                + "<cp:lastModifiedBy>PDF to Word Premium</cp:lastModifiedBy>"
                + "<dcterms:created xsi:type=\"dcterms:W3CDTF\">"
                + timestamp
                + "</dcterms:created>"
                + "<dcterms:modified xsi:type=\"dcterms:W3CDTF\">"
                + timestamp
                + "</dcterms:modified>"
                + "</cp:coreProperties>";
    }

    private static String appPropertiesXml() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Properties "
                + "xmlns=\"http://schemas.openxmlformats.org/officeDocument/2006/extended-properties\" "
                + "xmlns:vt=\"http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes\">"
                + "<Application>PDF to Word Premium</Application>"
                + "<AppVersion>1.0</AppVersion>"
                + "</Properties>";
    }

    private static String stylesXml() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<w:styles xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">"
                + "<w:docDefaults>"
                + "<w:rPrDefault><w:rPr>"
                + "<w:rFonts w:ascii=\"Calibri\" w:hAnsi=\"Calibri\" "
                + "w:eastAsia=\"Calibri\" w:cs=\"Calibri\"/>"
                + "<w:sz w:val=\"22\"/><w:szCs w:val=\"22\"/>"
                + "</w:rPr></w:rPrDefault>"
                + "<w:pPrDefault><w:pPr>"
                + "<w:spacing w:after=\"90\" w:line=\"276\" w:lineRule=\"auto\"/>"
                + "</w:pPr></w:pPrDefault>"
                + "</w:docDefaults>"
                + "<w:style w:type=\"paragraph\" w:default=\"1\" w:styleId=\"Normal\">"
                + "<w:name w:val=\"Normal\"/><w:qFormat/>"
                + "</w:style>"
                + "<w:style w:type=\"paragraph\" w:styleId=\"Heading1\">"
                + "<w:name w:val=\"Heading 1\"/>"
                + "<w:basedOn w:val=\"Normal\"/>"
                + "<w:next w:val=\"Normal\"/>"
                + "<w:qFormat/>"
                + "<w:pPr><w:keepNext/><w:spacing w:before=\"180\" w:after=\"100\"/></w:pPr>"
                + "<w:rPr><w:b/><w:color w:val=\"3730A3\"/><w:sz w:val=\"30\"/></w:rPr>"
                + "</w:style>"
                + "</w:styles>";
    }

    private static String settingsXml() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<w:settings xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">"
                + "<w:zoom w:percent=\"100\"/>"
                + "<w:defaultTabStop w:val=\"720\"/>"
                + "<w:compat/>"
                + "</w:settings>";
    }

    private static String fontTableXml() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<w:fonts xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">"
                + "<w:font w:name=\"Calibri\"><w:family w:val=\"swiss\"/></w:font>"
                + "</w:fonts>";
    }

    private static void putText(
            ZipOutputStream zip,
            String path,
            String text
    ) throws IOException {
        ZipEntry entry = new ZipEntry(path);
        zip.putNextEntry(entry);
        zip.write(text.getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
    }

    private static void putFile(
            ZipOutputStream zip,
            String path,
            File file
    ) throws IOException {
        ZipEntry entry = new ZipEntry(path);
        zip.putNextEntry(entry);

        try (BufferedInputStream input = new BufferedInputStream(
                new FileInputStream(file)
        )) {
            byte[] buffer = new byte[32 * 1024];
            int read;
            while ((read = input.read(buffer)) != -1) {
                zip.write(buffer, 0, read);
            }
        }

        zip.closeEntry();
    }

    private static String escapeXml(String value) {
        if (value == null) {
            return "";
        }

        StringBuilder escaped = new StringBuilder(value.length() + 16);
        for (int index = 0; index < value.length(); index++) {
            char character = value.charAt(index);
            switch (character) {
                case '&':
                    escaped.append("&amp;");
                    break;
                case '<':
                    escaped.append("&lt;");
                    break;
                case '>':
                    escaped.append("&gt;");
                    break;
                case '"':
                    escaped.append("&quot;");
                    break;
                case '\'':
                    escaped.append("&apos;");
                    break;
                default:
                    if (character == '\t'
                            || character == '\n'
                            || character == '\r'
                            || character >= 0x20) {
                        escaped.append(character);
                    }
                    break;
            }
        }
        return escaped.toString();
    }
}
