package com.pdfword.premium;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;

public final class SignatureOverlayView extends View {
    interface Listener {
        void onPlacementChanged(SignaturePlacement placement);
    }

    private final Paint bitmapPaint = new Paint(
            Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG
    );
    private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint handlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF actualRect = new RectF();

    private Bitmap signature;
    private SignaturePlacement placement;
    private Listener listener;
    private float downX;
    private float downY;
    private float originalLeft;
    private float originalTop;
    private float originalWidth;
    private float originalHeight;
    private boolean resizing;
    private boolean dragging;

    public SignatureOverlayView(Context context) {
        super(context);
        initialize();
    }

    public SignatureOverlayView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initialize();
    }

    private void initialize() {
        setBackgroundColor(Color.TRANSPARENT);
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(dp(2));
        borderPaint.setColor(Color.rgb(37, 99, 235));
        handlePaint.setStyle(Paint.Style.FILL);
        handlePaint.setColor(Color.rgb(37, 99, 235));
    }

    void setListener(Listener listener) {
        this.listener = listener;
    }

    void setSignature(Bitmap bitmap, SignaturePlacement value) {
        signature = bitmap;
        placement = value == null ? null : value.copy();
        invalidate();
    }

    SignaturePlacement getPlacement() {
        return placement == null ? null : placement.copy();
    }

    void clearPlacement() {
        placement = null;
        invalidate();
        notifyChanged();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (signature == null || signature.isRecycled() || placement == null) {
            return;
        }

        actualRect.set(
                placement.left * getWidth(),
                placement.top * getHeight(),
                (placement.left + placement.width) * getWidth(),
                (placement.top + placement.height) * getHeight()
        );

        canvas.drawBitmap(signature, null, actualRect, bitmapPaint);
        canvas.drawRoundRect(actualRect, dp(5), dp(5), borderPaint);
        canvas.drawCircle(
                actualRect.right,
                actualRect.bottom,
                dp(10),
                handlePaint
        );
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (signature == null || placement == null) {
            return false;
        }

        float x = event.getX();
        float y = event.getY();
        float handleRadius = dp(24);

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                updateActualRect();
                downX = x;
                downY = y;
                originalLeft = placement.left;
                originalTop = placement.top;
                originalWidth = placement.width;
                originalHeight = placement.height;

                resizing = distance(
                        x,
                        y,
                        actualRect.right,
                        actualRect.bottom
                ) <= handleRadius;
                dragging = !resizing && actualRect.contains(x, y);

                if (!resizing && !dragging) {
                    placement.left = x / Math.max(1f, getWidth())
                            - placement.width / 2f;
                    placement.top = y / Math.max(1f, getHeight())
                            - placement.height / 2f;
                    placement.clamp();
                    dragging = true;
                    originalLeft = placement.left;
                    originalTop = placement.top;
                    downX = x;
                    downY = y;
                    invalidate();
                    notifyChanged();
                }
                return true;

            case MotionEvent.ACTION_MOVE:
                if (resizing) {
                    float deltaWidth = (x - downX)
                            / Math.max(1f, getWidth());
                    float proposedWidth = originalWidth + deltaWidth;
                    float aspect = signature.getHeight()
                            / Math.max(1f, signature.getWidth());
                    float pageAspect = getWidth()
                            / Math.max(1f, getHeight());
                    placement.width = proposedWidth;
                    placement.height = proposedWidth
                            * aspect
                            * pageAspect;
                    placement.clamp();
                    invalidate();
                    notifyChanged();
                    return true;
                }

                if (dragging) {
                    placement.left = originalLeft
                            + (x - downX) / Math.max(1f, getWidth());
                    placement.top = originalTop
                            + (y - downY) / Math.max(1f, getHeight());
                    placement.clamp();
                    invalidate();
                    notifyChanged();
                    return true;
                }
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                resizing = false;
                dragging = false;
                notifyChanged();
                return true;

            default:
                return true;
        }
    }

    private void updateActualRect() {
        actualRect.set(
                placement.left * getWidth(),
                placement.top * getHeight(),
                (placement.left + placement.width) * getWidth(),
                (placement.top + placement.height) * getHeight()
        );
    }

    private void notifyChanged() {
        if (listener != null && placement != null) {
            listener.onPlacementChanged(placement.copy());
        }
    }

    private static float distance(
            float x1,
            float y1,
            float x2,
            float y2
    ) {
        float dx = x1 - x2;
        float dy = y1 - y2;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private float dp(int value) {
        return value * getResources().getDisplayMetrics().density;
    }
}
