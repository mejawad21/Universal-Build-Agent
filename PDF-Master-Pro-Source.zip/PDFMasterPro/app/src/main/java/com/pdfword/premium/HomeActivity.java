package com.pdfword.premium;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;

public final class HomeActivity extends AppCompatActivity {
    private ActivityResultLauncher<String[]> openForSigning;
    private ActivityResultLauncher<String[]> openForConversion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        PDFBoxResourceLoader.init(getApplicationContext());
        registerLaunchers();
        setContentView(R.layout.activity_home);

        findViewById(R.id.btnOpenSigner).setOnClickListener(view ->
                openForSigning.launch(new String[]{"application/pdf"})
        );
        findViewById(R.id.btnOpenConverter).setOnClickListener(view ->
                openForConversion.launch(new String[]{"application/pdf"})
        );

        Uri incoming = getIntent() == null ? null : getIntent().getData();
        if (incoming != null) {
            openActivity(SignerActivity.class, incoming);
        }
    }

    private void registerLaunchers() {
        openForSigning = registerForActivityResult(
                new ActivityResultContracts.OpenDocument(),
                uri -> {
                    if (uri != null) {
                        persistRead(uri);
                        openActivity(SignerActivity.class, uri);
                    }
                }
        );

        openForConversion = registerForActivityResult(
                new ActivityResultContracts.OpenDocument(),
                uri -> {
                    if (uri != null) {
                        persistRead(uri);
                        openActivity(ConvertActivity.class, uri);
                    }
                }
        );
    }

    private void openActivity(Class<?> activityClass, Uri uri) {
        Intent intent = new Intent(this, activityClass);
        intent.setData(uri);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(intent);
    }

    private void persistRead(Uri uri) {
        try {
            getContentResolver().takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
            );
        } catch (SecurityException ignored) {
            // Temporary access remains valid for this operation.
        }
    }
}
