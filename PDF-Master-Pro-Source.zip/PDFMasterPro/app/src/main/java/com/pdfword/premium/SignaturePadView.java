package com.pdfword.premium;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;

public final class SignaturePadView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path currentPath = new Path();
    private Bitmap inkBitmap;
    private Canvas inkCanvas;
    private boolean hasInk;

    public SignaturePadView(Context context) {
        super(context);
        initialize();
    }

    public SignaturePadView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initialize();
    }

    private void initialize() {
        paint.setColor(Color.rgb(15, 23, 42));
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(4));
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        setBackgroundColor(Color.WHITE);
    }

    @Override
    protected void onSizeChanged(int width, int height, int oldWidth, int oldHeight) {
        if (width <= 0 || height <= 0) {
            return;
        }
        inkBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        inkCanvas = new Canvas(inkBitmap);
        currentPath.reset();
        hasInk = false;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (inkBitmap != null) {
            canvas.drawBitmap(inkBitmap, 0f, 0f, null);
        }
        canvas.drawPath(currentPath, paint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                currentPath.moveTo(x, y);
                return true;
            case MotionEvent.ACTION_MOVE:
                currentPath.lineTo(x, y);
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                currentPath.lineTo(x, y);
                if (inkCanvas != null) {
                    inkCanvas.drawPath(currentPath, paint);
                }
                currentPath.reset();
                hasInk = true;
                invalidate();
                return true;
            default:
                return true;
        }
    }

    boolean hasInk() {
        return hasInk;
    }

    void clearPad() {
        if (inkBitmap != null) {
            inkBitmap.eraseColor(Color.TRANSPARENT);
        }
        currentPath.reset();
        hasInk = false;
        invalidate();
    }

    Bitmap createSignatureBitmap() {
        if (!hasInk || inkBitmap == null) {
            return null;
        }
        return BitmapUtils.trimTransparent(inkBitmap);
    }

    private float dp(int value) {
        return value * getResources().getDisplayMetrics().density;
    }
}
