package com.pdfword.premium;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.rendering.ImageType;
import com.tom_roush.pdfbox.rendering.PDFRenderer;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CancellationException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

final class PdfToWordConverter {
    interface Callback {
        void onProgress(int percent, String message);
    }

    static final class Result {
        final int convertedPages;
        final int textPages;
        final int ocrPages;

        Result(int convertedPages, int textPages, int ocrPages) {
            this.convertedPages = convertedPages;
            this.textPages = textPages;
            this.ocrPages = ocrPages;
        }
    }

    private PdfToWordConverter() {
    }

    static Result convert(
            Context context,
            Uri sourceUri,
            Uri destinationUri,
            String sourceName,
            ConversionOptions options,
            AtomicBoolean cancellation,
            Callback callback
    ) throws Exception {
        File jobDirectory = new File(
                context.getCacheDir(),
                "pdf-master-word-" + System.currentTimeMillis()
        );

        if (!jobDirectory.mkdirs() && !jobDirectory.isDirectory()) {
            throw new IOException("Could not create the conversion workspace.");
        }

        File sourceFile = new File(jobDirectory, "source.pdf");
        File outputFile = new File(jobDirectory, "output.docx");
        TextRecognizer recognizer = TextRecognition.getClient(
                TextRecognizerOptions.DEFAULT_OPTIONS
        );

        callback.onProgress(2, "Preparing PDF…");

        try {
            copyUriToFile(
                    context.getContentResolver(),
                    sourceUri,
                    sourceFile,
                    cancellation
            );

            ensureNotCancelled(cancellation);
            List<DocxWriter.PageContent> pages = new ArrayList<>();
            int directTextPages = 0;
            int ocrPages = 0;

            try (PDDocument document = loadDocument(
                    sourceFile,
                    options.password
            )) {
                int totalPages = document.getNumberOfPages();
                List<Integer> selectedPages = PageRangeParser.parse(
                        options.pageRange,
                        totalPages
                );

                PDFTextStripper stripper = new PDFTextStripper();
                stripper.setSortByPosition(true);
                stripper.setLineSeparator("\n");
                stripper.setParagraphStart("");
                stripper.setParagraphEnd("\n");
                stripper.setPageStart("");
                stripper.setPageEnd("");

                PDFRenderer renderer = new PDFRenderer(document);
                float ocrDpi = options.highQuality ? 240f : 180f;

                for (int position = 0;
                     position < selectedPages.size();
                     position++) {
                    ensureNotCancelled(cancellation);

                    int zeroBasedPage = selectedPages.get(position);
                    int humanPage = zeroBasedPage + 1;
                    int progress = 7 + Math.round(
                            position
                                    / (float) Math.max(1, selectedPages.size())
                                    * 77f
                    );

                    callback.onProgress(
                            progress,
                            "Reading page " + humanPage + " of " + totalPages + "…"
                    );

                    String pageText = "";
                    boolean usedOcr = options.mode
                            == ConversionOptions.Mode.FORCE_OCR;

                    if (!usedOcr) {
                        stripper.setStartPage(humanPage);
                        stripper.setEndPage(humanPage);
                        pageText = normalizeText(stripper.getText(document));
                        usedOcr = visibleCharacterCount(pageText) < 20;
                    }

                    if (usedOcr) {
                        callback.onProgress(
                                progress,
                                "OCR page " + humanPage + " of " + totalPages + "…"
                        );
                        pageText = recognizePage(
                                renderer,
                                zeroBasedPage,
                                ocrDpi,
                                recognizer,
                                cancellation
                        );
                        ocrPages++;
                    } else {
                        directTextPages++;
                    }

                    List<String> paragraphs = splitParagraphs(pageText);
                    if (paragraphs.isEmpty()) {
                        paragraphs.add(
                                "[No readable text was detected on source page "
                                        + humanPage
                                        + ".]"
                        );
                    }

                    pages.add(
                            DocxWriter.PageContent.text(
                                    humanPage,
                                    paragraphs
                            )
                    );
                }
            } catch (IOException error) {
                if (looksLikePasswordError(error)) {
                    throw new IOException(
                            "This PDF is password protected. Enter the correct password.",
                            error
                    );
                }
                throw error;
            }

            ensureNotCancelled(cancellation);
            callback.onProgress(88, "Building a real editable Word document…");
            DocxWriter.write(
                    outputFile,
                    removePdfExtension(sourceName),
                    pages
            );

            ensureNotCancelled(cancellation);
            callback.onProgress(96, "Saving Word document…");
            copyFileToUri(
                    context.getContentResolver(),
                    outputFile,
                    destinationUri,
                    cancellation
            );

            callback.onProgress(100, "Editable Word document created.");
            return new Result(
                    pages.size(),
                    directTextPages,
                    ocrPages
            );
        } finally {
            recognizer.close();
            deleteRecursively(jobDirectory);
        }
    }

    private static String recognizePage(
            PDFRenderer renderer,
            int pageIndex,
            float dpi,
            TextRecognizer recognizer,
            AtomicBoolean cancellation
    ) throws Exception {
        ensureNotCancelled(cancellation);
        Bitmap bitmap = renderer.renderImageWithDPI(
                pageIndex,
                dpi,
                ImageType.RGB
        );

        try {
            InputImage image = InputImage.fromBitmap(bitmap, 0);
            com.google.mlkit.vision.text.Text recognized = Tasks.await(
                    recognizer.process(image),
                    120,
                    TimeUnit.SECONDS
            );
            ensureNotCancelled(cancellation);
            return normalizeText(recognized.getText());
        } finally {
            if (!bitmap.isRecycled()) {
                bitmap.recycle();
            }
        }
    }

    private static PDDocument loadDocument(
            File sourceFile,
            String password
    ) throws IOException {
        if (password == null || password.isEmpty()) {
            return PDDocument.load(sourceFile);
        }
        return PDDocument.load(sourceFile, password);
    }

    private static String normalizeText(String value) {
        if (value == null) {
            return "";
        }
        return value
                .replace("\r\n", "\n")
                .replace('\r', '\n')
                .replace('\u0000', ' ')
                .replaceAll("[ \\t]+\\n", "\n")
                .replaceAll("\\n{3,}", "\n\n")
                .trim();
    }

    private static List<String> splitParagraphs(String text) {
        List<String> output = new ArrayList<>();
        if (text == null || text.trim().isEmpty()) {
            return output;
        }

        String[] lines = text.split("\\n", -1);
        StringBuilder paragraph = new StringBuilder();

        for (String raw : lines) {
            String line = raw.trim();
            if (line.isEmpty()) {
                flush(paragraph, output);
                if (!output.isEmpty()
                        && !output.get(output.size() - 1).isEmpty()) {
                    output.add("");
                }
                continue;
            }

            boolean listLine = line.startsWith("•")
                    || line.startsWith("- ")
                    || line.matches("^\\d+[.)].*");
            boolean tableLike = raw.contains("\t")
                    || raw.matches(".*\\S {3,}\\S.*");
            boolean heading = looksLikeHeading(line);

            if (listLine || tableLike || heading) {
                flush(paragraph, output);
                output.add(line.replaceAll(" {3,}", "\t"));
                continue;
            }

            if (paragraph.length() == 0) {
                paragraph.append(line);
            } else if (shouldJoin(paragraph, line)) {
                paragraph.append(' ').append(line);
            } else {
                flush(paragraph, output);
                paragraph.append(line);
            }
        }

        flush(paragraph, output);
        return output;
    }

    private static boolean shouldJoin(
            StringBuilder current,
            String nextLine
    ) {
        if (current.length() == 0) {
            return false;
        }
        char last = current.charAt(current.length() - 1);
        boolean ended = last == '.'
                || last == '!'
                || last == '?'
                || last == ':'
                || last == ';';
        return !ended && !looksLikeHeading(current.toString());
    }

    private static boolean looksLikeHeading(String value) {
        if (value.length() < 3 || value.length() > 90) {
            return false;
        }
        int letters = 0;
        int upper = 0;
        for (int index = 0; index < value.length(); index++) {
            char character = value.charAt(index);
            if (Character.isLetter(character)) {
                letters++;
                if (Character.isUpperCase(character)) {
                    upper++;
                }
            }
        }
        return letters >= 3
                && upper >= Math.ceil(letters * 0.78)
                && !value.endsWith(".");
    }

    private static void flush(
            StringBuilder paragraph,
            List<String> output
    ) {
        if (paragraph.length() > 0) {
            output.add(paragraph.toString().trim());
            paragraph.setLength(0);
        }
    }

    private static int visibleCharacterCount(String text) {
        int count = 0;
        if (text == null) {
            return 0;
        }
        for (int index = 0; index < text.length(); index++) {
            if (!Character.isWhitespace(text.charAt(index))) {
                count++;
            }
        }
        return count;
    }

    private static boolean looksLikePasswordError(IOException error) {
        String message = error.getMessage();
        if (message == null) {
            return false;
        }
        String lower = message.toLowerCase();
        return lower.contains("password")
                || lower.contains("decrypt")
                || lower.contains("encrypted");
    }

    private static String removePdfExtension(String name) {
        if (name == null || name.trim().isEmpty()) {
            return "Converted PDF";
        }
        String clean = name.trim();
        if (clean.toLowerCase().endsWith(".pdf")) {
            clean = clean.substring(0, clean.length() - 4);
        }
        return clean;
    }

    private static void copyUriToFile(
            ContentResolver resolver,
            Uri source,
            File destination,
            AtomicBoolean cancellation
    ) throws IOException {
        try (InputStream input = resolver.openInputStream(source);
             OutputStream output = new FileOutputStream(destination)) {
            if (input == null) {
                throw new IOException("The selected PDF could not be opened.");
            }
            copy(input, output, cancellation);
        }
    }

    private static void copyFileToUri(
            ContentResolver resolver,
            File source,
            Uri destination,
            AtomicBoolean cancellation
    ) throws IOException {
        try (InputStream input = new FileInputStream(source);
             OutputStream output = resolver.openOutputStream(destination, "w")) {
            if (output == null) {
                throw new IOException("The selected save location could not be opened.");
            }
            copy(input, output, cancellation);
        }
    }

    private static void copy(
            InputStream input,
            OutputStream output,
            AtomicBoolean cancellation
    ) throws IOException {
        byte[] buffer = new byte[64 * 1024];
        int read;
        while ((read = input.read(buffer)) != -1) {
            ensureNotCancelled(cancellation);
            output.write(buffer, 0, read);
        }
    }

    private static void ensureNotCancelled(
            AtomicBoolean cancellation
    ) {
        if (cancellation != null && cancellation.get()) {
            throw new CancellationException("Conversion cancelled.");
        }
    }

    private static void deleteRecursively(File file) {
        if (file == null || !file.exists()) {
            return;
        }
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) {
                    deleteRecursively(child);
                }
            }
        }
        //noinspection ResultOfMethodCallIgnored
        file.delete();
    }
}
