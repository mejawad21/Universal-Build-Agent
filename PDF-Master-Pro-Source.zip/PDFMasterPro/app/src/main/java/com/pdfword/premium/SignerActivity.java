package com.pdfword.premium;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.materialswitch.MaterialSwitch;
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class SignerActivity extends AppCompatActivity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final SparseArray<SignaturePlacement> placements = new SparseArray<>();

    private TextView statusText;
    private TextView pageText;
    private ImageView pageImage;
    private SignatureOverlayView signatureOverlay;
    private FrameLayout pageFrame;
    private MaterialSwitch allPagesSwitch;

    private Uri sourceUri;
    private File sourceFile;
    private ParcelFileDescriptor descriptor;
    private android.graphics.pdf.PdfRenderer renderer;
    private Bitmap displayedPage;
    private Bitmap signatureBitmap;
    private int currentPage;
    private int renderToken;

    private ActivityResultLauncher<String[]> importSignatureLauncher;
    private ActivityResultLauncher<String> savePdfLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        PDFBoxResourceLoader.init(getApplicationContext());
        registerLaunchers();
        setContentView(R.layout.activity_signer);
        bindViews();
        bindActions();

        sourceUri = getIntent() == null ? null : getIntent().getData();
        if (sourceUri == null) {
            showError("No PDF was selected.");
            return;
        }
        openPdf();
    }

    private void registerLaunchers() {
        importSignatureLauncher = registerForActivityResult(
                new ActivityResultContracts.OpenDocument(),
                uri -> {
                    if (uri != null) {
                        importSignature(uri);
                    }
                }
        );

        savePdfLauncher = registerForActivityResult(
                new ActivityResultContracts.CreateDocument("application/pdf"),
                uri -> {
                    if (uri != null) {
                        saveSignedPdf(uri);
                    }
                }
        );
    }

    private void bindViews() {
        statusText = findViewById(R.id.signerStatus);
        pageText = findViewById(R.id.signerPageText);
        pageImage = findViewById(R.id.signerPageImage);
        signatureOverlay = findViewById(R.id.signatureOverlay);
        pageFrame = findViewById(R.id.signerPageFrame);
        allPagesSwitch = findViewById(R.id.switchAllPages);

        signatureOverlay.setListener(placement ->
                placements.put(currentPage, placement)
        );
    }

    private void bindActions() {
        findViewById(R.id.btnSignerBack).setOnClickListener(view -> finish());
        findViewById(R.id.btnPreviousSignerPage).setOnClickListener(view -> changePage(-1));
        findViewById(R.id.btnNextSignerPage).setOnClickListener(view -> changePage(1));
        findViewById(R.id.btnDrawSignature).setOnClickListener(view -> showSignaturePad());
        findViewById(R.id.btnImportSignature).setOnClickListener(view ->
                importSignatureLauncher.launch(new String[]{"image/png", "image/jpeg", "image/webp"})
        );
        findViewById(R.id.btnClearPageSignature).setOnClickListener(view -> {
            placements.remove(currentPage);
            signatureOverlay.clearPlacement();
            setStatus("Signature removed from this page.");
        });
        findViewById(R.id.btnSaveSignedPdf).setOnClickListener(view -> {
            storeCurrentPlacement();
            if (signatureBitmap == null) {
                Toast.makeText(this, "Draw or import a signature first.", Toast.LENGTH_LONG).show();
                return;
            }
            if (placements.size() == 0) {
                Toast.makeText(this, "Place the signature on at least one page.", Toast.LENGTH_LONG).show();
                return;
            }
            savePdfLauncher.launch("signed_document.pdf");
        });
    }

    private void openPdf() {
        setStatus("Opening PDF…");
        executor.execute(() -> {
            try {
                sourceFile = copyUriToCache(sourceUri, ".pdf");
                descriptor = ParcelFileDescriptor.open(
                        sourceFile,
                        ParcelFileDescriptor.MODE_READ_ONLY
                );
                renderer = new android.graphics.pdf.PdfRenderer(descriptor);
                if (renderer.getPageCount() <= 0) {
                    throw new IllegalStateException("The PDF has no pages.");
                }
                runOnUiThread(() -> {
                    currentPage = 0;
                    renderCurrentPage();
                });
            } catch (Exception error) {
                runOnUiThread(() -> showError(message(error)));
            }
        });
    }

    private void renderCurrentPage() {
        if (renderer == null) {
            return;
        }
        storeCurrentPlacement();
        int token = ++renderToken;
        int pageIndex = currentPage;
        setStatus("Rendering page…");

        executor.execute(() -> {
            android.graphics.pdf.PdfRenderer.Page page = null;
            Bitmap bitmap = null;
            try {
                page = renderer.openPage(pageIndex);
                float scale = 1.45f;
                int width = Math.max(1, Math.round(page.getWidth() * scale));
                int height = Math.max(1, Math.round(page.getHeight() * scale));
                bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(bitmap);
                canvas.drawColor(Color.WHITE);
                page.render(
                        bitmap,
                        null,
                        null,
                        android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY
                );
                Bitmap finalBitmap = bitmap;
                runOnUiThread(() -> {
                    if (token != renderToken || pageIndex != currentPage) {
                        if (!finalBitmap.isRecycled()) {
                            finalBitmap.recycle();
                        }
                        return;
                    }
                    if (displayedPage != null && !displayedPage.isRecycled()) {
                        displayedPage.recycle();
                    }
                    displayedPage = finalBitmap;
                    ViewGroup.LayoutParams parameters = pageFrame.getLayoutParams();
                    parameters.width = finalBitmap.getWidth();
                    parameters.height = finalBitmap.getHeight();
                    pageFrame.setLayoutParams(parameters);
                    pageImage.setImageBitmap(finalBitmap);
                    SignaturePlacement placement = placements.get(currentPage);
                    signatureOverlay.setSignature(signatureBitmap, placement);
                    updatePageText();
                    setStatus(signatureBitmap == null
                            ? "Draw a signature, then place it on the page."
                            : "Drag the signature. Use the blue handle to resize it.");
                });
            } catch (Exception error) {
                if (bitmap != null && !bitmap.isRecycled()) {
                    bitmap.recycle();
                }
                runOnUiThread(() -> showError(message(error)));
            } finally {
                if (page != null) {
                    page.close();
                }
            }
        });
    }

    private void changePage(int direction) {
        if (renderer == null) {
            return;
        }
        int next = currentPage + direction;
        if (next < 0 || next >= renderer.getPageCount()) {
            return;
        }
        storeCurrentPlacement();
        currentPage = next;
        renderCurrentPage();
    }

    private void showSignaturePad() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_signature_pad);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setLayout(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
        }

        SignaturePadView pad = dialog.findViewById(R.id.signaturePad);
        Button clear = dialog.findViewById(R.id.btnClearSignaturePad);
        Button use = dialog.findViewById(R.id.btnUseSignaturePad);
        Button cancel = dialog.findViewById(R.id.btnCancelSignaturePad);

        clear.setOnClickListener(view -> pad.clearPad());
        cancel.setOnClickListener(view -> dialog.dismiss());
        use.setOnClickListener(view -> {
            Bitmap created = pad.createSignatureBitmap();
            if (created == null) {
                Toast.makeText(this, "Please draw your signature.", Toast.LENGTH_SHORT).show();
                return;
            }
            replaceSignature(created);
            dialog.dismiss();
        });
        dialog.show();
        if (window != null) {
            window.setLayout(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
        }
    }

    private void importSignature(Uri uri) {
        executor.execute(() -> {
            try (InputStream input = getContentResolver().openInputStream(uri)) {
                if (input == null) {
                    throw new IllegalStateException("Could not open the signature image.");
                }
                Bitmap decoded = BitmapFactory.decodeStream(input);
                if (decoded == null) {
                    throw new IllegalStateException("The signature image is invalid.");
                }
                Bitmap trimmed = BitmapUtils.trimTransparent(decoded);
                if (trimmed == null) {
                    trimmed = decoded;
                } else if (trimmed != decoded) {
                    decoded.recycle();
                }
                Bitmap finalBitmap = trimmed;
                runOnUiThread(() -> replaceSignature(finalBitmap));
            } catch (Exception error) {
                runOnUiThread(() -> showError(message(error)));
            }
        });
    }

    private void replaceSignature(Bitmap bitmap) {
        if (signatureBitmap != null && !signatureBitmap.isRecycled()) {
            signatureBitmap.recycle();
        }
        signatureBitmap = bitmap;
        SignaturePlacement placement = placements.get(currentPage);
        if (placement == null) {
            placement = defaultPlacement(bitmap);
            placements.put(currentPage, placement);
        }
        signatureOverlay.setSignature(signatureBitmap, placement);
        setStatus("Signature ready. Drag it and resize it with the blue handle.");
    }

    private SignaturePlacement defaultPlacement(Bitmap bitmap) {
        float width = 0.32f;
        float pageAspect = pageFrame.getWidth()
                / Math.max(1f, pageFrame.getHeight());
        float imageAspect = bitmap.getHeight()
                / Math.max(1f, bitmap.getWidth());
        float height = Math.max(0.07f, Math.min(0.24f, width * imageAspect * pageAspect));
        return new SignaturePlacement(
                1f - width - 0.06f,
                1f - height - 0.08f,
                width,
                height
        );
    }

    private void storeCurrentPlacement() {
        if (signatureOverlay == null) {
            return;
        }
        SignaturePlacement placement = signatureOverlay.getPlacement();
        if (placement != null) {
            placements.put(currentPage, placement);
        }
    }

    private void saveSignedPdf(Uri destination) {
        setStatus("Saving signed PDF without turning pages into pictures…");
        findViewById(R.id.btnSaveSignedPdf).setEnabled(false);

        SparseArray<SignaturePlacement> outputPlacements = new SparseArray<>();
        if (allPagesSwitch.isChecked() && renderer != null) {
            SignaturePlacement base = placements.get(currentPage);
            if (base == null && placements.size() > 0) {
                base = placements.valueAt(0);
            }
            if (base != null) {
                for (int page = 0; page < renderer.getPageCount(); page++) {
                    outputPlacements.put(page, base.copy());
                }
            }
        } else {
            for (int index = 0; index < placements.size(); index++) {
                outputPlacements.put(
                        placements.keyAt(index),
                        placements.valueAt(index).copy()
                );
            }
        }

        executor.execute(() -> {
            try {
                PdfSignerEngine.saveSignedPdf(
                        this,
                        sourceFile,
                        destination,
                        signatureBitmap,
                        outputPlacements
                );
                runOnUiThread(() -> {
                    findViewById(R.id.btnSaveSignedPdf).setEnabled(true);
                    setStatus("Signed PDF saved successfully.");
                    Toast.makeText(
                            this,
                            "Signed PDF saved. Original text remains selectable.",
                            Toast.LENGTH_LONG
                    ).show();
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    findViewById(R.id.btnSaveSignedPdf).setEnabled(true);
                    showError(message(error));
                });
            }
        });
    }

    private File copyUriToCache(Uri uri, String extension) throws Exception {
        File file = new File(
                getCacheDir(),
                "signer-" + System.currentTimeMillis() + extension
        );
        try (InputStream input = getContentResolver().openInputStream(uri);
             FileOutputStream output = new FileOutputStream(file)) {
            if (input == null) {
                throw new IllegalStateException("Could not open the PDF.");
            }
            byte[] buffer = new byte[64 * 1024];
            int read;
            while ((read = input.read(buffer)) != -1) {
                output.write(buffer, 0, read);
            }
        }
        return file;
    }

    private void updatePageText() {
        if (renderer != null) {
            pageText.setText(
                    "Page "
                            + (currentPage + 1)
                            + " of "
                            + renderer.getPageCount()
            );
        }
    }

    private void setStatus(String value) {
        statusText.setText(value);
    }

    private void showError(String value) {
        setStatus(value);
        Toast.makeText(this, value, Toast.LENGTH_LONG).show();
    }

    private static String message(Throwable error) {
        String value = error.getMessage();
        return value == null || value.trim().isEmpty()
                ? error.getClass().getSimpleName()
                : value;
    }

    @Override
    protected void onDestroy() {
        renderToken++;
        executor.shutdownNow();
        if (renderer != null) {
            renderer.close();
        }
        if (descriptor != null) {
            try {
                descriptor.close();
            } catch (Exception ignored) {
            }
        }
        if (displayedPage != null && !displayedPage.isRecycled()) {
            displayedPage.recycle();
        }
        if (signatureBitmap != null && !signatureBitmap.isRecycled()) {
            signatureBitmap.recycle();
        }
        if (sourceFile != null) {
            //noinspection ResultOfMethodCallIgnored
            sourceFile.delete();
        }
        super.onDestroy();
    }
}
