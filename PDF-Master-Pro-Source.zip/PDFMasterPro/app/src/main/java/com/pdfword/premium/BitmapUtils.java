package com.pdfword.premium;

import android.graphics.Bitmap;
import android.graphics.Color;

final class BitmapUtils {
    private BitmapUtils() {
    }

    static Bitmap trimTransparent(Bitmap source) {
        int width = source.getWidth();
        int height = source.getHeight();
        Bitmap cleaned = Bitmap.createBitmap(
                width,
                height,
                Bitmap.Config.ARGB_8888
        );

        int left = width;
        int top = height;
        int right = -1;
        int bottom = -1;
        int[] row = new int[width];

        for (int y = 0; y < height; y++) {
            source.getPixels(row, 0, width, 0, y, width, 1);
            for (int x = 0; x < width; x++) {
                int color = row[x];
                int alpha = (color >>> 24) & 0xFF;
                int red = (color >>> 16) & 0xFF;
                int green = (color >>> 8) & 0xFF;
                int blue = color & 0xFF;

                boolean nearlyWhite = red > 244
                        && green > 244
                        && blue > 244;
                if (alpha < 12 || nearlyWhite) {
                    row[x] = Color.TRANSPARENT;
                    continue;
                }

                left = Math.min(left, x);
                right = Math.max(right, x);
                top = Math.min(top, y);
                bottom = Math.max(bottom, y);
            }
            cleaned.setPixels(row, 0, width, 0, y, width, 1);
        }

        if (right < left || bottom < top) {
            cleaned.recycle();
            return null;
        }

        int padding = 8;
        left = Math.max(0, left - padding);
        top = Math.max(0, top - padding);
        right = Math.min(width - 1, right + padding);
        bottom = Math.min(height - 1, bottom + padding);

        Bitmap trimmed = Bitmap.createBitmap(
                cleaned,
                left,
                top,
                right - left + 1,
                bottom - top + 1
        );
        if (trimmed != cleaned) {
            cleaned.recycle();
        }
        return trimmed;
    }
}
