package com.pdfword.premium;

final class SignaturePlacement {
    float left;
    float top;
    float width;
    float height;

    SignaturePlacement(float left, float top, float width, float height) {
        this.left = left;
        this.top = top;
        this.width = width;
        this.height = height;
        clamp();
    }

    SignaturePlacement copy() {
        return new SignaturePlacement(left, top, width, height);
    }

    void clamp() {
        width = Math.max(0.12f, Math.min(0.75f, width));
        height = Math.max(0.04f, Math.min(0.35f, height));
        left = Math.max(0f, Math.min(1f - width, left));
        top = Math.max(0f, Math.min(1f - height, top));
    }
}
