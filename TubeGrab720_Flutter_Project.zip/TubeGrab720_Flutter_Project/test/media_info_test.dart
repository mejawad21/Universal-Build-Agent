import 'package:flutter_test/flutter_test.dart';
import 'package:tubegrab/models/media_info.dart';

void main() {
  test('finds a strict 720p MP4 option', () {
    final media = MediaInfo.fromJson(
      {
        'title': 'Example',
        'channel': 'Owner',
        'duration_seconds': 90,
        'thumbnail_url': 'https://example.com/thumb.jpg',
        'options': [
          {
            'id': '720',
            'label': '720p MP4',
            'kind': 'video',
            'format': 'mp4',
            'height': 720,
            'url': 'https://example.com/video.mp4',
            'filename': 'example-720p.mp4',
            'mime_type': 'video/mp4',
          },
        ],
      },
      'https://example.com/watch',
    );

    expect(media.option720p, isNotNull);
    expect(media.option720p!.height, 720);
  });

  test('does not accept audio as a 720p option', () {
    final option = MediaOption.fromJson({
      'label': '720p',
      'kind': 'audio',
      'format': 'mp4',
      'height': 720,
      'url': 'https://example.com/audio.mp4',
    });
    expect(option.is720pMp4, isFalse);
  });

  test('does not accept insecure option URLs', () {
    final media = MediaInfo.fromJson(
      {
        'options': [
          {
            'label': '720p MP4',
            'kind': 'video',
            'format': 'mp4',
            'height': 720,
            'url': 'http://insecure.example/video.mp4',
          },
        ],
      },
      'https://example.com',
    );
    expect(media.option720p, isNull);
  });
}
