# TubeGrab 720 resolver API contract

The Android app does not parse or scrape platform pages. It calls an authorized resolver backend.

## Request

```http
POST /v1/resolve
Content-Type: application/json

{
  "url": "https://www.youtube.com/watch?v=VIDEO_ID",
  "quality": 720,
  "format": "mp4"
}
```

## Successful response

```json
{
  "title": "Video title",
  "channel": "Creator name",
  "duration_seconds": 245,
  "thumbnail_url": "https://cdn.example/thumbnail.jpg",
  "options": [
    {
      "id": "video-720p",
      "label": "720p MP4",
      "kind": "video",
      "format": "mp4",
      "height": 720,
      "url": "https://cdn.example/authorized-video-720p.mp4",
      "filename": "video-title-720p.mp4",
      "mime_type": "video/mp4",
      "content_length": 73400320
    }
  ]
}
```

The bundled gateway rejects every option except an HTTPS 720p MP4 file.

## Resolver requirements

- Return only media the user owns or is authorized to save.
- Return an HTTPS MP4 URL with a 720-pixel video height.
- Keep signed URLs valid long enough for background downloads.
- Support HTTP range requests for reliable pause/resume.
- Set correct `Content-Type`, `Content-Length`, ETag, and range headers.
- Do not return DRM-protected, paywalled, private, or access-controlled streams.
