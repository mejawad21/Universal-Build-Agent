import http from 'node:http';

const port = Number.parseInt(process.env.PORT ?? '8080', 10);
const upstreamUrl = process.env.UPSTREAM_RESOLVER_URL?.trim() ?? '';
const upstreamApiKey = process.env.UPSTREAM_API_KEY?.trim() ?? '';

const server = http.createServer(async (request, response) => {
  setSecurityHeaders(response);

  if (request.method === 'GET' && request.url === '/health') {
    return json(response, 200, { status: 'ok', quality: 720, format: 'mp4' });
  }

  if (request.method !== 'POST' || request.url !== '/v1/resolve') {
    return json(response, 404, { error: 'Not found' });
  }

  try {
    const body = await readJson(request);
    const source = parseHttpsUrl(body.url);

    if (!upstreamUrl) {
      return json(response, 501, {
        error:
          'No authorized resolver is configured. Set UPSTREAM_RESOLVER_URL to a service you are licensed to use.',
      });
    }

    const upstreamResponse = await fetch(upstreamUrl, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        ...(upstreamApiKey ? { authorization: `Bearer ${upstreamApiKey}` } : {}),
      },
      body: JSON.stringify({
        url: source.toString(),
        quality: 720,
        format: 'mp4',
      }),
      signal: AbortSignal.timeout(30000),
    });

    const text = await upstreamResponse.text();
    if (!upstreamResponse.ok) {
      response.writeHead(upstreamResponse.status, {
        'content-type': 'application/json; charset=utf-8',
      });
      return response.end(text);
    }

    const payload = JSON.parse(text);
    const options = Array.isArray(payload.options) ? payload.options : [];
    const filtered = options.filter(is720pMp4Option).map(sanitizeOption);
    if (filtered.length === 0) {
      return json(response, 422, {
        error: 'The upstream resolver did not return an authorized 720p MP4 option.',
      });
    }

    return json(response, 200, {
      title: String(payload.title ?? 'Untitled video').slice(0, 300),
      channel: String(payload.channel ?? 'Unknown channel').slice(0, 200),
      duration_seconds: Number(payload.duration_seconds ?? 0),
      thumbnail_url: safeHttpsString(payload.thumbnail_url),
      options: filtered,
    });
  } catch (error) {
    return json(response, 400, {
      error: error instanceof Error ? error.message : 'Bad request',
    });
  }
});

server.listen(port, '0.0.0.0', () => {
  console.log(`TubeGrab 720 resolver gateway listening on :${port}`);
});

function is720pMp4Option(option) {
  if (!option || typeof option !== 'object') return false;
  const label = String(option.label ?? '').toLowerCase();
  return String(option.kind ?? 'video').toLowerCase() === 'video' &&
    String(option.format ?? '').toLowerCase() === 'mp4' &&
    (Number(option.height) === 720 || label.includes('720p')) &&
    safeHttpsString(option.url) !== '';
}

function sanitizeOption(option) {
  return {
    id: String(option.id ?? 'video-720p'),
    label: '720p MP4',
    kind: 'video',
    format: 'mp4',
    height: 720,
    url: safeHttpsString(option.url),
    filename: safeFilename(option.filename ?? 'tubegrab_720p.mp4'),
    mime_type: 'video/mp4',
    ...(Number.isFinite(Number(option.content_length))
      ? { content_length: Number(option.content_length) }
      : {}),
  };
}

function safeFilename(value) {
  const cleaned = String(value)
    .replace(/[\\/:*?"<>|]/g, '_')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 180);
  return cleaned.toLowerCase().endsWith('.mp4')
    ? cleaned
    : `${cleaned || 'tubegrab_720p'}.mp4`;
}

function safeHttpsString(value) {
  try {
    const url = new URL(String(value ?? ''));
    return url.protocol === 'https:' ? url.toString() : '';
  } catch {
    return '';
  }
}

function parseHttpsUrl(value) {
  if (typeof value !== 'string' || value.length > 2048) {
    throw new Error('A valid URL is required.');
  }
  const url = new URL(value);
  if (url.protocol !== 'https:') {
    throw new Error('Only HTTPS sources are accepted.');
  }
  if (
    url.hostname === 'localhost' ||
    url.hostname === '127.0.0.1' ||
    url.hostname === '::1' ||
    url.hostname.endsWith('.local')
  ) {
    throw new Error('Local network targets are not allowed.');
  }
  return url;
}

async function readJson(request) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > 16_384) throw new Error('Request body is too large.');
    chunks.push(chunk);
  }
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}

function setSecurityHeaders(response) {
  response.setHeader('x-content-type-options', 'nosniff');
  response.setHeader('cache-control', 'no-store');
  response.setHeader('content-security-policy', "default-src 'none'");
}

function json(response, status, body) {
  response.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
  });
  response.end(JSON.stringify(body));
}
