import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:tubegrab/models/media_info.dart';

class ResolverException implements Exception {
  const ResolverException(this.message);
  final String message;

  @override
  String toString() => message;
}

class ResolverApi {
  ResolverApi({
    http.Client? client,
    String? baseUrl,
  })  : _client = client ?? http.Client(),
        _baseUrl = baseUrl ??
            const String.fromEnvironment(
              'TUBEGRAB_API_BASE_URL',
              defaultValue: '',
            );

  final http.Client _client;
  final String _baseUrl;

  Future<MediaInfo> fetch720p(String sourceUrl) async {
    final normalized = sourceUrl.trim();
    final uri = Uri.tryParse(normalized);
    if (uri == null || uri.scheme != 'https' || uri.host.isEmpty) {
      throw const ResolverException('Enter a valid HTTPS video link.');
    }

    if (_baseUrl.isEmpty) {
      throw const ResolverException(
        'The authorized resolver backend is not configured. Build with '
        '--dart-define=TUBEGRAB_API_BASE_URL=https://your-api.example',
      );
    }

    final base = _baseUrl.replaceAll(RegExp(r'/$'), '');
    final endpoint = Uri.parse('$base/v1/resolve');
    final response = await _client
        .post(
          endpoint,
          headers: const {'content-type': 'application/json'},
          body: jsonEncode({
            'url': uri.toString(),
            'quality': 720,
            'format': 'mp4',
          }),
        )
        .timeout(const Duration(seconds: 30));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      final message = _readError(response.body) ??
          'Resolver returned HTTP ${response.statusCode}.';
      throw ResolverException(message);
    }

    final decoded = jsonDecode(response.body);
    if (decoded is! Map<String, dynamic>) {
      throw const ResolverException('Resolver returned an invalid response.');
    }

    final result = MediaInfo.fromJson(decoded, uri.toString());
    if (result.option720p == null) {
      throw const ResolverException(
        'A downloadable 720p MP4 option was not available for this video.',
      );
    }
    return result;
  }

  String? _readError(String body) {
    try {
      final decoded = jsonDecode(body);
      if (decoded is Map<String, dynamic>) return decoded['error'] as String?;
    } catch (_) {
      return null;
    }
    return null;
  }
}
