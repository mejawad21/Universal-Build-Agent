import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:tubegrab/models/media_info.dart';
import 'package:tubegrab/services/download_service.dart';
import 'package:tubegrab/services/resolver_api.dart';
import 'package:tubegrab/widgets/media_preview_card.dart';

enum InputMode { single, multiple }

class _ResolveItem {
  const _ResolveItem({
    required this.url,
    this.media,
    this.error,
  });

  final String url;
  final MediaInfo? media;
  final String? error;
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    super.key,
    required this.resolverApi,
    required this.downloadService,
    required this.openLibrary,
  });

  final ResolverApi resolverApi;
  final DownloadService downloadService;
  final VoidCallback openLibrary;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _controller = TextEditingController();
  InputMode _mode = InputMode.single;
  final List<_ResolveItem> _results = [];
  bool _fetching = false;
  int _resolvedCount = 0;
  int _totalCount = 0;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _paste() async {
    HapticFeedback.selectionClick();
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    if (!mounted) return;
    final text = data?.text?.trim();
    if (text != null && text.isNotEmpty) {
      _controller.text = text;
      _controller.selection =
          TextSelection.collapsed(offset: _controller.text.length);
    }
  }

  List<String> _links() {
    final parts = _mode == InputMode.single
        ? <String>[_controller.text.trim()]
        : _controller.text
            .split(RegExp(r'[\r\n]+'))
            .map((item) => item.trim())
            .where((item) => item.isNotEmpty)
            .toList();

    final unique = <String>[];
    final seen = <String>{};
    for (final value in parts) {
      if (value.isNotEmpty && seen.add(value)) unique.add(value);
    }
    return unique;
  }

  Future<void> _fetch() async {
    HapticFeedback.mediumImpact();
    FocusScope.of(context).unfocus();
    final links = _links();
    if (links.isEmpty) {
      _show('Paste at least one video link.');
      return;
    }
    if (links.length > 20) {
      _show('Batch mode supports up to 20 links at a time.');
      return;
    }

    setState(() {
      _fetching = true;
      _results.clear();
      _resolvedCount = 0;
      _totalCount = links.length;
    });

    for (final link in links) {
      try {
        final media = await widget.resolverApi.fetch720p(link);
        if (!mounted) return;
        setState(() {
          _results.add(_ResolveItem(url: link, media: media));
          _resolvedCount += 1;
        });
      } on ResolverException catch (error) {
        if (!mounted) return;
        setState(() {
          _results.add(_ResolveItem(url: link, error: error.message));
          _resolvedCount += 1;
        });
      } catch (_) {
        if (!mounted) return;
        setState(() {
          _results.add(
            _ResolveItem(
              url: link,
              error: 'Unable to resolve this link.',
            ),
          );
          _resolvedCount += 1;
        });
      }
    }

    if (mounted) setState(() => _fetching = false);
  }

  Future<void> _download(MediaInfo media, {bool openLibrary = true}) async {
    final option = media.option720p;
    if (option == null) return;
    HapticFeedback.heavyImpact();
    await widget.downloadService.enqueue(media, option);
    if (!mounted) return;
    if (openLibrary) widget.openLibrary();
  }

  Future<void> _downloadAll() async {
    final mediaItems = _results
        .map((item) => item.media)
        .whereType<MediaInfo>()
        .toList(growable: false);
    if (mediaItems.isEmpty) return;

    for (final media in mediaItems) {
      await _download(media, openLibrary: false);
    }
    if (!mounted) return;
    _show('${mediaItems.length} videos added to the background queue.');
    widget.openLibrary();
  }

  void _show(String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final successes = _results.where((item) => item.media != null).length;
    return SafeArea(
      child: CustomScrollView(
        slivers: [
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 22, 20, 8),
            sliver: SliverToBoxAdapter(
              child: Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.primary,
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: const Icon(
                      Icons.download_rounded,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'TubeGrab 720',
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        Text('Single and multiple 720p video downloads'),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.all(20),
            sliver: SliverList.list(
              children: [
                Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(24),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        SegmentedButton<InputMode>(
                          segments: const [
                            ButtonSegment(
                              value: InputMode.single,
                              icon: Icon(Icons.link_rounded),
                              label: Text('Single'),
                            ),
                            ButtonSegment(
                              value: InputMode.multiple,
                              icon: Icon(Icons.playlist_add_rounded),
                              label: Text('Multiple'),
                            ),
                          ],
                          selected: {_mode},
                          onSelectionChanged: _fetching
                              ? null
                              : (selection) {
                                  setState(() {
                                    _mode = selection.first;
                                    _results.clear();
                                  });
                                },
                        ),
                        const SizedBox(height: 14),
                        TextField(
                          controller: _controller,
                          keyboardType: TextInputType.url,
                          autocorrect: false,
                          enableSuggestions: false,
                          textInputAction: _mode == InputMode.single
                              ? TextInputAction.go
                              : TextInputAction.newline,
                          onSubmitted: _mode == InputMode.single
                              ? (_) => _fetch()
                              : null,
                          minLines: _mode == InputMode.single ? 1 : 6,
                          maxLines: _mode == InputMode.single ? 1 : 10,
                          decoration: InputDecoration(
                            labelText: _mode == InputMode.single
                                ? 'Video link'
                                : 'One video link per line',
                            hintText: _mode == InputMode.single
                                ? 'https://www.youtube.com/watch?v=…'
                                : 'https://youtu.be/…\nhttps://www.youtube.com/watch?v=…',
                            prefixIcon: const Icon(Icons.link_rounded),
                            suffixIcon: TextButton.icon(
                              onPressed: _paste,
                              icon: const Icon(Icons.content_paste_rounded),
                              label: const Text('Paste'),
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        FilledButton.icon(
                          onPressed: _fetching ? null : _fetch,
                          style: FilledButton.styleFrom(
                            minimumSize: const Size.fromHeight(54),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                            ),
                          ),
                          icon: _fetching
                              ? const SizedBox.square(
                                  dimension: 20,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2.5,
                                  ),
                                )
                              : const Icon(Icons.search_rounded),
                          label: Text(
                            _fetching
                                ? 'Fetching $_resolvedCount of $_totalCount…'
                                : _mode == InputMode.single
                                    ? 'Fetch 720p video'
                                    : 'Fetch all 720p videos',
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                if (_fetching) ...[
                  const SizedBox(height: 14),
                  LinearProgressIndicator(
                    value: _totalCount == 0
                        ? null
                        : _resolvedCount / _totalCount,
                    borderRadius: BorderRadius.circular(20),
                    minHeight: 7,
                  ),
                ],
                if (_results.isNotEmpty) ...[
                  const SizedBox(height: 18),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          '$successes ready • ${_results.length - successes} unavailable',
                          style: Theme.of(context)
                              .textTheme
                              .titleMedium
                              ?.copyWith(fontWeight: FontWeight.w800),
                        ),
                      ),
                      if (successes > 1)
                        FilledButton.icon(
                          onPressed: _downloadAll,
                          icon: const Icon(Icons.download_for_offline_rounded),
                          label: Text('Download all ($successes)'),
                        ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  ..._results.map(
                    (item) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: item.media != null
                          ? MediaPreviewCard(
                              media: item.media!,
                              compact: _mode == InputMode.multiple,
                              onDownload: () => _download(item.media!),
                            )
                          : _ErrorCard(url: item.url, error: item.error ?? ''),
                    ),
                  ),
                ] else if (!_fetching) ...[
                  const SizedBox(height: 18),
                  const _EmptyHome(),
                ],
                const SizedBox(height: 30),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ErrorCard extends StatelessWidget {
  const _ErrorCard({required this.url, required this.error});
  final String url;
  final String error;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Icon(
          Icons.error_outline_rounded,
          color: Theme.of(context).colorScheme.error,
        ),
        title: Text(
          url,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        subtitle: Text(error),
      ),
    );
  }
}

class _EmptyHome extends StatelessWidget {
  const _EmptyHome();

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            Icon(
              Icons.video_collection_outlined,
              size: 64,
              color: Theme.of(context).colorScheme.primary,
            ),
            const SizedBox(height: 14),
            Text(
              'Single or batch downloading',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
            ),
            const SizedBox(height: 6),
            const Text(
              'Paste one link or up to 20 links. The resolver returns only an '
              'authorized 720p MP4 option for each video.',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
