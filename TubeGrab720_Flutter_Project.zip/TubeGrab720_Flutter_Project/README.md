# TubeGrab 720

TubeGrab 720 is a polished Flutter Android client for **single and multiple 720p MP4 downloads**.

## Main features

- Single-link mode
- Multiple-link mode with up to 20 links per batch
- Clipboard paste
- Sequential metadata resolution with batch progress
- Thumbnail, title, channel, duration, and file-size preview
- Strict 720p MP4 filtering
- Download one item or add every successful item to the queue
- Android background downloads
- Percentage, transfer speed, ETA, pause, resume, retry, and cancel
- Public `Downloads/TubeGrab` storage
- Completed-download history
- In-app video playback
- Material 3 dark interface
- GitHub Actions APK build workflow
- Optional Node.js resolver gateway

## Important limitation

The repository deliberately does not include YouTube page scraping, signature deciphering, DRM bypassing, account/session bypassing, or protected-stream extraction.

For YouTube or another platform link, connect an authorized resolver service that returns a 720p MP4 URL the user is permitted to download. Use YouTube's own offline/download functions where required by its terms.

## Build locally

Install Flutter 3.44.7 or a compatible stable version, then run:

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --debug \
  --dart-define=TUBEGRAB_API_BASE_URL=https://your-resolver.example
```

APK output:

```text
build/app/outputs/flutter-apk/app-debug.apk
```

## Build with GitHub Actions

1. Push this folder to GitHub.
2. Add the repository secret `TUBEGRAB_API_BASE_URL`.
3. Open **Actions → Build Android APK → Run workflow**.
4. Download the `TubeGrab-debug-apk` artifact.

## Resolver gateway

The `backend/` folder provides a secure adapter. It forwards resolution requests to an upstream service you are licensed to use and filters its response to a 720p MP4 option only.

```bash
cd backend
cp .env.example .env
npm start
```

Environment variables:

```text
PORT=8080
UPSTREAM_RESOLVER_URL=https://licensed-resolver.example/resolve
UPSTREAM_API_KEY=replace-me
```

## Background download requirements

Pause/resume depends on the download server supporting HTTP range requests. Completed files are moved to Android shared Downloads storage by the `background_downloader` package.

## Release signing

The included Android release configuration is intended for testing. Before publishing, add your own upload keystore and release signing configuration.

## License

MIT for the application source. Flutter packages retain their own licenses.
