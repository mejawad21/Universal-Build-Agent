# Shield VPN for Android

A polished, open-source WireGuard-compatible Android VPN client built with Kotlin and Jetpack Compose.

> **Important:** This repository is a VPN client, not a VPN service/provider. To connect, import a valid WireGuard `.conf` profile from your own server or a provider that gives you permission to use it.

## Features

- Real WireGuard userspace tunnel through Android `VpnService`
- Standard `.conf` profile import
- Paste-config option
- Multiple profiles with quick switching
- Connect/disconnect status and error handling
- AES-256-GCM encryption for configuration files at rest
- Android Keystore-managed encryption key
- No ads, analytics, tracking SDKs, or built-in servers
- Light, dark, and system themes
- Android always-on VPN/lockdown settings shortcut
- GitHub Actions APK build workflow
- Minimum Android 6.0 (API 23)

## Build

1. Install Android Studio with Android SDK 36.
2. Open the repository folder.
3. Let Gradle sync.
4. Run the `app` configuration, or use:

```bash
./gradlew assembleDebug
```

The debug APK will be created at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Build on GitHub

Push the project to GitHub and open **Actions → Android Build → Run workflow**.  
After completion, download the `ShieldVPN-debug-apk` artifact.

## Getting a profile

Use a configuration from:

- Your own WireGuard server
- Your workplace or organization
- A VPN provider that explicitly supplies WireGuard configuration files

The app does not create accounts, sell subscriptions, provide free servers, bypass paywalls, or include third-party credentials.

## Security notes

- Configurations can contain private keys. They are validated and AES-GCM encrypted before being stored.
- Encryption keys are generated and protected by Android Keystore.
- App data and profiles are excluded from Android backup/device transfer.
- Cleartext network traffic is disabled at the application level.
- Do not commit real `.conf`, `.jks`, or keystore files to Git.

## Technology

- Kotlin
- Jetpack Compose + Material 3
- Android `VpnService`
- Official WireGuard Android tunnel library `com.wireguard.android:tunnel:1.0.20260102`

## License

Application source: MIT License.  
WireGuard tunnel library: Apache License 2.0 and its upstream notices.
