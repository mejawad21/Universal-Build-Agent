# Third-party notices

This application uses the official WireGuard Android tunnel library:

- Group: `com.wireguard.android`
- Artifact: `tunnel`
- Version: `1.0.20260102`
- License: Apache License 2.0
- Project: WireGuard

Review the dependency's published license and upstream notices before distributing the application.
