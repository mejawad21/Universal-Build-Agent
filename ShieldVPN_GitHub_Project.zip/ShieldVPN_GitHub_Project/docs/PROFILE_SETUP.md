# Profile setup

Shield VPN accepts standard WireGuard `wg-quick` configuration files.

A valid profile normally contains:

- An `[Interface]` section with a private key and tunnel address
- At least one `[Peer]` section with a public key, endpoint, and allowed IPs
- Optional DNS, MTU, and persistent keepalive values

Obtain the complete file from your administrator, provider, or self-hosted server. Never share the private key in screenshots, issue reports, or public repositories.

For full-tunnel routing, the server profile usually includes IPv4 and/or IPv6 default routes in `AllowedIPs`. The exact values must come from the server operator.
