package com.example.shieldvpn.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ProfileNameSanitizerTest {
    @Test
    fun removesExtensionForDisplayName() {
        assertEquals("Dubai Server", ProfileNameSanitizer.fromFileName("Dubai Server.conf"))
    }

    @Test
    fun createsValidShortTunnelName() {
        val name = ProfileNameSanitizer.tunnelName("Dubai Premium Server #1")
        assertTrue(name.length <= 15)
        assertTrue(name.matches(Regex("[A-Za-z0-9_=+.-]+")))
    }
}
