package com.example.shieldvpn.data

data class VpnProfile(
    val id: String,
    val displayName: String,
    val tunnelName: String,
    val createdAt: Long,
)
