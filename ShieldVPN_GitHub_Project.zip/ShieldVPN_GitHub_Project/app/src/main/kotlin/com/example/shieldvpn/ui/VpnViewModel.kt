package com.example.shieldvpn.ui

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.shieldvpn.data.ProfileRepository
import com.example.shieldvpn.data.VpnProfile
import com.example.shieldvpn.vpn.VpnController
import com.example.shieldvpn.vpn.VpnStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppTheme { SYSTEM, LIGHT, DARK }

data class VpnUiState(
    val profiles: List<VpnProfile> = emptyList(),
    val selectedProfile: VpnProfile? = null,
    val status: VpnStatus = VpnStatus.Disconnected,
    val theme: AppTheme = AppTheme.SYSTEM,
    val message: String? = null,
)

class VpnViewModel(
    private val profiles: ProfileRepository,
    private val controller: VpnController,
) : ViewModel() {
    private val theme = MutableStateFlow(AppTheme.SYSTEM)
    private val message = MutableStateFlow<String?>(null)

    val uiState: StateFlow<VpnUiState> = combine(
        profiles.profiles,
        profiles.selectedId,
        controller.status,
        theme,
        message,
    ) { profileList, selectedId, vpnStatus, currentTheme, currentMessage ->
        VpnUiState(
            profiles = profileList,
            selectedProfile = profileList.firstOrNull { it.id == selectedId } ?: profileList.firstOrNull(),
            status = vpnStatus,
            theme = currentTheme,
            message = currentMessage,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), VpnUiState())

    init {
        viewModelScope.launch {
            controller.refresh(profiles.profiles.value)
        }
    }

    fun importUri(uri: Uri, fileName: String) {
        viewModelScope.launch {
            runCatching { profiles.importUri(uri, fileName) }
                .onSuccess {
                    profiles.select(it.id)
                    message.value = "Profile imported securely"
                }
                .onFailure { message.value = it.readableMessage() }
        }
    }

    fun importText(name: String, text: String) {
        viewModelScope.launch {
            runCatching { profiles.importText(name, text) }
                .onSuccess {
                    profiles.select(it.id)
                    message.value = "Profile added securely"
                }
                .onFailure { message.value = it.readableMessage() }
        }
    }

    fun select(profile: VpnProfile) = profiles.select(profile.id)

    fun delete(profile: VpnProfile) {
        viewModelScope.launch {
            val connected = uiState.value.status as? VpnStatus.Connected
            if (connected?.profileId == profile.id) controller.disconnect(profile)
            runCatching { profiles.delete(profile) }
                .onSuccess { message.value = "Profile deleted" }
                .onFailure { message.value = it.readableMessage() }
        }
    }

    fun connect() {
        val profile = uiState.value.selectedProfile
        if (profile == null) {
            message.value = "Import a WireGuard profile first"
            return
        }
        viewModelScope.launch { controller.connect(profile) }
    }

    fun disconnect() {
        val state = uiState.value
        val connectedId = (state.status as? VpnStatus.Connected)?.profileId
        val profile = state.profiles.firstOrNull { it.id == connectedId } ?: state.selectedProfile
        viewModelScope.launch { controller.disconnect(profile) }
    }

    fun setTheme(value: AppTheme) {
        theme.value = value
    }

    fun clearMessage() {
        message.value = null
    }

    private fun Throwable.readableMessage(): String =
        message?.takeIf { it.isNotBlank() }?.take(180) ?: "Unable to complete the action"

    class Factory(
        private val profiles: ProfileRepository,
        private val controller: VpnController,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return VpnViewModel(profiles, controller) as T
        }
    }
}
