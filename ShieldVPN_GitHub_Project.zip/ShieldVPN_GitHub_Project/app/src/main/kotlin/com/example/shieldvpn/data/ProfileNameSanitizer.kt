package com.example.shieldvpn.data

object ProfileNameSanitizer {
    private val invalid = Regex("[^A-Za-z0-9_=+.-]")

    fun fromFileName(fileName: String): String {
        val base = fileName.substringBeforeLast(".").trim().ifBlank { "VPN Profile" }
        return base.take(40)
    }

    fun tunnelName(displayName: String): String {
        val cleaned = displayName
            .trim()
            .replace(invalid, "_")
            .trim('_', '.', '-')
            .ifBlank { "shield" }
        // Linux/WireGuard interface names are limited to 15 characters.
        return cleaned.take(15)
    }
}
