package com.example.shieldvpn.vpn

import android.content.Context
import com.example.shieldvpn.data.ProfileRepository
import com.example.shieldvpn.data.VpnProfile
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

class VpnController(
    context: Context,
    private val repository: ProfileRepository,
) {
    private val backend = GoBackend(context.applicationContext)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val tunnels = ConcurrentHashMap<String, ManagedTunnel>()

    private val _status = MutableStateFlow<VpnStatus>(VpnStatus.Disconnected)
    val status: StateFlow<VpnStatus> = _status.asStateFlow()

    suspend fun refresh(profiles: List<VpnProfile>) = withContext(Dispatchers.IO) {
        runCatching {
            val running = backend.runningTunnelNames
            val profile = profiles.firstOrNull { it.tunnelName in running }
            _status.value = if (profile == null) {
                VpnStatus.Disconnected
            } else {
                VpnStatus.Connected(profile.id, profile.displayName)
            }
        }
    }

    suspend fun connect(profile: VpnProfile) = withContext(Dispatchers.IO) {
        _status.value = VpnStatus.Connecting
        try {
            val connected = (_status.value as? VpnStatus.Connected)
            if (connected != null && connected.profileId != profile.id) {
                repository.profiles.value.firstOrNull { it.id == connected.profileId }?.let {
                    disconnectInternal(it)
                }
            }

            val tunnel = tunnel(profile)
            val config = repository.config(profile)
            val result = backend.setState(tunnel, Tunnel.State.UP, config)
            if (result == Tunnel.State.UP) {
                _status.value = VpnStatus.Connected(profile.id, profile.displayName)
            } else {
                _status.value = VpnStatus.Error("The VPN tunnel did not start")
            }
        } catch (error: Exception) {
            _status.value = VpnStatus.Error(error.userMessage())
        }
    }

    suspend fun disconnect(profile: VpnProfile?) = withContext(Dispatchers.IO) {
        _status.value = VpnStatus.Disconnecting
        try {
            if (profile != null) disconnectInternal(profile)
            else backend.runningTunnelNames.forEach { runningName ->
                val synthetic = VpnProfile(runningName, runningName, runningName, 0)
                disconnectInternal(synthetic)
            }
            _status.value = VpnStatus.Disconnected
        } catch (error: Exception) {
            _status.value = VpnStatus.Error(error.userMessage())
        }
    }

    private fun disconnectInternal(profile: VpnProfile) {
        backend.setState(tunnel(profile), Tunnel.State.DOWN, null)
    }

    private fun tunnel(profile: VpnProfile): ManagedTunnel =
        tunnels.getOrPut(profile.tunnelName) {
            ManagedTunnel(profile.tunnelName) { newState ->
                scope.launch {
                    when (newState) {
                        Tunnel.State.UP ->
                            _status.value = VpnStatus.Connected(profile.id, profile.displayName)
                        Tunnel.State.DOWN ->
                            _status.value = VpnStatus.Disconnected
                        Tunnel.State.TOGGLE -> Unit
                    }
                }
            }
        }

    private fun Throwable.userMessage(): String {
        val raw = message?.trim().orEmpty()
        return when {
            raw.isBlank() -> "VPN connection failed"
            raw.length > 180 -> raw.take(177) + "..."
            else -> raw
        }
    }
}
