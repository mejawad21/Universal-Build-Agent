package com.example.shieldvpn.vpn

sealed interface VpnStatus {
    data object Disconnected : VpnStatus
    data object Connecting : VpnStatus
    data class Connected(val profileId: String, val profileName: String) : VpnStatus
    data object Disconnecting : VpnStatus
    data class Error(val message: String) : VpnStatus
}
