package com.example.shieldvpn.vpn

import com.wireguard.android.backend.Tunnel

internal class ManagedTunnel(
    private val tunnelName: String,
    private val onChange: (Tunnel.State) -> Unit,
) : Tunnel {
    override fun getName(): String = tunnelName

    override fun onStateChange(newState: Tunnel.State) {
        onChange(newState)
    }
}
