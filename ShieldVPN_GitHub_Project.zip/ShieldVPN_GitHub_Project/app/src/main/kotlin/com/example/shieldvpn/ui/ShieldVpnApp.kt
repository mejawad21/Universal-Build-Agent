package com.example.shieldvpn.ui

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.FileOpen
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Sync
import androidx.compose.material.icons.outlined.VpnLock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.shieldvpn.data.ProfileNameSanitizer
import com.example.shieldvpn.data.VpnProfile
import com.example.shieldvpn.ui.theme.ShieldVpnTheme
import com.example.shieldvpn.vpn.VpnStatus

private enum class Tab(val title: String, val icon: ImageVector) {
    HOME("Home", Icons.Outlined.Home),
    PROFILES("Profiles", Icons.Outlined.VpnLock),
    SETTINGS("Settings", Icons.Outlined.Settings),
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShieldVpnApp(viewModel: VpnViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }
    var showPasteDialog by remember { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }

    val vpnPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK || VpnService.prepare(context) == null) {
            viewModel.connect()
        }
    }

    val filePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri != null) {
            val fileName = uri.lastPathSegment?.substringAfterLast('/')
                ?.let(ProfileNameSanitizer::fromFileName)
                ?: "VPN Profile"
            viewModel.importUri(uri, fileName)
        }
    }

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    ShieldVpnTheme(preference = state.theme) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.Shield, contentDescription = null)
                            Text(
                                text = "  Shield VPN",
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background,
                    ),
                )
            },
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = {
                NavigationBar(modifier = Modifier.navigationBarsPadding()) {
                    Tab.entries.forEachIndexed { index, tab ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            icon = { Icon(tab.icon, contentDescription = tab.title) },
                            label = { Text(tab.title) },
                        )
                    }
                }
            },
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
            ) {
                when (Tab.entries[selectedTab]) {
                    Tab.HOME -> HomeScreen(
                        state = state,
                        onSelect = viewModel::select,
                        onConnect = {
                            val intent = VpnService.prepare(context)
                            if (intent == null) viewModel.connect()
                            else vpnPermission.launch(intent)
                        },
                        onDisconnect = viewModel::disconnect,
                        onImport = { filePicker.launch(arrayOf("text/plain", "application/octet-stream", "*/*")) },
                    )
                    Tab.PROFILES -> ProfilesScreen(
                        state = state,
                        onSelect = viewModel::select,
                        onDelete = viewModel::delete,
                        onImport = { filePicker.launch(arrayOf("text/plain", "application/octet-stream", "*/*")) },
                        onPaste = { showPasteDialog = true },
                    )
                    Tab.SETTINGS -> SettingsScreen(
                        state = state,
                        onTheme = viewModel::setTheme,
                        openVpnSettings = {
                            context.startActivity(Intent(Settings.ACTION_VPN_SETTINGS))
                        },
                    )
                }
            }
        }

        if (showPasteDialog) {
            PasteProfileDialog(
                onDismiss = { showPasteDialog = false },
                onSave = { name, config ->
                    showPasteDialog = false
                    viewModel.importText(name, config)
                },
            )
        }
    }
}

@Composable
private fun HomeScreen(
    state: VpnUiState,
    onSelect: (VpnProfile) -> Unit,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
    onImport: () -> Unit,
) {
    val isConnected = state.status is VpnStatus.Connected
    val busy = state.status is VpnStatus.Connecting || state.status is VpnStatus.Disconnecting

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                ),
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box(
                        modifier = Modifier
                            .size(132.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        FilledIconButton(
                            onClick = {
                                if (!busy) {
                                    if (isConnected) onDisconnect() else onConnect()
                                }
                            },
                            enabled = state.selectedProfile != null && !busy,
                            modifier = Modifier.size(112.dp),
                            shape = CircleShape,
                            colors = ButtonDefaults.filledIconButtonColors(
                                containerColor = if (isConnected) {
                                    MaterialTheme.colorScheme.primary
                                } else {
                                    MaterialTheme.colorScheme.surfaceVariant
                                },
                            ),
                        ) {
                            if (busy) {
                                CircularProgressIndicator(modifier = Modifier.size(42.dp))
                            } else {
                                Icon(
                                    imageVector = if (isConnected) Icons.Outlined.CheckCircle else Icons.Outlined.Shield,
                                    contentDescription = null,
                                    modifier = Modifier.size(52.dp),
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    AnimatedContent(targetState = state.status, label = "connection-status") { status ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = when (status) {
                                    VpnStatus.Disconnected -> "Not connected"
                                    VpnStatus.Connecting -> "Connecting securely…"
                                    is VpnStatus.Connected -> "Protected"
                                    VpnStatus.Disconnecting -> "Disconnecting…"
                                    is VpnStatus.Error -> "Connection error"
                                },
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                            )
                            if (status is VpnStatus.Error) {
                                Text(
                                    text = status.message,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.error,
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(20.dp))
                    ProfileSelector(
                        profiles = state.profiles,
                        selected = state.selectedProfile,
                        onSelect = onSelect,
                    )
                    Spacer(Modifier.height(16.dp))

                    Button(
                        onClick = if (isConnected) onDisconnect else onConnect,
                        enabled = state.selectedProfile != null && !busy,
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(14.dp),
                    ) {
                        Icon(
                            if (isConnected) Icons.Outlined.Lock else Icons.Outlined.Public,
                            contentDescription = null,
                        )
                        Text(if (isConnected) "  Disconnect" else "  Connect VPN")
                    }
                }
            }
        }

        if (state.profiles.isEmpty()) {
            item {
                OutlinedCard(
                    onClick = onImport,
                    modifier = Modifier.fillMaxWidth(),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                ) {
                    Row(
                        modifier = Modifier.padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Outlined.FileOpen, contentDescription = null)
                        Column(Modifier.padding(start = 16.dp)) {
                            Text("Import your VPN profile", fontWeight = FontWeight.SemiBold)
                            Text(
                                "Select a standard WireGuard .conf file.",
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SecurityFeature(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Outlined.Lock,
                    title = "Encrypted",
                    description = "Profiles stay encrypted on this device",
                )
                SecurityFeature(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Outlined.Security,
                    title = "WireGuard",
                    description = "Modern userspace VPN tunnel",
                )
            }
        }
    }
}

@Composable
private fun ProfileSelector(
    profiles: List<VpnProfile>,
    selected: VpnProfile?,
    onSelect: (VpnProfile) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier = Modifier.fillMaxWidth()) {
        OutlinedButton(
            onClick = { expanded = true },
            enabled = profiles.isNotEmpty(),
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(14.dp),
        ) {
            Icon(Icons.Outlined.VpnLock, contentDescription = null)
            Text(
                text = "  " + (selected?.displayName ?: "No VPN profile"),
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            profiles.forEach { profile ->
                DropdownMenuItem(
                    text = { Text(profile.displayName) },
                    leadingIcon = {
                        if (selected?.id == profile.id) {
                            Icon(Icons.Outlined.CheckCircle, contentDescription = null)
                        }
                    },
                    onClick = {
                        expanded = false
                        onSelect(profile)
                    },
                )
            }
        }
    }
}

@Composable
private fun SecurityFeature(
    modifier: Modifier,
    icon: ImageVector,
    title: String,
    description: String,
) {
    Card(modifier = modifier) {
        Column(Modifier.padding(16.dp)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(10.dp))
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(description, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun ProfilesScreen(
    state: VpnUiState,
    onSelect: (VpnProfile) -> Unit,
    onDelete: (VpnProfile) -> Unit,
    onImport: () -> Unit,
    onPaste: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Text("VPN profiles", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(
                "Use configurations supplied by your VPN provider or your own WireGuard server.",
                style = MaterialTheme.typography.bodyMedium,
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onImport, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Outlined.FileOpen, contentDescription = null)
                    Text("  Import")
                }
                OutlinedButton(onClick = onPaste, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Outlined.Add, contentDescription = null)
                    Text("  Paste")
                }
            }
        }
        if (state.profiles.isEmpty()) {
            item {
                OutlinedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Icon(Icons.Outlined.VpnLock, contentDescription = null, modifier = Modifier.size(48.dp))
                        Spacer(Modifier.height(12.dp))
                        Text("No profiles yet", fontWeight = FontWeight.SemiBold)
                        Text("Import or paste a valid WireGuard configuration.")
                    }
                }
            }
        }
        items(state.profiles, key = { it.id }) { profile ->
            val selected = profile.id == state.selectedProfile?.id
            val connected = (state.status as? VpnStatus.Connected)?.profileId == profile.id
            OutlinedCard(
                onClick = { onSelect(profile) },
                modifier = Modifier.fillMaxWidth(),
                border = BorderStroke(
                    width = if (selected) 2.dp else 1.dp,
                    color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                ),
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        imageVector = if (connected) Icons.Outlined.CheckCircle else Icons.Outlined.VpnLock,
                        contentDescription = null,
                        tint = if (connected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                    )
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 14.dp),
                    ) {
                        Text(profile.displayName, fontWeight = FontWeight.SemiBold)
                        Text(
                            "Tunnel: ${profile.tunnelName}",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    if (connected) AssistChip(onClick = {}, label = { Text("Active") })
                    IconButton(onClick = { onDelete(profile) }) {
                        Icon(Icons.Outlined.DeleteOutline, contentDescription = "Delete profile")
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    state: VpnUiState,
    onTheme: (AppTheme) -> Unit,
    openVpnSettings: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Text("Settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column {
                    SettingRow(
                        icon = Icons.Outlined.Sync,
                        title = "Follow system theme",
                        subtitle = "Use your phone's light or dark setting",
                        trailing = {
                            Switch(
                                checked = state.theme == AppTheme.SYSTEM,
                                onCheckedChange = { enabled ->
                                    onTheme(if (enabled) AppTheme.SYSTEM else AppTheme.DARK)
                                },
                            )
                        },
                    )
                    Divider()
                    SettingRow(
                        icon = Icons.Outlined.LightMode,
                        title = "Light mode",
                        subtitle = "Use the light appearance",
                        trailing = {
                            Switch(
                                checked = state.theme == AppTheme.LIGHT,
                                onCheckedChange = { if (it) onTheme(AppTheme.LIGHT) },
                            )
                        },
                    )
                    Divider()
                    SettingRow(
                        icon = Icons.Outlined.DarkMode,
                        title = "Dark mode",
                        subtitle = "Use the dark appearance",
                        trailing = {
                            Switch(
                                checked = state.theme == AppTheme.DARK,
                                onCheckedChange = { if (it) onTheme(AppTheme.DARK) },
                            )
                        },
                    )
                }
            }
        }
        item {
            OutlinedCard(onClick = openVpnSettings, modifier = Modifier.fillMaxWidth()) {
                SettingRow(
                    icon = Icons.Outlined.Security,
                    title = "Always-on VPN & kill switch",
                    subtitle = "Open Android VPN settings to enable always-on and block connections without VPN",
                )
            }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                SettingRow(
                    icon = Icons.Outlined.Info,
                    title = "Privacy",
                    subtitle = "No analytics or ads. Imported configurations are AES-GCM encrypted in app-only storage.",
                )
            }
        }
        item {
            Text(
                "Shield VPN is a client, not a VPN provider. A valid WireGuard server configuration is required.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun SettingRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    trailing: (@Composable () -> Unit)? = null,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 14.dp),
        ) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall)
        }
        trailing?.invoke()
    }
}

@Composable
private fun PasteProfileDialog(
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit,
) {
    var name by remember { mutableStateOf("") }
    var config by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add WireGuard profile") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Profile name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = config,
                    onValueChange = { config = it },
                    label = { Text("WireGuard configuration") },
                    minLines = 8,
                    maxLines = 12,
                    modifier = Modifier.fillMaxWidth(),
                )
                Text(
                    "The private key is encrypted before it is saved.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onSave(name.ifBlank { "VPN Profile" }, config) },
                enabled = config.isNotBlank(),
            ) {
                Text("Save securely")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}
