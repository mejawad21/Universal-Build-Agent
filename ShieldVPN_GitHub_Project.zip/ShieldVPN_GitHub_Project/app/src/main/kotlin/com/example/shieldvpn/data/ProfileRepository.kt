package com.example.shieldvpn.data

import android.content.Context
import android.net.Uri
import com.wireguard.config.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.util.UUID

class ProfileRepository(private val context: Context) {
    private val mutex = Mutex()
    private val crypto = CryptoBox()
    private val directory = File(context.filesDir, "vpn_profiles").apply { mkdirs() }
    private val indexFile = File(directory, "profiles.json")
    private val preferences = context.getSharedPreferences("shield_vpn", Context.MODE_PRIVATE)

    private val _profiles = MutableStateFlow(loadIndex())
    val profiles: StateFlow<List<VpnProfile>> = _profiles.asStateFlow()

    private val _selectedId = MutableStateFlow(preferences.getString(KEY_SELECTED, null))
    val selectedId: StateFlow<String?> = _selectedId.asStateFlow()

    suspend fun importUri(uri: Uri, suggestedName: String): VpnProfile = withContext(Dispatchers.IO) {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: error("Unable to read the selected profile")
        importBytes(bytes, suggestedName)
    }

    suspend fun importText(displayName: String, configText: String): VpnProfile =
        withContext(Dispatchers.IO) {
            importBytes(configText.toByteArray(Charsets.UTF_8), displayName)
        }

    private suspend fun importBytes(bytes: ByteArray, requestedName: String): VpnProfile = mutex.withLock {
        // Validate before storing. Invalid keys, addresses, endpoints, or sections are rejected.
        Config.parse(ByteArrayInputStream(bytes))

        val existing = _profiles.value
        val baseDisplay = requestedName.trim().ifBlank { "VPN Profile" }.take(40)
        val display = uniqueDisplayName(baseDisplay, existing)
        val tunnel = uniqueTunnelName(ProfileNameSanitizer.tunnelName(display), existing)
        val profile = VpnProfile(
            id = UUID.randomUUID().toString(),
            displayName = display,
            tunnelName = tunnel,
            createdAt = System.currentTimeMillis(),
        )

        File(directory, "${profile.id}.bin").writeBytes(crypto.encrypt(bytes))
        val updated = (existing + profile).sortedBy { it.displayName.lowercase() }
        saveIndex(updated)
        _profiles.value = updated
        if (_selectedId.value == null) select(profile.id)
        profile
    }

    suspend fun config(profile: VpnProfile): Config = withContext(Dispatchers.IO) {
        val file = File(directory, "${profile.id}.bin")
        require(file.isFile) { "Profile data is missing" }
        Config.parse(ByteArrayInputStream(crypto.decrypt(file.readBytes())))
    }

    suspend fun delete(profile: VpnProfile) = withContext(Dispatchers.IO) {
        mutex.withLock {
            File(directory, "${profile.id}.bin").delete()
            val updated = _profiles.value.filterNot { it.id == profile.id }
            saveIndex(updated)
            _profiles.value = updated
            if (_selectedId.value == profile.id) {
                select(updated.firstOrNull()?.id)
            }
        }
    }

    fun select(id: String?) {
        _selectedId.value = id
        preferences.edit().putString(KEY_SELECTED, id).apply()
    }

    fun selectedProfile(): VpnProfile? =
        _profiles.value.firstOrNull { it.id == _selectedId.value } ?: _profiles.value.firstOrNull()

    private fun uniqueDisplayName(base: String, existing: List<VpnProfile>): String {
        if (existing.none { it.displayName.equals(base, ignoreCase = true) }) return base
        var index = 2
        while (existing.any { it.displayName.equals("$base $index", ignoreCase = true) }) index++
        return "$base $index"
    }

    private fun uniqueTunnelName(base: String, existing: List<VpnProfile>): String {
        if (existing.none { it.tunnelName == base }) return base
        var index = 2
        while (true) {
            val suffix = "_$index"
            val candidate = base.take(15 - suffix.length) + suffix
            if (existing.none { it.tunnelName == candidate }) return candidate
            index++
        }
    }

    private fun loadIndex(): List<VpnProfile> = runCatching {
        if (!indexFile.isFile) return emptyList()
        val array = JSONArray(indexFile.readText())
        buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                add(
                    VpnProfile(
                        id = item.getString("id"),
                        displayName = item.getString("displayName"),
                        tunnelName = item.getString("tunnelName"),
                        createdAt = item.getLong("createdAt"),
                    ),
                )
            }
        }.filter { File(directory, "${it.id}.bin").isFile }
    }.getOrDefault(emptyList())

    private fun saveIndex(items: List<VpnProfile>) {
        val array = JSONArray()
        items.forEach { profile ->
            array.put(
                JSONObject()
                    .put("id", profile.id)
                    .put("displayName", profile.displayName)
                    .put("tunnelName", profile.tunnelName)
                    .put("createdAt", profile.createdAt),
            )
        }
        val temp = File(directory, "profiles.tmp")
        temp.writeText(array.toString())
        if (indexFile.exists()) indexFile.delete()
        check(temp.renameTo(indexFile)) { "Unable to save profile index" }
    }

    companion object {
        private const val KEY_SELECTED = "selected_profile"
    }
}
