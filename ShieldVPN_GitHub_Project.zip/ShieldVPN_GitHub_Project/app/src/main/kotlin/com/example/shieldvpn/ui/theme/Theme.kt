package com.example.shieldvpn.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.example.shieldvpn.ui.AppTheme

private val Green = Color(0xFF18A675)
private val Navy = Color(0xFF071B2C)
private val SoftGreen = Color(0xFFB8F2DC)

private val DarkColors = darkColorScheme(
    primary = Green,
    secondary = SoftGreen,
    background = Color(0xFF06131E),
    surface = Color(0xFF0C2232),
    surfaceVariant = Color(0xFF153447),
    onPrimary = Color.White,
    onBackground = Color(0xFFE8F1F5),
    onSurface = Color(0xFFE8F1F5),
)

private val LightColors = lightColorScheme(
    primary = Green,
    secondary = Navy,
    background = Color(0xFFF3F8F7),
    surface = Color.White,
    surfaceVariant = Color(0xFFE0EEEA),
    onPrimary = Color.White,
    onBackground = Navy,
    onSurface = Navy,
)

@Composable
fun ShieldVpnTheme(
    preference: AppTheme,
    content: @Composable () -> Unit,
) {
    val dark = when (preference) {
        AppTheme.SYSTEM -> isSystemInDarkTheme()
        AppTheme.LIGHT -> false
        AppTheme.DARK -> true
    }
    val colors = if (dark) DarkColors else LightColors
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !dark
        }
    }

    MaterialTheme(
        colorScheme = colors,
        typography = MaterialTheme.typography,
        content = content,
    )
}
