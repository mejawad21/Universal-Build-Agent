package com.example.shieldvpn

import android.app.Application
import com.example.shieldvpn.data.ProfileRepository
import com.example.shieldvpn.vpn.VpnController

class ShieldVpnApplication : Application() {
    val profiles: ProfileRepository by lazy { ProfileRepository(this) }
    val vpnController: VpnController by lazy { VpnController(this, profiles) }
}
