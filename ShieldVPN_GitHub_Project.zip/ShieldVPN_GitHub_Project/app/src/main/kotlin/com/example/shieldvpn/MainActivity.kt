package com.example.shieldvpn

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.shieldvpn.ui.ShieldVpnApp
import com.example.shieldvpn.ui.VpnViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val application = application as ShieldVpnApplication
        setContent {
            val vm: VpnViewModel = viewModel(
                factory = VpnViewModel.Factory(
                    profiles = application.profiles,
                    controller = application.vpnController,
                ),
            )
            ShieldVpnApp(viewModel = vm)
        }
    }
}
