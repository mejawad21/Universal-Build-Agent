# Security policy

## Reporting

Do not open a public issue containing VPN private keys, preshared keys, endpoints tied to a private network, or real configuration files.

Report code-level vulnerabilities privately to the repository maintainer.

## Sensitive files

The `.gitignore` excludes common signing-key formats. Real WireGuard configurations must never be committed.
